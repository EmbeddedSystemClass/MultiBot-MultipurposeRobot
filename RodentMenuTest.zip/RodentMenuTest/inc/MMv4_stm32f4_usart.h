#ifndef __MMv4_STM32F4_USART_H
#define __MMv4_STM32F4_USART_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "main.h"

#define USART_NUMBER 				USART1
#define USART_NUMBER_AF				GPIO_AF_USART1
#define USART_CLOCK_PORT			RCC_APB2Periph_USART1

#define GPIO_USART_PORT				GPIOB
#define GPIO_USART_PIN_TX 			GPIO_Pin_6
#define GPIO_USART_PIN_RX			GPIO_Pin_7
#define GPIO_USART_CLOCK_PORT		RCC_AHB1Periph_GPIOB
#define GPIO_USART_PSOURCE_TX		GPIO_PinSource6
#define GPIO_USART_PSOURCE_RX		GPIO_PinSource7

typedef struct 
{
	char character;
	char buffer[100];	
} USARTBuffer_TypeDef;

void USART_Initialize(void);
void USART_NVIC_Initialize(void);
void USART_Puts(volatile char *s);
void USART_SendChar(char c);
void USART_SendString(const char* s);
void USART1_IRQHandler(void);
void USART_SprintfPuts(int16_t value);

/* scans intiger from terminal, 
	ENTER key is '/' (write text and accept using '/') */
float USART_geti(void);

#ifdef __cplusplus
}
#endif

#endif
