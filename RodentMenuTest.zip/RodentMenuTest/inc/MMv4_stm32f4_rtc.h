#ifndef __MMv4_STM32F4_RTC_H
#define __MMv4_STM32F4_RTC_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "main.h"

/* Exported types ------------------------------------------------------------*/
typedef struct{
  uint8_t time_array[12]; //character time array (for display)
	double seconds;
	uint32_t time;
	uint32_t vel_time;
	uint32_t tmp_time;
}Time_TypeDef;

void RTC_Initialize(void);
void RTC_WakeUp_InteruptInitialize(void);
void RTC_Enable(void);
void RTC_WakeUp_InteruptEnable(double wake_up_counter);
void RTC_Disable(void);
Time_TypeDef RTC_Get_Time(RTC_TimeTypeDef* RTC_TimeStructure);
double RTC_GetTime_SecondsSubSeconds(RTC_TimeTypeDef* RTC_TimeStructure);
void RTC_Time_display(RTC_TimeTypeDef* RTC_TimeStructure, Time_TypeDef TimeData); /* Displays the Time */ 
void RTC_ResetTime(RTC_TimeTypeDef* RTC_TimeStructure); /* Resets Time Data */
extern void RTC_WKUP_IRQHandler(void);

#ifdef __cplusplus
}
#endif

#endif
