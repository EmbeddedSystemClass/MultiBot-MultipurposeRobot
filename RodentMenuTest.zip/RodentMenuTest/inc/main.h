/**
  ******************************************************************************
  * @file    Project/STM32F4xx_StdPeriph_Templates/main.h 
  * @author  MCD Application Team
  * @version V1.6.0
  * @date    04-September-2015
  * @brief   Header for main.c module
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2015 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */
  
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#define USART_NUMBER 						USART1
#define USART_NUMBER_AF					GPIO_AF_USART1
#define USART_CLOCK_PORT				RCC_APB2Periph_USART1

#define GPIO_USART_PORT					GPIOB
#define GPIO_USART_PIN_TX 			GPIO_Pin_6
#define GPIO_USART_PIN_RX				GPIO_Pin_7
#define GPIO_USART_CLOCK_PORT		RCC_AHB1Periph_GPIOB
#define GPIO_USART_PSOURCE_TX		GPIO_PinSource6
#define GPIO_USART_PSOURCE_RX		GPIO_PinSource7

#define tic_factor 10

/* Includes ------------------------------------------------------------------*/

#include "stm32f4xx.h"
#include "stm32f4xx_rng.h"

#include "arm_math.h"
#include <math.h>

//#ifndef __MAIN_H
//#define __MAIN_H
//#include "arm_math.h"
//#endif


#include "MMv4_stm32f4_l3gd20.h"
#include "MMv4_stm32f4_adc_dma.h"
#include "MMv4_stm32f4_rtc.h"
#include "MMv4_stm32f4_tb6612fng.h"
#include "MMv4_stm32f4_rs030.h"
#include "MMv4_stm32f4_usart.h"
#include "MMv4_stm32f4_delay.h"
#include "MMv4_stm32f4_buzzer.h"
//#include "MMv4_stm32f4_software.h"


#include <stdio.h>
#include <stdlib.h> 

#define CHECK_BIT(val,pos) ((val) & (0<<(pos)))

void Delay(__IO uint32_t nTime);
void TimingDelay_Decrement(void);
void GPIO_ClockInitialize(void);

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
