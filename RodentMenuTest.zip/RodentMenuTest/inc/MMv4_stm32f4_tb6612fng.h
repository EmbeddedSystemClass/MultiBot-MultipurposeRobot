#ifndef __MMv4_STM32F4_TB6612FNG_H
#define __MMv4_STM32F4_TB6612FNG_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "main.h"
	 
#include "arm_math.h"
#include "MMv4_stm32f4_rs030.h"
	 
#define STBY_PORT	GPIOA
#define STBY_PIN	GPIO_Pin_8

#define PWMA_Channel	TM_PWM_Channel_2
#define PWMA_PP				TM_PWM_PinsPack_1
#define PWMB_Channel 	TM_PWM_Channel_1
#define PWMB_PP				TM_PWM_PinsPack_2

#define AB_IN	GPIOB
#define A_IN1	GPIO_Pin_4
#define A_IN2	GPIO_Pin_3
#define B_IN1	GPIO_Pin_5
#define B_IN2	GPIO_Pin_10

#define TIM2_counter_clock 50000000 //stm32f4 tim2 freuency
#define TIM2_output_clock 80000 //TB6612FNG frequency
#define CCR_percnt_factor 6 //CCR_percnt_factor =  6 (indeed 6.24) / 100 => CCR_percnt_factor =  CCR_percnt_factor * duty cycle %
//#define SE_MaxCCR	2050 //maxTim_CCR = Tim_ARR
#define SE_MaxCCR	5857 //SE_MaxCCR = (SE_Max*100)/duty_cycle; f.e 5857 = (2050*100)/35

typedef struct {
	int A_power_percent;
	int B_power_percent;
	float power_error_perc;
	arm_pid_instance_f32 PID;
} TB6612FNG_TypeDef;

typedef struct {
	int8_t dir_flagA;
	int8_t dir_flagB;
}DirectionFlag_TypeDef;

void TB6612FNG_GPIO_Initialize(void);
void TB6612FNG_PWM_Initialize(void);
int16_t CCR_Perc(int8_t CCR_Percent);	/* Converts percents to CCR values */
void TB6612FNG_PWMA_SetChannel(int16_t CCR1_Val);
void TB6612FNG_PWMB_SetChannel(int16_t CCR2_Val);
void RightMotor(DirectionFlag_TypeDef* Direction_FlagStruct, int16_t CRR_Val);
void LeftMotor(DirectionFlag_TypeDef* Direction_FlagStruct, int16_t CRR_Val);
void RightForward(DirectionFlag_TypeDef* Direction_FlagStruct, int8_t PowerPercent);
void LeftForward(DirectionFlag_TypeDef* Direction_FlagStruct, int8_t PowerPercent);
void RightBackward(DirectionFlag_TypeDef* Direction_FlagStruct, int8_t PowerPercent);
void LeftBackward(DirectionFlag_TypeDef* Direction_FlagStruct, int8_t PowerPercent);
void RightHardStop(void);
void LeftHardStop(void);
void RightSoftStop(void);
void LeftSoftStop(void);
void MouseHardStop(void);

#ifdef __cplusplus
}
#endif

#endif 
