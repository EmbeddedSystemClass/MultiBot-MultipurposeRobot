#ifndef __MMv4_STM32F4_RNG_H
#define __MMv4_STM32F4_RNG_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "main.h"
#include "stm32f4xx_rcc.h"
	 
#define RCC_AHB2Periph_RNG ((uint32_t)0x00000040)
	 
void RNG_Initialize(void);
uint32_t RNG_GetRandomNumber(void);
FlagStatus RNG_GetFlagStatus(uint8_t RNG_FLAG);

#ifdef __cplusplus
}
#endif

#endif
