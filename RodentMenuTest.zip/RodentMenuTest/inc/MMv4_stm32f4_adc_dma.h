#ifndef __MMv4_STM32F4_ADC_DMA_H
#define __MMv4_STM32F4_ADC_DMA_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "main.h"

//#include "arm_math.h"
	 
#define SE_ADC 						ADC1
#define SE_ADC_CLK        			RCC_APB2Periph_ADC1

#define SE_ADC_DMA_CHANNEL    		DMA_Channel_0
#define SE_ADC_DMA_STREAM     		DMA2_Stream0
#define SE_ADC_DR_ADDRESS    		(uint32_t)&(ADC1->DR)

#define SE1_Channel					ADC_Channel_2	//Right
#define SE1_ADC_CHANNEL_GPIO_CLK  	RCC_AHB1Periph_GPIOA
#define SE1_GPIO_PORT   			GPIOA
#define SE1_GPIO_PIN    			GPIO_Pin_2

#define SE2_Channel 				ADC_Channel_12	//Right
#define SE2_ADC_CHANNEL_GPIO_CLK  	RCC_AHB1Periph_GPIOC
#define SE2_GPIO_PORT   			GPIOC
#define SE2_GPIO_PIN   				GPIO_Pin_2


#define SE3_Channel 				ADC_Channel_3	//Left
#define SE3_ADC_CHANNEL_GPIO_CLK  	RCC_AHB1Periph_GPIOA
#define SE3_GPIO_PORT  			 	GPIOA
#define SE3_GPIO_PIN   				GPIO_Pin_3

#define SE4_Channel 				ADC_Channel_13 //Left
#define SE4_ADC_CHANNEL_GPIO_CLK  	RCC_AHB1Periph_GPIOC
#define SE4_GPIO_PORT   			GPIOC
#define SE4_GPIO_PIN   				GPIO_Pin_3
#define voltage_conv_factor			0.8058608059 // 3300/4095

typedef struct {
	__IO uint32_t SE_voltage[4];
	__IO uint32_t SE_value[4];
	
	uint32_t SE_middle_value;
	int32_t SE_value_correct[4];
	
	int8_t wsk_previous_error;
	float error_perc;
}IRSernorsData_InitTypeDef;

int32_t getADCx(IRSernorsData_InitTypeDef* IRSensors_DataStruct, uint8_t x);


/**
  * @brief  ADC1 channelx with DMA configuration
  * @note   This function Configure the ADC peripheral  
            1) Enable peripheral clocks
            2) DMA2_Stream0 channel0 configuration
            3) Configure ADC Channelx pin as analog input
            4) Configure ADC1 Channelx
  * @param  None
  * @retval None
  */
  
void SE1_ADC_DMA_Initialize(IRSernorsData_InitTypeDef* IRSernorsData_DataStruct); //initialise sensor 1
void SE2_ADC_DMA_Initialize(IRSernorsData_InitTypeDef* IRSernorsData_DataStruct);	//initialise sensor 2
void SE3_ADC_DMA_Initialize(IRSernorsData_InitTypeDef* IRSernorsData_DataStruct);	//initialise sensor 3
void SE4_ADC_DMA_Initialize(IRSernorsData_InitTypeDef* IRSernorsData_DataStruct);	//initialise sensor 4
void SE_ADC_DMA_Initialize(IRSernorsData_InitTypeDef* IRSernorsData_DataStruct);	//initialise all 4 sensors
//int ADC_ErrorToPerc(int error_value);	/* Converts error value to percent */

#ifdef __cplusplus
}
#endif

#endif
