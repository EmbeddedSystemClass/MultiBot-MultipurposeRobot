#ifndef __MMv4_STM32F4_BUZZER_H
#define __MMv4_STM32F4_BUZZER_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "main.h"
	 
#define	BUZZER_PORT	GPIOA
#define	BUZZER_PIN GPIO_Pin_7

#define on_time 50

	 
void BuzzerInit(void );
	 
#ifdef __cplusplus
}
#endif

#endif
