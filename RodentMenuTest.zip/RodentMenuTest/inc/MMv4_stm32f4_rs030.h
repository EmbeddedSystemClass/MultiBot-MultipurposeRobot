#ifndef __MMv4_STM32F4_RS030_H
#define __MMv4_STM32F4_RS030_H
#ifdef __cplusplus
 extern "C" {
#endif

#include "main.h"
#include "arm_math.h"
	 
#define Encoders_PORT	GPIOC
#define EncoderB_PIN	GPIO_Pin_11 //right
#define EncoderA_PIN 	GPIO_Pin_8 //left
//#define wheel_radius 	1.56	//[cm]
#define rotation_distance 9.801769079	//2*pi*r[cm]

typedef struct {
	int16_t bumpA;
	int16_t bumpB;
	int16_t turnA;
	int16_t turnB;
	
	int8_t directionA;
	int8_t directionB;
	int8_t actual_bumps;
	int8_t previous_bumps;
	float32_t distanceA;
	float32_t distanceB;
	float32_t prev_distA;
	float32_t prev_distB;
	int8_t rotation;
	
	arm_pid_instance_f32 PID;
	float32_t distance;
	float32_t velocity;
	float acceleration;
}EncoderData_TypeDef;

void EncoderA_EXTI_Initialize(void); /* Configures EXTI Linex for A in interrupt mode */
void EncoderB_EXTI_Initialize(void); /* Configures EXTI Linex for B in interrupt mode */
void Encoders_EXTI_Enable(void);
void Encoders_EXTI_Disable(void);
extern void EXTI9_5_IRQHandler(void);	// encoder A Right
extern void EXTI15_10_IRQHandler(void);	// encoder B Left

#ifdef __cplusplus
}
#endif

#endif 
