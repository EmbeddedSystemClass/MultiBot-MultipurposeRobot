#ifndef __MMv4_STM32F4_SOFTWARE_H
#define __MMv4_STM32F4_SOFTWARE_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "main.h"

//#include "arm_math.h"
	 
/* Choose PID parameters */
#define PID_PARAM_KP        5            /* Proporcional */ //gain
#define PID_PARAM_KI        0.025        /* Integral */
#define PID_PARAM_KD        20            /* Derivative */
	 
/*last*/
#define robot_width 8 	 
#define robot_lenght 8
#define square_size 18	 
#define bumps_per_suare 19.76718647	//
#define distance_per_revolution 9.106//
#define distance_per_bump 0.9106 //[cm]	 
#define axel_to_center_distance 1.45 //[cm]	
#define initial_distane_state 2.55 //robot_lenght/2 - axel_to_center_distance
#define initial_distance_to_square_center 6.45 //square_size/2 -  initial_distane_state
	 
#define wheel_radius 1.45
#define wheel_diameter 2.9
#define	wheel_width 1.3
#define wheelbase 6.8

#define Rside_wall_present	-400
#define Lside_wall_present	-700
#define front_wall_present	-350
/*last*/
	 
#define double_bumps_per_suare 40
	 
	 
#define make_turn_left	-40
#define make_turn_right	40

#define stop_wall	15
#define stop_wall_factor 2
	 
#define front_se_max 2050
#define side_se_max 3500
	 
#define side_wall_present	1100

#define acceptable_front_wall 900//850
#define front_wall_close	250
#define front_is_in_square 520

#define high_error_level 500

#define front_error_tolerance 25
#define side_error_tolerance 25

#define accelerate_kp	1.2
#define accelerate_ki	0
#define accelerate_kd	0

#define break_kp	1.2//3
#define break_ki	0
#define break_kd	0

#define forward_kp	0.4
#define forward_ki	0//1
#define forward_kd	0//0.025

#define enc_forward_kp	60
#define enc_forward_ki	0.5
#define enc_forward_kd	9

#define gyro_turn_kp	10
#define gyro_turn_ki	0.005
#define gyro_turn_kd	0

#define gyro_turn_around_kp	5
#define gyro_turn_around_ki	0.005
#define gyro_turn_around_kd	0

#define turn_kp	15
#define turn_ki	0.045
#define turn_kd	0.9 

#define stop_ccr 200
#define turn_ccr 600

#define turn_around_speed 12
#define turn_bumps 3
#define turn_around_bumps	6
#define turn_bumps_one_wheel 6
#define turn_around_bumps_one_wheel	12
	 
#define wall_thickness	1.2 //[cm]
#define wall_height	5 //[cm]

#define square_size 18	//[cm]
#define maze_width	16 //16x16
#define maze_size	256 //16*16

#define error_to_percent_factor_side		0.0333	//100/3000
#define error_to_percent_factor_front		0.0416//100/2400
#define error_correction_factor 0.17 //error_percent_value * error_correction_factor = correction value
#define ready_error_corrctor_side 0.01665 // = error_to_percent_factor_side * error_correction_factor
#define ready_error_corrctor_front 0.007072


#define a_coeficient 0.01665 


#define DirN 0
#define DirE 1
#define DirS 2
#define DirW 3

/*
|__| - 0111
|''| - 1101
*/
#define  wall_north   4    // 0b00000100
#define  wall_east    1    // 0b00000001
#define  wall_south   2    // 0b00000010 		
#define  wall_west    8    // 0b00001000


//0N0E0S0W
//#define  dir_north   	64    // 0b01000000
//#define  dir_east    	16    // 0b00010000
//#define  dir_south   	4    	// 0b00000100
//#define  dir_west   	1    	// 0b00000001 

#define  dir_north   	4    	// 0b00000100
#define  dir_east    	1    	// 0b00000001
#define  dir_south   	2    	// 0b00000010
#define  dir_west   	8    	// 0b00001000 

#define  north   	4    	// 0b00000100
#define  east    	1    	// 0b00000001
#define  south   	2    	// 0b00000010
#define  west   	8    	// 0b00001000

#define visited		128		//0b10000000
#define finish		32		//0b00100000
#define dead_end	64		//0b01000000
#define start		16		//0b00010000

//int side_middle_position; //middle position of side ir sensor



enum Mouse_Status{
	Init,
	Decide,
	Forward,
	Turn,
	TurnAround,
	TurnAroundRight,
	TurnAroundLeft,
	Backward,
	TurnRight,
	TurnLeft,
	NewSquare,
	DrivePath,
	DriveDist,
	Stop,
	Thinking,
	Done,
	Flood,
	Test
};

typedef struct  {
	uint8_t N;
	uint8_t initial_corner_position;
	int16_t actual_position;
	uint8_t X, Y;
	int8_t nextX, nextY;

	int8_t top_neighbor; //coeficiet
	int8_t right_neighbor;
	int8_t left_neighbor;
	int8_t down_neighbor;

	uint8_t maze_flood[maze_width][maze_width];	//[X][Y]
	uint8_t maze_wall[maze_width][maze_width];	//type of square and box properities
	uint8_t mouse_dir;	//micromouse direction
	char mouse_orientation[4];
	int8_t wall_square[8];
	uint32_t SE_Right_vir; //virtual IR sensor value
	uint32_t SE_Left_vir;
	uint8_t temp_north;
	uint8_t temp_east;
	uint8_t temp_south;   	
	uint8_t temp_west;

	uint8_t mouse_north;
	uint8_t mouse_east;
	uint8_t mouse_south;
	uint8_t mouse_west;
} MazeData_TypeDef;

typedef struct {
	int16_t irsensor_front;
	int16_t irsensor_side;
	int16_t irsensor_side_l;
	int16_t irsensor_side_r;
	int16_t encoders_square;
	int16_t encoders_square_l;
	int16_t encoders_square_r;
	int16_t encoders_differ;
	int16_t irsensor_side_differ;
	float32_t gyro_error;
	int8_t error_corrector_perc;
	uint8_t irsensor_front_perc;
	int8_t irsensor_front_error_perc;
	int16_t error;
	int16_t error_left_motor;
	int16_t error_right_motor;
	int16_t error_diff;
	float32_t error_pid_correction_front;
	float32_t error_pid_correction_front_l;
	float32_t error_pid_correction_front_r;
	float32_t error_pid_correction_differ;
	float32_t error_pid_correction_side;
	float32_t error_pid_correction_side_l;
	float32_t error_pid_correction_side_r;
	float32_t error_pid_correction_turn;
	//int8_t irsensor_front_error_perc;
} ErrorData_TypeDef;

typedef struct {
	float32_t kp, ki, kd;
	arm_pid_instance_f32 PID;
} PidData_TypeDef;

typedef enum {
	MM_State_Ready,
	MM_State_Error,
	MM_Success
	//MM_State_Distance
} MM_State_TypeDef;

typedef struct {
	int8_t directionA;
	int8_t directionB;
}DirectionData_TypeDef;

typedef struct {
	float32_t x, x_prev;
	float32_t y, y_prev;
	float32_t Da;
	float32_t Db;
	float32_t D;
	float32_t theta; //angle
	float32_t va;
	float32_t aa;
	float32_t ab;
	float32_t vb;
	float32_t Ox;
	float32_t Oy;
	float32_t Rs;
	float32_t omega;
	
	float32_t	maxCCRpulse;
	float32_t CCRpulseA;
	float32_t	CCRpulseB;
	float32_t CCRpulseCorrA;
	float32_t	CCRpulseCorrB;
	
	float32_t rot_pd_regulator;//regulator rotacji
	float32_t trans_pd_regulator;//regulator translacji
	float32_t trans_pd_regulatorA;
	float32_t trans_pd_regulatorB;
	
	float32_t distance_to_drive;
	float32_t distance_to_driveA;
	float32_t distance_to_driveB;
} DifferentialDrive_TypeDef;

void getBin(int num, char *str);
int DecToBin(int n);

void ResetMaze(MazeData_TypeDef *Maze_DataStruct);
void FillMaze(MazeData_TypeDef *Maze_DataStruct);
void DrawMaze(MazeData_TypeDef *Maze_DataStruct);
void DrawMaze_Bin(MazeData_TypeDef *Maze_DataStruct);
void DrawMazeWalls(MazeData_TypeDef *Maze_DataStruct);

void setDa(DifferentialDrive_TypeDef* DifferentialDrive_DataStruct, int8_t directionA);
void setDb(DifferentialDrive_TypeDef* DifferentialDrive_DataStruct, int8_t directionB);
void setTheta(DifferentialDrive_TypeDef* DifferentialDrive_DataStruct);
void setD(DifferentialDrive_TypeDef* DifferentialDrive_DataStruct);
void setX(DifferentialDrive_TypeDef* DifferentialDrive_DataStruct);
void setY(DifferentialDrive_TypeDef* DifferentialDrive_DataStruct);

//void resetDifferentialDrive(DifferentialDrive_TypeDef* DifferentialDrive_DataStruct, int16_t bumpB);
void PresentMazeWalls(MazeData_TypeDef *Maze_DataStruct);

MM_State_TypeDef ResetMouseOrientatioArray(MazeData_TypeDef *Maze_DataStruct);
MM_State_TypeDef RotateMouseOrientatioArray90degRight(MazeData_TypeDef *Maze_DataStruct);
MM_State_TypeDef RotateMouseOrientatioArray90degLeft(MazeData_TypeDef *Maze_DataStruct);

MM_State_TypeDef CheckNextFieldOrientation(MazeData_TypeDef *Maze_DataStruct);

void FloodFillMaze(MazeData_TypeDef *Maze_DataStruct, uint8_t position_x, uint8_t position_y, int8_t actual_position, int8_t next_position);

void AddWall(IRSernorsData_InitTypeDef* IRSensors_DataStruct, MazeData_TypeDef *Maze_DataStruct);
//void DriveDistance(IRSernorsData_InitTypeDef *IRSensors_DataStruct, EncoderData_TypeDef *Encoders_DataStruct, ErrorData_TypeDef * Error_DataStruct, uint8_t move_bumps, uint8_t test_value);
//void FloodMaze(IRSernorsData_InitTypeDef* IRSensors_DataStruct, ErrorData_TypeDef * Error_DataStruct, uint8_t *pwm_perc_value);
void PidInit(arm_pid_instance_f32 * S, float KP, float KI, float KD);
void PidInitR(arm_pid_instance_f32 * S, float KP, float KI, float KD);


void MakeDecision(enum Mouse_Status* MouseState, EncoderData_TypeDef *Encoders_DataStruct, DirectionFlag_TypeDef* Direction_DataStruct, MazeData_TypeDef* Maze_DataStruct, DifferentialDrive_TypeDef* DifferentialDrive_DataStruct);

void DriveDistance(enum Mouse_Status* MouseState, DifferentialDrive_TypeDef* DifferentialDrive_DataStruct, IRSernorsData_InitTypeDef* IRSensors_DataStruct, PidData_TypeDef PID_Regulator[],DirectionFlag_TypeDef* Direction_FlagStruct);
void LeftTurn(enum Mouse_Status* MouseState, DifferentialDrive_TypeDef* DifferentialDrive_DataStruct, IRSernorsData_InitTypeDef* IRSensors_DataStruct, PidData_TypeDef PID_Regulator[],DirectionFlag_TypeDef* Direction_FlagStruct);
void RightTurn(enum Mouse_Status* MouseState, DifferentialDrive_TypeDef* DifferentialDrive_DataStruct, IRSernorsData_InitTypeDef* IRSensors_DataStruct, PidData_TypeDef PID_Regulator[],DirectionFlag_TypeDef* Direction_FlagStruct);

void AroundLeftTurn(enum Mouse_Status* MouseState, DifferentialDrive_TypeDef* DifferentialDrive_DataStruct, IRSernorsData_InitTypeDef* IRSensors_DataStruct, PidData_TypeDef PID_Regulator[],DirectionFlag_TypeDef* Direction_FlagStruct);

void Turn90DegreesRightOneWheel(EncoderData_TypeDef *Encoders_DataStruct, enum Mouse_Status *MouseState, uint8_t *turn_speed);
void Turn90DegreesLeftOneWheel(EncoderData_TypeDef *Encoders_DataStruct, enum Mouse_Status *MouseState, uint8_t *turn_speed);
void SpyWall(IRSernorsData_InitTypeDef* IRSensors_DataStruct, PidData_TypeDef PID_Regulator[], ErrorData_TypeDef * Error_DataStruct, DirectionFlag_TypeDef* Direction_DataStruct, int16_t pwm_ccr_value);
float32_t ReturnPidError(arm_pid_instance_f32 *S, float32_t error, int16_t se_max);
void Button_Initialize(void);
void DriveForward(IRSernorsData_InitTypeDef* IRSensors_DataStruct, ErrorData_TypeDef * Error_DataStruct, DirectionFlag_TypeDef* Direction_DataStruct, uint8_t pwm_perc_value);
void PidInsert(PidData_TypeDef* PID_Regulator, USARTBuffer_TypeDef* USART_Buffer);
void FloodMaze(enum Mouse_Status MouseState, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_DataStruct, uint16_t pwm_ccr_value);
void TurnRight90Degrees(enum Mouse_Status* MouseState, L3GD20_TypeDef* L3GD20_DataStruct, Time_TypeDef* Time_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef* PID_Regulator, DirectionFlag_TypeDef* Direction_DataStruct,  uint16_t pwm_ccr_value);
void TurnLeft90Degrees(enum Mouse_Status* MouseState, L3GD20_TypeDef* L3GD20_DataStruct, Time_TypeDef* Time_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef* PID_Regulator, DirectionFlag_TypeDef* Direction_DataStruct,  uint16_t pwm_ccr_value);
void TurnRight180Degrees(enum Mouse_Status* MouseState, L3GD20_TypeDef* L3GD20_DataStruct, Time_TypeDef* Time_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef* PID_Regulator, DirectionFlag_TypeDef* Direction_DataStruct,  uint16_t pwm_ccr_value);
void TurnLeft180Degrees(enum Mouse_Status* MouseState, L3GD20_TypeDef* L3GD20_DataStruct, Time_TypeDef* Time_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef* PID_Regulator, DirectionFlag_TypeDef* Direction_DataStruct,  uint16_t pwm_ccr_value);
void FollowTheWall(enum Mouse_Status* MouseState, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_DataStruct, uint16_t pwm_ccr_value);
void FollowOneWall(enum Mouse_Status* MouseState, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_DataStruct, uint16_t pwm_ccr_value);
void MouseInit(IRSernorsData_InitTypeDef* IRSensors_DataStruct, MazeData_TypeDef* Maze_DataStruct, PidData_TypeDef* PID_Regulator, DirectionFlag_TypeDef* Direction_DataStruct);
void MakeTurnRight(enum Mouse_Status* MouseState, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_DataStruct, uint16_t pwm_ccr_value);
void MakeTurnLeft(enum Mouse_Status* MouseState, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_DataStruct, uint16_t pwm_ccr_value);
void MakeTurnAroundRight(enum Mouse_Status* MouseState, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_DataStruct, uint16_t pwm_ccr_value);
void MakeTurnAroundLeft(enum Mouse_Status* MouseState, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_DataStruct, uint16_t pwm_ccr_value);
void DriveSuareOneWall(enum Mouse_Status* MouseState, EncoderData_TypeDef *Encoders_DataStruct, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_DataStruct, uint16_t pwm_ccr_value);
void MouseInit2(IRSernorsData_InitTypeDef* IRSensors_DataStruct);

void MakeTurnAroundGyro(enum Mouse_Status* MouseState, L3GD20_TypeDef* L3GD20_DataStruct, Time_TypeDef* Time_DataStruct, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_DataStruct, uint16_t pwm_ccr_value);

#ifdef __cplusplus
}
#endif

#endif
