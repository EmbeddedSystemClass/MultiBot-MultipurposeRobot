#ifndef __MMv4_STM32F4_DELAY_H
#define __MMv4_STM32F4_DELAY_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "main.h"

static __IO uint32_t uwTimingDelay;

void Delay(__IO uint32_t nTime);
void TimingDelay_Decrement(void);

#ifdef __cplusplus
}
#endif

#endif
