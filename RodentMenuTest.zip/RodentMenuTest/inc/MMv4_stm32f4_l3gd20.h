#ifndef __MMv4_STM32F4_L3GD20_H
#define __MMv4_STM32F4_L3GD20_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "main.h"
#include "arm_math.h"
	 
/* Default I2C used */
#ifndef L3GD20_I2C
	#define L3GD20_I2C_NUM				I2C1
	#define L3GD20_I2C_PORT    		GPIOB 
	#define L3GD20_I2C_PIN_SCL    GPIO_Pin_8
	#define L3GD20_I2C_PIN_SDA    GPIO_Pin_9
#endif

/* Default I2C clock */
#ifndef L3G_I2C_CLOCK
#define L3G_I2C_CLOCK			400000
#endif

/* Identification number */
#define D20H_WHO_ID     0xD7

#define D20_SA0_HIGH_ADDRESS      (0x6B << 1) 
#define D20_SA0_LOW_ADDRESS       (0x6A << 1) 

/* Registers addresses */
#define	WHO_AM_I        0x0F

/* L3G registers */
#define	CTRL1           0x20 // D20H
#define	CTRL_REG1       0x20 // D20, 4200D
#define	CTRL2           0x21 // D20H
#define	CTRL_REG2       0x21 // D20, 4200D
#define	CTRL3           0x22 // D20H
#define	CTRL_REG3       0x22 // D20, 4200D
#define	CTRL4           0x23 // D20H
#define	CTRL_REG4       0x23 // D20, 4200D
#define	CTRL5          	0x24 // D20H
#define	CTRL_REG5       0x24 // D20, 4200D
#define	REFERENCE       0x25
#define	OUT_TEMP        0x26
#define	STATUS          0x27 // D20H
#define	STATUS_REG      0x27 // D20, 4200D

#define	OUT_X_L         0x28
#define	OUT_X_H         0x29
#define	OUT_Y_L         0x2A
#define	OUT_Y_H         0x2B
#define	OUT_Z_L         0x2C
#define	OUT_Z_H         0x2D

#define	FIFO_CTRL       0x2E // D20H
#define	FIFO_CTRL_REG   0x2E // D20, 4200D
#define	FIFO_SRC        0x2F // D20H
#define	FIFO_SRC_REG    0x2F // D20, 4200D

#define	IG_CFG          0x30 // D20H
#define	INT1_CFG        0x30 // D20, 4200D
#define	IG_SRC          0x31 // D20H
#define	INT1_SRC        0x31 // D20, 4200D
#define	IG_THS_XH       0x32 // D20H
#define	INT1_THS_XH     0x32 // D20, 4200D
#define	IG_THS_XL       0x33 // D20H
#define	INT1_THS_XL     0x33 // D20, 4200D
#define	IG_THS_YH       0x34 // D20H
#define	INT1_THS_YH     0x34 // D20, 4200D
#define	IG_THS_YL       0x35 // D20H
#define	INT1_THS_YL     0x35 // D20, 4200D
#define	IG_THS_ZH       0x36 // D20H
#define	INT1_THS_ZH     0x36 // D20, 4200D
#define	IG_THS_ZL       0x37 // D20H
#define	INT1_THS_ZL     0x37 // D20, 4200D
#define	IG_DURATION     0x38 // D20H
#define	INT1_DURATION   0x38 // D20, 4200D

#define	LOW_ODR         0x39  // D20H

/* Sensitivity factors, datasheet pg. 9 */
#define L3GD20_SENSITIVITY_250		8.75	/* 8.75 mdps/digit */
#define L3GD20_SENSITIVITY_500		17.5	/* 17.5 mdps/digit */
#define L3GD20_SENSITIVITY_2000		70		/* 70 mdps/digit */

#define	sampleTime	20
#define	noise	3

typedef struct {
  uint8_t Address;
	uint8_t GyroState;
	int16_t X;
	int16_t Y;
	int16_t Z;
	float32_t angle;
	float32_t prev_rate;
} L3GD20_TypeDef;

typedef enum {
	L3GD20_State_Ready,   
	L3GD20_State_Error, 
} L3GD20_State_TypeDef;

typedef enum {
	L3GD20_Scale_250, 
	L3GD20_Scale_500, 
	L3GD20_Scale_2000 
} L3GD20_Scale_TypeDef;

L3GD20_State_TypeDef L3GD20_Initialize(L3GD20_TypeDef* L3GD20_InitStruct, L3GD20_Scale_TypeDef scale);

L3GD20_State_TypeDef L3GD20_ReadXYZ(L3GD20_TypeDef* L3GD20_InitStruct);

#ifdef __cplusplus
}
#endif
#endif
