#include  "MMv4_stm32f4_buzzer.h"

void BuzzerInit(void ){
	GPIO_InitTypeDef BUZZER_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
  
  BUZZER_InitStructure.GPIO_Pin = BUZZER_PIN;
  BUZZER_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  BUZZER_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  BUZZER_InitStructure.GPIO_OType = GPIO_OType_PP;
  BUZZER_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;  
  GPIO_Init(GPIOA, &BUZZER_InitStructure);
}
