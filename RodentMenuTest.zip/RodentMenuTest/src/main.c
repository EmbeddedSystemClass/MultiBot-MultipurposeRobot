#include "main.h"
#include "MMv4_stm32f4_software.h"

int16_t test_value;
int16_t *wsk_test_value = &test_value;
uint32_t msTicks = 0;
uint32_t msDelay = 0;
uint32_t vel_time = 0;
float32_t time = 0;
float32_t time_act = 0;
float32_t time_prev = 0;
float32_t dt;

float32_t distance_actA;
float32_t distance_prevA;
float32_t velocity_actA;
float32_t velocity_prevA;

float32_t distance_actB;
float32_t distance_prevB;

int8_t dir_flag_actA;
int8_t dir_flag_prevA;
int8_t dir_flag_actB;
int8_t dir_flag_prevB;

uint32_t *wsk_msTicks = &msTicks;

uint8_t buzzer_state;
uint32_t buzzer_time;
//uint32_t sampleNum;
double dc_offset;

double turn_right_data[20];
double turn_left_data[20];
double turn_around_data[20];
int r_counter;
int l_counter;
int a_counter;

IRSernorsData_InitTypeDef IRSensors_DataStruct;

EncoderData_TypeDef Encoders_DataStruct;

DirectionFlag_TypeDef Direction_FlagStruct;

DirectionData_TypeDef Direction_DataStruct;

USARTBuffer_TypeDef USART_Buffer;

USARTBuffer_TypeDef USART_Buffer2;

MazeData_TypeDef Maze_DataStruct;

ErrorData_TypeDef Error_DataStruct;

L3GD20_TypeDef L3GD20_DataStruct; //L3GD20 MEMS motion sensor: 3-axis digital gyroscope

Time_TypeDef Time_DataStruct;

RTC_TimeTypeDef RTC_TimeStruct;

PidData_TypeDef PID_Regulator[8]; // PID_Regulator[0] - accelerating, PID_Regulator[1] - breaking, PID_Regulator[2] - moving forward, PID_Regulator[3] - turning


DifferentialDrive_TypeDef DifferentialDrive_DataStruct;
float32_t actual_time;
float32_t previous_timeA;
float32_t previous_timeB;

enum Mouse_Status MouseState;
	
//maze array indexes
int8_t actual_position = -1;
//int8_t *wsk_actual_position = &actual_position;

//uint32_t sampleTime = 10;
float32_t prev_rate=0;
//int16_t noise = 1;
float32_t angle;

int tmp;

int32_t i;
int8_t mouse_initialized = 0;
int main(void)
{
	mouse_initialized = 0;
	MouseState = Stop;
	
	/* System Tic initialize */
	/* if (SystemCoreClock / 100) - Delay(5) - 50ms
				(SystemCoreClock / 1000) - Delay(50) - 50ms */
	if (SysTick_Config(SystemCoreClock / 1000)) 
  { 
    /* Catch error */ 
    while (1);
  }
  Delay(20);
	
	SystemInit();
	Delay(20);

	/* USART initialize */
  USART_Initialize();
	Delay(20);
	USART_NVIC_Initialize();
	Delay(20);
	USART_Puts("\r\n********************************************\r\n");
	USART_Puts("\r\tSystem Tic, System, USART Ready\r\n");
	
	EncoderA_EXTI_Initialize();
	Delay(20);
	EncoderB_EXTI_Initialize();
	Delay(20);
	Encoders_DataStruct.previous_bumps = 0;
	USART_Puts("\r\tEncoders Ready\r\n");
	
	TB6612FNG_GPIO_Initialize();
	Delay(20);
	TB6612FNG_PWM_Initialize();
	Delay(20);
	Direction_FlagStruct.dir_flagB = 0;
	Direction_DataStruct.directionA = 0;
	Direction_FlagStruct.dir_flagA = 0;
	Direction_DataStruct.directionB =0;
	USART_Puts("\r\tMotor Driver Ready\r\n");
	
	/* ADC configuration */
  //SE1_ADC_Config();
	//SE2_ADC_Config();
	//SE3_ADC_Config();
	//SE4_ADC_Config();
	SE_ADC_DMA_Initialize(&IRSensors_DataStruct);
	Delay(20);
	USART_Puts("\r\tIR Sensors Ready\r\n");
	
	/* RTC configuration  */
  RTC_Initialize();
	Delay(20);
	
	RTC_WakeUp_InteruptInitialize();
	Delay(20);
	RTC_Enable();
	USART_Puts("\r\tTRC, RTC Timer Ready\r\n");
	
	/*Gyro initialization*/
	if(L3GD20_Initialize(&L3GD20_DataStruct, L3GD20_Scale_2000) != L3GD20_State_Ready) {
		USART_Puts("\r\tL3GD20 gyro Error\r\n");
		while (1);
	}
	USART_Puts("\r\tL3GD20 Gyro Ready\r\n");
	Delay(500);
	
	USART_Puts("\r\n\t\t!!!Micro Mouse Ready\r\n\n");
	
	Button_Initialize();		
	
	BuzzerInit();
	
	//MouseInit(&IRSensors_DataStruct,&Maze_DataStruct, &PID_Regulator[2], &Direction_FlagStruct);
	MouseInit2(&IRSensors_DataStruct);
	
	ResetMouseOrientatioArray(&Maze_DataStruct);

	mouse_initialized = 1;
  while (1)
  {	
		Delay(5);
		if (USART_GetFlagStatus(USART1, USART_FLAG_RXNE)) {
		    USART_Buffer.character = USART_ReceiveData(USART1);
		    switch (USART_Buffer.character)
		    {
				case 'g':
					USART_SendString("\rTest Gyro\r\n");
					angle = 0;
					prev_rate = 0;
					Time_DataStruct.time = 0;
					//RTC_ResetTime(&RTC_TimeStruct);
					//uwTimingDelay = 5;
					time_prev  = 0;

					//time_act = (1000 - (RTC_GetSubSecond()*3.818426197));
						//if(time_act - time_prev > sampleTime){}
					while(1){
						//time_act = (1000 - (RTC_GetSubSecond()*3.818426197));
						if(Time_DataStruct.time > sampleTime){
							//sprintf(USART_Buffer.buffer, "\rTime: %f \n", (time_act - time_prev));
							//USART_Puts(USART_Buffer.buffer);
							time_prev = time_act;

							//time = Time_DataStruct.time;
							Time_DataStruct.time = 0;
							L3GD20_ReadXYZ(&L3GD20_DataStruct);

							//rate = L3GD20_DataStruct.Z/100;
							//sampleNum++;
							//dc_offset = (sampleNum-1)*dc_offset+(1/sampleNum)*(int)gyro.g.z;
							if(L3GD20_DataStruct.Z > noise || L3GD20_DataStruct.Z < -noise){
								angle += ((prev_rate + (float32_t)L3GD20_DataStruct.Z) * (float32_t)sampleTime) / (float32_t)2000;

							// remember the current speed for the next loop rate integration.
								prev_rate = (float32_t)L3GD20_DataStruct.Z;
							}
							// Keep our angle between 0-359 degrees
	//										 if (angle < 0)
	//											angle += 360;
	//										 else if (angle >= 360)
	//											angle -= 360;
							//sprintf(USART_Buffer.buffer, "\rAngle: %f \t Rate: %d\n", angle, L3GD20_DataStruct.Z);
							//USART_Puts(USART_Buffer.buffer);
						}
						if(angle == 0){
							prev_rate = 0;
						}else if(angle == 90){
							prev_rate = 90;
						}
					}
				break;
				case 'y':
					USART_SendString("\rTest Orientation Array\r\n");
					Maze_DataStruct.initial_corner_position = 3;
					while(1){

						//Delay(50);
						if (USART_GetFlagStatus(USART1, USART_FLAG_RXNE)) {
							USART_Buffer.character = USART_ReceiveData(USART1);
							if(USART_Buffer.character == 'r'){
								USART_SendString("\rRotate Right\n");
								RotateMouseOrientatioArray90degRight(&Maze_DataStruct);
								DrawMouseOrientation(&Maze_DataStruct);
							}else if(USART_Buffer.character == 'l'){
								USART_SendString("\rRotate Left\n");
								RotateMouseOrientatioArray90degLeft(&Maze_DataStruct);
								DrawMouseOrientation(&Maze_DataStruct);
							}else if(USART_Buffer.character == 'd'){
								USART_SendString("\rDraw Orientation Array\n");
								DrawMouseOrientation(&Maze_DataStruct);
							}else if(USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == 'b'){
								break;
							}
							//USART_ClearFlag(USART1, USART_FLAG_RXNE);
							//USART_ClearITPendingBit(USART1, USART_FLAG_RXNE);
							USART_Buffer.character = '0';
						}
					}
				break;
				case 'a':
					USART_SendString("\rTest ADC\r\n");
					while(1){

						sprintf(USART_Buffer.buffer, "\rSE1:%4d | SE2:%4d | SE3:%4d | SE4:%4d\n",
							getADCx(&IRSensors_DataStruct, 0),
							getADCx(&IRSensors_DataStruct, 1),
							getADCx(&IRSensors_DataStruct, 2),
							getADCx(&IRSensors_DataStruct, 3)
						);
						USART_Puts(USART_Buffer.buffer);

//						sprintf(USART_Buffer.buffer, "\rSE1:%d | SE2:%d | SE3:%d | SE4:%d\n",
//							IRSensors_DataStruct.SE_value[0],
//							IRSensors_DataStruct.SE_value[1],
//							IRSensors_DataStruct.SE_value[2],
//							IRSensors_DataStruct.SE_value[3]
//						);
//						USART_Puts(USART_Buffer.buffer);
							//tmp = (getADCx(&IRSensors_DataStruct, 0) + getADCx(&IRSensors_DataStruct, 3))*error_to_percent_factor_front/2;
							//sprintf(USART_Buffer.buffer, "\rstop_value_perc is: %d \n", tmp);
							USART_SendString(USART_Buffer.buffer);
						if (USART_GetFlagStatus(USART1, USART_FLAG_RXNE)) break;
					}
				break;
					case 'e':
						USART_SendString("\rTest error\r\n");
						while(1){
							Error_DataStruct.irsensor_front = acceptable_front_wall - (getADCx(&IRSensors_DataStruct, 3) + getADCx(&IRSensors_DataStruct, 0))/2;
							Error_DataStruct.irsensor_side = (getADCx(&IRSensors_DataStruct, 2) - getADCx(&IRSensors_DataStruct, 1));
							sprintf(USART_Buffer.buffer, "\rside error:%6d   |   front error:%6d\n",
								Error_DataStruct.irsensor_side,
								Error_DataStruct.irsensor_front
							);
							USART_Puts(USART_Buffer.buffer);
							if (USART_GetFlagStatus(USART1, USART_FLAG_RXNE)) break;
						}
					break;
						case 'd':
								USART_SendString("\rMotors Test\r\n");
								/* STBY enable */
								GPIO_SetBits(GPIOA, STBY_PIN);
								Delay(5);
								
								MouseState = Stop;
						
								USART_Puts("\rEnter PWM CCR value in % \r\n");
								test_value = USART_geti();
								//sprintf(USART_Buffer.buffer, "\rYour PWM value is: %d perc\n", test_value);
								//USART_SendString(USART_Buffer.buffer);
								sprintf(USART_Buffer.buffer, "\rYour PWM value is: %d \n", CCR_Perc(test_value));
								USART_SendString(USART_Buffer.buffer);
								MouseState = Test;
								//RTC_Enable();
								RTC_WakeUp_InteruptEnable(1);
						
								while(!(USART_ReceiveData(USART1) == 'b')){
									Delay(5);	
									if (USART_GetFlagStatus(USART1, USART_FLAG_RXNE)) {
										USART_Buffer.character = USART_ReceiveData(USART1);
										switch (USART_Buffer.character){
											case 'p':
												sprintf(USART_Buffer.buffer, "\radc & pwm test: %c \n", USART_Buffer.character);
												USART_SendString(USART_Buffer.buffer);
												while(!(USART_ReceiveData(USART1) == 'b')){
													Error_DataStruct.error = 2050 - (getADCx(&IRSensors_DataStruct, 3) + getADCx(&IRSensors_DataStruct, 0))/2;
													LeftMotor(&Direction_FlagStruct, Error_DataStruct.error);
													RightMotor(&Direction_FlagStruct, Error_DataStruct.error);
												}
//												while((getADCx(&IRSensors_DataStruct, 1) + getADCx(&IRSensors_DataStruct, 2))/2 > 600);
//												RightHardStop();
//												LeftHardStop();
//												GPIO_ResetBits(GPIOB, A_IN1);
//												GPIO_ResetBits(GPIOB, A_IN2);
//												GPIO_ResetBits(GPIOB, B_IN1);
//												GPIO_ResetBits(GPIOB, B_IN2);
//												GPIO_SetBits(GPIOB, A_IN1);
												Delay(5);
												break;
											case 'w':
												sprintf(USART_Buffer.buffer, "\rforward: %c \n", USART_Buffer.character);
												USART_SendString(USART_Buffer.buffer);
											
												RightMotor(&Direction_FlagStruct, test_value);
												LeftMotor(&Direction_FlagStruct, test_value);
//												while((getADCx(&IRSensors_DataStruct, 1) + getADCx(&IRSensors_DataStruct, 2))/2 > 600);
//												RightHardStop();
//												LeftHardStop();
//												GPIO_ResetBits(GPIOB, A_IN1);
//												GPIO_ResetBits(GPIOB, A_IN2);
//												GPIO_ResetBits(GPIOB, B_IN1);
//												GPIO_ResetBits(GPIOB, B_IN2);
//												GPIO_SetBits(GPIOB, A_IN1);
												Delay(5);
												break;
											case 'a':
												sprintf(USART_Buffer.buffer, "\rLeft: %c \n", USART_Buffer.character);
												USART_SendString(USART_Buffer.buffer);
												LeftSoftStop();
												RightMotor(&Direction_FlagStruct, test_value);
//												GPIO_ResetBits(GPIOB, A_IN1);
//												GPIO_ResetBits(GPIOB, A_IN2);
//												GPIO_ResetBits(GPIOB, B_IN1);
//												GPIO_ResetBits(GPIOB, B_IN2);
//												GPIO_SetBits(GPIOB, A_IN2);
												Delay(5);
												break;
											case 's':
												sprintf(USART_Buffer.buffer, "\rBackward: %c \n", USART_Buffer.character);
												USART_SendString(USART_Buffer.buffer);
												RightMotor(&Direction_FlagStruct, -test_value);
												LeftMotor(&Direction_FlagStruct, -test_value);
//												GPIO_ResetBits(GPIOB, A_IN1);
//												GPIO_ResetBits(GPIOB, A_IN2);
//												GPIO_ResetBits(GPIOB, B_IN1);
//												GPIO_ResetBits(GPIOB, B_IN2);
//												GPIO_SetBits(GPIOB, B_IN1);
												Delay(5);
												break;
											case 'd':
												sprintf(USART_Buffer.buffer, "\rRight: %c \n", USART_Buffer.character);
												USART_SendString(USART_Buffer.buffer);
												RightSoftStop();
												LeftMotor(&Direction_FlagStruct, test_value);
//												GPIO_ResetBits(GPIOB, A_IN1);
//												GPIO_ResetBits(GPIOB, A_IN2);
//												GPIO_ResetBits(GPIOB, B_IN1);
//												GPIO_ResetBits(GPIOB, B_IN2);
//												GPIO_SetBits(GPIOB, B_IN2);
												Delay(5);
												break;
											case ' ':
												sprintf(USART_Buffer.buffer, "\rStop: '%c' \n", USART_Buffer.character);
												//RightHardStop();
												//LeftHardStop();
												RightBackward(&Direction_FlagStruct, 6);
												LeftBackward(&Direction_FlagStruct, 6);
//												USART_SendString(USART_Buffer.buffer);
//												GPIO_ResetBits(GPIOB, A_IN1);
//												GPIO_ResetBits(GPIOB, A_IN2);
//												GPIO_ResetBits(GPIOB, B_IN1);
//												GPIO_ResetBits(GPIOB, B_IN2);
												Delay(5);
												break;
											default:
												USART_SendString("\rWrong choice\r\n");
												break;
										}
									}
								}
								RightForward(&Direction_FlagStruct, 0);
								LeftForward(&Direction_FlagStruct, 0);
								MouseState = Stop;
								RTC_Disable();
								/* STBY disable */
								GPIO_ResetBits(GPIOA, STBY_PIN);
								Delay(5);	
		            break;								
						case 't':
							USART_SendString("\rMicroMouse turn test\r\n");
						
							/* STBY enable */
							GPIO_SetBits(GPIOA, STBY_PIN);
							Encoders_DataStruct.bumpA = 0;
							Encoders_DataStruct.bumpB = 0;
							Delay(5);
							USART_Puts("\rEnter turn PWM CCR value in %: \r\n");
							*wsk_test_value = USART_geti();
							sprintf(USART_Buffer.buffer, "\rYour turn PWM value is: %d \n", *wsk_test_value);
							USART_SendString(USART_Buffer.buffer);
							
							PidInit(&PID_Regulator[6].PID, gyro_turn_kp, gyro_turn_ki, gyro_turn_kd);
							PidInit(&PID_Regulator[7].PID, gyro_turn_around_kp, gyro_turn_around_ki, gyro_turn_around_kd);
							//PidInsert(&PID_Regulator[7], &USART_Buffer);
						
							//RTC_Enable();
							RTC_WakeUp_InteruptEnable(1);
						
							while(!(USART_ReceiveData(USART1) == 'b')){
							Delay(5);	
								if (USART_GetFlagStatus(USART1, USART_FLAG_RXNE)) {
									USART_Buffer.character = USART_ReceiveData(USART1);
									switch (USART_Buffer.character){
										case 'j':
											USART_SendString("\rRight: \n");																			
											while(!(USART_ReceiveData(USART1) == 'b')){
										
												//sprintf(USART_Buffer.buffer, "\rError: %f\n", arm_pid_f32(&IRSensors_DataStruct.PID, 100 - (float)getADCx(&IRSensors_DataStruct, 2) - (float)getADCx(&IRSensors_DataStruct, 1)));USART_SendString(USART_Buffer.buffer);

											}
//											LeftForward(&Direction_FlagStruct, *wsk_test_value);
//											RightBackward(&Direction_FlagStruct, *wsk_test_value);
//											Turn90DegreesRight(&Encoders_DataStruct, wsk_test_value);
											//Delay(5);
											break;
										case 'r':
											USART_SendString("\rTurn right: \n");	
												//sprintf(USART_Buffer.buffer, "\rTurn right: %c \n", USART_Buffer.character);
												//USART_SendString(USART_Buffer.buffer);
											
											Time_DataStruct.time = 0;
											L3GD20_DataStruct.angle = 0;
											L3GD20_DataStruct.prev_rate = 0;
											//PidInsert(&PID_Regulator[3], &USART_Buffer);
											//Time_DataStruct.time = 0;
											//L3GD20_DataStruct.angle = 0;
											//L3GD20_DataStruct.prev_rate = 0;
											MouseState = TurnRight;
											//TurnRight90Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &PID_Regulator[3], &Direction_FlagStruct, test_value);
											//Delay(5);
										break;
										case 'l':
											USART_SendString("\rTurn left: \n");	
												//sprintf(USART_Buffer.buffer, "\rTurn right: %c \n", USART_Buffer.character);
												//USART_SendString(USART_Buffer.buffer);
											//PidInit(&PID_Regulator[3].PID, turn_kp, turn_ki, turn_kd); 
											//PidInsert(&PID_Regulator[3], &USART_Buffer);
//											Time_DataStruct.time = 0;
//											L3GD20_DataStruct.angle = 0;
//											L3GD20_DataStruct.prev_rate = 0;
											Time_DataStruct.time = 0;
											L3GD20_DataStruct.angle = 0;
											L3GD20_DataStruct.prev_rate = 0;
											MouseState = TurnLeft;
											//TurnLeft90Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &PID_Regulator[3], &Direction_FlagStruct, test_value);
											//Delay(5);
										break;
										
										case 'd':
											USART_SendString("\rTurn around right: \n");	
												//sprintf(USART_Buffer.buffer, "\rTurn right: %c \n", USART_Buffer.character);
												//USART_SendString(USART_Buffer.buffer);
											
											Time_DataStruct.time = 0;
											L3GD20_DataStruct.angle = 0;
											L3GD20_DataStruct.prev_rate = 0;
											//PidInsert(&PID_Regulator[3], &USART_Buffer);
											//Time_DataStruct.time = 0;
											//L3GD20_DataStruct.angle = 0;
											//L3GD20_DataStruct.prev_rate = 0;
											MouseState = TurnAroundRight;
											//TurnRight90Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &PID_Regulator[3], &Direction_FlagStruct, test_value);
											//Delay(5);
										break;
										case 'a':
											USART_SendString("\rTurn around left: \n");	
												//sprintf(USART_Buffer.buffer, "\rTurn right: %c \n", USART_Buffer.character);
												//USART_SendString(USART_Buffer.buffer);
											//PidInit(&PID_Regulator[3].PID, turn_kp, turn_ki, turn_kd); 
											//PidInsert(&PID_Regulator[3], &USART_Buffer);
//											Time_DataStruct.time = 0;
//											L3GD20_DataStruct.angle = 0;
//											L3GD20_DataStruct.prev_rate = 0;
											Time_DataStruct.time = 0;
											L3GD20_DataStruct.angle = 0;
											L3GD20_DataStruct.prev_rate = 0;
											MouseState = TurnAroundLeft;
											//TurnLeft90Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &PID_Regulator[3], &Direction_FlagStruct, test_value);
											//Delay(5);
										break;
										
										case 's':
											USART_SendString("\rTest: \n");
											//*wsk_test_value = 30;
											//USART_Puts("\rwsk_test_value: \n");*wsk_test_value = USART_geti();
											MouseState = Forward;
											/* STBY enable */
											GPIO_SetBits(GPIOA, STBY_PIN);
											//Encoders_DataStruct.bumpA = 0;
											//Encoders_DataStruct.bumpB = 0;

											//FillMaze(&Maze_DataStruct);					

											//ResetMaze(&Maze_DataStruct);
											
											Delay(1000);
											PidInit(&PID_Regulator[0].PID, accelerate_kp, accelerate_ki, accelerate_kd);
											PidInit(&PID_Regulator[1].PID, break_kp, break_ki, break_kd); 
											PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki, forward_kd); 
											while(!(USART_ReceiveData(USART1) == 'b')){
												//Error_DataStruct.error = acceptable_front_wall - (getADCx(&IRSensors_DataStruct, 3) + getADCx(&IRSensors_DataStruct, 0))/2;
												//Error_DataStruct.error_pid_correction = ReturnPidError(&IRSensors_DataStruct.PID, (float)Error_DataStruct.error, -25, 25, ready_error_corrctor_front);
												sprintf(USART_Buffer.buffer, "\r%d\n", (int)Error_DataStruct.error_pid_correction_side);USART_Puts(USART_Buffer.buffer);
												//Delay(10);
												//free (USART_Buffer.buffer);
												if (USART_GetFlagStatus(USART1, USART_FLAG_RXNE)) {
													if (USART_ReceiveData(USART1) == 'b') break;
													MouseState = Stop;
													LeftMotor(&Direction_FlagStruct, -5);
													RightMotor(&Direction_FlagStruct, -5);		
													
													//PidInsert(&PID_Regulator[0], &USART_Buffer);
													//PidInsert(&PID_Regulator[1], &USART_Buffer);
													PidInsert(&PID_Regulator[2], &USART_Buffer);

														//sprintf(USART_Buffer.buffer, "\r\nValue: %f\n", USART_geti());USART_SendString(USART_Buffer.buffer);
														//Delay(2000);
													MouseState = Forward;
												}
											}
											*wsk_test_value = 0;
											GPIO_ResetBits(GPIOA, STBY_PIN);
											
											Delay(5);
											break;
//										case 'a':
//											USART_SendString("\rLeft: \n");
//												Encoders_DataStruct.bumpA = 0;
//												Encoders_DataStruct.bumpB = 0;
//												RightForward(&Direction_FlagStruct, 6);
//												LeftForward(&Direction_FlagStruct, 6);
////											RightForward(&Direction_FlagStruct, *wsk_test_value);
////											LeftBackward(&Direction_FlagStruct, *wsk_test_value);
////											Turn90DegreesLeft(&Encoders_DataStruct, wsk_test_value);
//											//Delay(5);
//											break;
//										case 'e':
//											USART_SendString("\rRight one wheel: \n");
////											RightForward(&Direction_FlagStruct, *wsk_test_value);
////											LeftBackward(&Direction_FlagStruct, *wsk_test_value);
////											Turn90DegreesRightOneWheel(&Encoders_DataStruct, wsk_test_value);
//											//Delay(5);
//											break;
//										case 'q':
//											USART_SendString("\rLeft one wheel: \n");
////											RightForward(&Direction_FlagStruct, *wsk_test_value);
////											LeftBackward(&Direction_FlagStruct, *wsk_test_value);
////											Turn90DegreesLeftOneWheel(&Encoders_DataStruct, wsk_test_value);
//											//Delay(5);
//											break;
//										case 'c':
//											USART_SendString("\rLeft one wheel: \n");
////											RightForward(&Direction_FlagStruct, *wsk_test_value);
////											LeftBackward(&Direction_FlagStruct, *wsk_test_value);
////											DriveDistance(&IRSensors_DataStruct, &Encoders_DataStruct, &Error_DataStruct, USART_geti(), *wsk_test_value);
//											//Delay(5);
//											break;
//										case 'u':
//											USART_SendString("\rAround: %c \n");
//										
//											break;
//										case 's':
//											USART_SendString("\rSpy Wall: \n");
//											while(!(USART_ReceiveData(USART1) == 'b')){
//												USART_Puts("\rEnter Pf, If, Df %: \r\n");
//												PidInit(&IRSensors_DataStruct.PID, USART_geti(), USART_geti(), USART_geti());
//												while(!(USART_ReceiveData(USART1) == 'k')){
//													SpyWall(&IRSensors_DataStruct, &Error_DataStruct, *wsk_test_value);
//												}
//											}
//											break;
										default:
											USART_SendString("\rWrong choice\r\n");
											break;
									}
								}
								//Encoders_DataStruct.bumpA = 0;
								//Encoders_DataStruct.bumpB = 0;
							}
							RTC_Disable();
							GPIO_ResetBits(GPIOA, STBY_PIN);
							break;
						case 'm':
							USART_SendString("\rMicromouse System\r\n");
							sprintf(USART_Buffer.buffer, "\rMaze_DataStruct.SE_middle_value: %d \n", IRSensors_DataStruct.SE_middle_value);USART_SendString(USART_Buffer.buffer);
							
							*wsk_test_value = 700;
							DifferentialDrive_DataStruct.maxCCRpulse = *wsk_test_value;
							/* STBY enable */
							GPIO_SetBits(GPIOA, STBY_PIN);
							//RTC_WakeUp_InteruptEnable(0.01);
							//PidInit(&PID_Regulator[0].PID, accelerate_kp, accelerate_ki, accelerate_kd);
							PidInit(&PID_Regulator[1].PID, break_kp, break_ki, break_kd); 
							//PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki, forward_kd);
							//PidInit(&PID_Regulator[3].PID, turn_kp, turn_ki, turn_kd); 					
						
							PID_Regulator[4].kp = 60;
							PID_Regulator[4].ki = 0.1;
							PID_Regulator[4].kd = 5;
							PidInit(&PID_Regulator[4].PID, PID_Regulator[4].kp, PID_Regulator[4].ki, PID_Regulator[4].kd); 
							
							PID_Regulator[2].kp = 0.5;
							PID_Regulator[2].ki = 0;
							PID_Regulator[2].kd = 0;
							PidInit(&PID_Regulator[2].PID, PID_Regulator[2].kp, PID_Regulator[2].ki, PID_Regulator[2].kd);						
							
							//MouseState = Init;
							//MouseInit(&IRSensors_DataStruct,&Maze_DataStruct, &PID_Regulator[2], &Direction_FlagStruct);
							MouseState = Stop;
						
							//PidInsert(&PID_Regulator[2], &USART_Buffer);	
						
							PID_Regulator[5].kp = PID_Regulator[2].kp;
							PID_Regulator[5].ki = PID_Regulator[2].ki;
							PID_Regulator[5].kd = PID_Regulator[2].kd;
							PidInitR(&PID_Regulator[5].PID, PID_Regulator[5].kp, PID_Regulator[5].ki, PID_Regulator[5].kd); 
							
//							PID_Regulator[4].kp = enc_forward_kp;
//							PID_Regulator[4].ki = enc_forward_ki;
//							PID_Regulator[4].kd = enc_forward_kd;
//							PidInit(&PID_Regulator[4].PID, enc_forward_kp, enc_forward_ki, enc_forward_kd); 	
							
							PID_Regulator[6].kp = gyro_turn_kp;
							PID_Regulator[6].ki = gyro_turn_ki;
							PID_Regulator[6].kd = gyro_turn_kd;
							PidInit(&PID_Regulator[6].PID, gyro_turn_kp, gyro_turn_ki, gyro_turn_kd); 	
							//PidInsert(&PID_Regulator[4], &USART_Buffer);
						
							PidInit(&PID_Regulator[6].PID, gyro_turn_kp, gyro_turn_ki, gyro_turn_kd);
							PidInit(&PID_Regulator[7].PID, gyro_turn_around_kp, gyro_turn_around_ki, gyro_turn_around_kd);
						
							//RTC_Enable();
							//RTC_WakeUp_InteruptEnable(0.050);
							PID_Regulator[4].kp = 60;
							PID_Regulator[4].ki = 0.1;
							PID_Regulator[4].kd = 5;
							PidInit(&PID_Regulator[4].PID, PID_Regulator[4].kp, PID_Regulator[4].ki, PID_Regulator[4].kd); 
							
							PID_Regulator[2].kp = 0.5;
							PID_Regulator[2].ki = 0;
							PID_Regulator[2].kd = 0;
							PidInit(&PID_Regulator[2].PID, PID_Regulator[2].kp, PID_Regulator[2].ki, PID_Regulator[2].kd);	

							PID_Regulator[3].kp = 1000;
							PID_Regulator[3].ki = 0;
							PID_Regulator[3].kd = 0;
							PidInit(&PID_Regulator[3].PID, PID_Regulator[3].kp, PID_Regulator[3].ki, PID_Regulator[3].kd);
							//PidInsert(&PID_Regulator[3], &USART_Buffer);
							PidInit(&PID_Regulator[0].PID, PID_Regulator[3].kp, PID_Regulator[3].ki, PID_Regulator[3].kd);
							
							//arm_pid_reset_f32(&PID_Regulator[0].PID);
							//arm_pid_reset_f32(&PID_Regulator[3].PID);	
							
							Delay(3000);

							Maze_DataStruct.N = 8;                       //1 __ 2
							Maze_DataStruct.initial_corner_position = 3; // |__|
							ResetMouseOrientatioArray(&Maze_DataStruct); //4    3

							FillMaze(&Maze_DataStruct);					
							//ResetMaze(&Maze_DataStruct);
							CheckNextFieldOrientation(&Maze_DataStruct);
							
							DrawMaze(&Maze_DataStruct);
							USART_SendString("\n\n");
							DrawMazeWalls(&Maze_DataStruct);	
							USART_SendString("\n\n");
							PresentMazeWalls(&Maze_DataStruct);
							USART_SendString("\n\n");
							


//							Maze_DataStruct.mouse_dir = dir_north;
							//Maze_DataStruct.actual_position = 0;
							//Maze_DataStruct.Y = 15;
							//Maze_DataStruct.X = 15;
							Maze_DataStruct.actual_position = -1;
							Maze_DataStruct.maze_flood[Maze_DataStruct.X][Maze_DataStruct.Y] = 8;


							//AddWall(&IRSensors_DataStruct, &Maze_DataStruct);
							FloodFillMaze(&Maze_DataStruct, Maze_DataStruct.X, Maze_DataStruct.Y, Maze_DataStruct.actual_position, Maze_DataStruct.actual_position + 1);
							Maze_DataStruct.actual_position = Maze_DataStruct.actual_position + 1;
							//Maze_DataStruct.maze_flood[Maze_DataStruct.X][Maze_DataStruct.Y] = Maze_DataStruct.actual_position;

							//Maze_DataStruct.actual_position = 0;
							Maze_DataStruct.mouse_dir = dir_north;

							//ADD WALL
							Maze_DataStruct.maze_wall[Maze_DataStruct.X][Maze_DataStruct.Y] = 0;
							if(getADCx(&IRSensors_DataStruct, 1) >= Rside_wall_present) {
								Maze_DataStruct.maze_wall[Maze_DataStruct.X][Maze_DataStruct.Y] |=  Maze_DataStruct.mouse_east;
								//indeks = indeks + 16;          // teraz indeks pokazuje na segment powyzej
								//mapa[indeks] = mapa[indeks] | SOUTH;
							}

							if(getADCx(&IRSensors_DataStruct, 2) >= Lside_wall_present) {
								Maze_DataStruct.maze_wall[Maze_DataStruct.X][Maze_DataStruct.Y] |=  Maze_DataStruct.mouse_west;
									//indeks = indeks + 1;
									//mapa[indeks] = mapa[indeks] | WEST;
							}

							if((getADCx(&IRSensors_DataStruct, 0) + getADCx(&IRSensors_DataStruct, 3))/2 >= front_wall_present) {
									Maze_DataStruct.maze_wall[Maze_DataStruct.X][Maze_DataStruct.Y] |=  Maze_DataStruct.mouse_north;
									//indeks = indeks + 240;    // r�wnowazne z odjeciem 16
									//mapa[indeks] = mapa[indeks] | NORTH;
							}
							Maze_DataStruct.maze_wall[Maze_DataStruct.X][Maze_DataStruct.Y] |= Maze_DataStruct.mouse_south;
							Maze_DataStruct.maze_wall[Maze_DataStruct.X][Maze_DataStruct.Y] |= start;
							Maze_DataStruct.maze_wall[Maze_DataStruct.X][Maze_DataStruct.Y] |= visited;
							//END ADD WALL
							
							//AddWall(&IRSensors_DataStruct, &Maze_DataStruct);
							//Maze_DataStruct.maze_wall[Maze_DataStruct.X][Maze_DataStruct.Y] |=  Maze_DataStruct.mouse_south;
							
							Encoders_DataStruct.bumpA = 0;
							DifferentialDrive_DataStruct.Da = 2.55;
							Encoders_DataStruct.bumpB = 0;
							DifferentialDrive_DataStruct.Db = 2.55;
							DifferentialDrive_DataStruct.D = 2.55;
							arm_pid_reset_f32(&PID_Regulator[4].PID);
							
							DifferentialDrive_DataStruct.distance_to_drive = 27;
							
							RTC_ResetTime(&RTC_TimeStruct);

//							if(!((Maze_DataStruct.maze_wall[Maze_DataStruct.X][Maze_DataStruct.Y] & wall_north) == wall_north)){
//								//USART_SendString("\rMouseState = Forward\n");
//								MouseState = Forward;
//								Maze_DataStruct.mouse_dir = Maze_DataStruct.north;
//							}else if(!((Maze_DataStruct.maze_wall[Maze_DataStruct.X][Maze_DataStruct.Y] & wall_east) == wall_east)){
//								//USART_SendString("\rMouseState = TurnRight\n");
//								MouseState = TurnRight;
//								Maze_DataStruct.mouse_dir = Maze_DataStruct.east;
//							}else if(!((Maze_DataStruct.maze_wall[Maze_DataStruct.X][Maze_DataStruct.Y] & wall_west) == wall_west)){
//								//USART_SendString("\rMouseState = TurnLeft\n");
//								MouseState = TurnLeft;
//								Maze_DataStruct.mouse_dir = Maze_DataStruct.south;
//							}else {
//								//USART_SendString("\rMouseState = Stop\n");
//								MouseState = Stop;
//								GPIO_ResetBits(BUZZER_PORT, BUZZER_PIN);
//								GPIO_ToggleBits(BUZZER_PORT, BUZZER_PIN);
//								Delay(100);
//								GPIO_ToggleBits(BUZZER_PORT, BUZZER_PIN);
//								Delay(100);
//								GPIO_ToggleBits(BUZZER_PORT, BUZZER_PIN);
//								Delay(100);
//								GPIO_ToggleBits(BUZZER_PORT, BUZZER_PIN);
//								//GPIO_ResetBits(BUZZER_PORT, BUZZER_PIN);
//							}
							MakeDecision(&MouseState, &Encoders_DataStruct, &Direction_FlagStruct, &Maze_DataStruct, &DifferentialDrive_DataStruct);
							
							DrawMaze(&Maze_DataStruct);
							USART_SendString("\n\n");
							DrawMazeWalls(&Maze_DataStruct);	
							USART_SendString("\n\n");
							PresentMazeWalls(&Maze_DataStruct);
							USART_SendString("\n\n");
							
							Time_DataStruct.time = 0;
							L3GD20_DataStruct.angle = 0;
							L3GD20_DataStruct.prev_rate = 0;
							
							//MDrivePath;
							while(!(USART_ReceiveData(USART1) == 'b')){
							}
//								if(MouseState == NewSquare){
//									//Encoders_DataStruct.bumpA = 0;
//									//Encoders_DataStruct.bumpB = 0;
//									MouseState = Stop;
//									
//									GPIO_ToggleBits(BUZZER_PORT, BUZZER_PIN);
//									buzzer_state = 1;
//									buzzer_time = 0;
//									
//									if(Maze_DataStruct.mouse_dir == Maze_DataStruct.north){
//										Maze_DataStruct.Y--;
//									}else if(Maze_DataStruct.mouse_dir == Maze_DataStruct.west){
//										Maze_DataStruct.X--;
//									}else if(Maze_DataStruct.mouse_dir == Maze_DataStruct.east){
//										Maze_DataStruct.X++;
//									}else if(Maze_DataStruct.mouse_dir == Maze_DataStruct.south){
//										Maze_DataStruct.Y++;
//									}
//									//Maze_DataStruct.maze_flood[Maze_DataStruct.X][Maze_DataStruct.Y]++;
//									Maze_DataStruct.actual_position++;
//									Maze_DataStruct.maze_flood[Maze_DataStruct.X][Maze_DataStruct.Y] = Maze_DataStruct.actual_position;
//									
//									AddWall(&IRSensors_DataStruct, &Maze_DataStruct);
//									
//									Time_DataStruct.time = 0;
//									L3GD20_DataStruct.angle = 0;
//									L3GD20_DataStruct.prev_rate = 0;
//									
//									MakeDecision(&MouseState, &Encoders_DataStruct, &Direction_FlagStruct, &Maze_DataStruct);
//								
//									//MouseState = Stop;
//								}
//							
//								while(MouseState == Forward){
//									DriveSuareOneWall(&MouseState, &Encoders_DataStruct, &Maze_DataStruct, &Error_DataStruct, PID_Regulator, &IRSensors_DataStruct, &Direction_FlagStruct, test_value);
//								}
//								while(MouseState == TurnRight){
//									//MakeTurnRight(&MouseState, &Maze_DataStruct, &Error_DataStruct, PID_Regulator, &IRSensors_DataStruct, &Direction_FlagStruct, test_value);
//									TurnRight90Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &Error_DataStruct, &PID_Regulator[6], &Direction_FlagStruct, test_value);		
//								}
//								while(MouseState == TurnLeft){
//									//MakeTurnLeft(&MouseState, &Maze_DataStruct, &Error_DataStruct, PID_Regulator, &IRSensors_DataStruct, &Direction_FlagStruct, test_value);
//									TurnLeft90Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &Error_DataStruct, &PID_Regulator[6], &Direction_FlagStruct, test_value);		
//								}
//								
//								if(MouseState == TurnAround){
//									if(getADCx(&IRSensors_DataStruct, 2) > getADCx(&IRSensors_DataStruct, 1)){
//										//MouseState = TurnAroundRight;
//										while(MouseState == TurnAround){
//											TurnRight180Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &Error_DataStruct, &PID_Regulator[7], &Direction_FlagStruct, test_value);		
//										}
//									}else{
//										//MouseState = TurnAroundLeft;
//										while(MouseState == TurnAround){	
//											TurnLeft180Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &Error_DataStruct, &PID_Regulator[7], &Direction_FlagStruct, test_value);		
//										}										
//									}
//								}
//								
//							};
							GPIO_ResetBits(GPIOA, STBY_PIN);
							RTC_Disable();
							MouseState = Stop;	
								
							DrawMaze(&Maze_DataStruct);
							USART_SendString("\n\n");
							DrawMazeWalls(&Maze_DataStruct);
							USART_SendString("\n\n");
							PresentMazeWalls(&Maze_DataStruct);
							USART_SendString("\n\n");
							
							sprintf(USART_Buffer.buffer, "\r%d\n", (int)Error_DataStruct.error_pid_correction_side);USART_Puts(USART_Buffer.buffer);
							USART_SendString(USART_Buffer.buffer);

							Delay(10);
							*wsk_test_value = 0;
							GPIO_ResetBits(GPIOA, STBY_PIN);
							Delay(5);
							break;
						case 'k':
							USART_SendString("\rMCU KiLlEd\r\n");
							RightForward(&Direction_FlagStruct, 0);
							LeftForward(&Direction_FlagStruct, 0);
							GPIO_ResetBits(GPIOA, STBY_PIN);
							TIM_Cmd(TIM2, DISABLE);
							RTC_Disable();
							I2C_Cmd(I2C1, DISABLE);
							ADC_DMACmd(SE_ADC, DISABLE);
							ADC_Cmd(SE_ADC, DISABLE);
							USART_SendString("\rMCU OFF\r\n");
							USART_Cmd(USART1, DISABLE); 
							return 0;
		        default:
							LeftMotor(&Direction_FlagStruct, -stop_ccr);
							RightMotor(&Direction_FlagStruct, stop_ccr);
							MouseState = Stop;
							USART_SendString("\rPause\r\n");
							break;
			//USART_Buffer.character = '0';
		    }
			}else if(!GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13)){
				//*wsk_test_value = 30;
				USART_Puts("\rwsk_test_value: \n");*wsk_test_value = USART_geti();
				MouseState = Test;
				/* STBY enable */
				GPIO_SetBits(GPIOA, STBY_PIN);
				//Encoders_DataStruct.bumpA = 0;
				//Encoders_DataStruct.bumpB = 0;

				//FillMaze(&Maze_DataStruct);					

				//ResetMaze(&Maze_DataStruct);
				
				Delay(1000);
				PidInit(&PID_Regulator[0].PID, accelerate_kp, accelerate_ki, accelerate_kd);
				PidInit(&PID_Regulator[1].PID, break_kp, break_ki, break_kd); 
				PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki, forward_kd); 
				while(1){
						//Error_DataStruct.error = acceptable_front_wall - (getADCx(&IRSensors_DataStruct, 3) + getADCx(&IRSensors_DataStruct, 0))/2;
						//Error_DataStruct.error_pid_correction = ReturnPidError(&IRSensors_DataStruct.PID, (float)Error_DataStruct.error, -25, 25, ready_error_corrctor_front);
						sprintf(USART_Buffer.buffer, "\r%d\n", (int)Error_DataStruct.error_pid_correction_side);USART_Puts(USART_Buffer.buffer);
						//Delay(10);
						//free (USART_Buffer.buffer);
					if (USART_GetFlagStatus(USART1, USART_FLAG_RXNE)) {
						MouseState = Stop;
						LeftMotor(&Direction_FlagStruct, -5);
						RightMotor(&Direction_FlagStruct, -5);		
						
						//PidInsert(&PID_Regulator[0], &USART_Buffer);
						//PidInsert(&PID_Regulator[1], &USART_Buffer);
						PidInsert(&PID_Regulator[2], &USART_Buffer);

							//sprintf(USART_Buffer.buffer, "\r\nValue: %f\n", USART_geti());USART_SendString(USART_Buffer.buffer);
							//Delay(2000);
						MouseState = Test;
					}
					if(!GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13)){
						*wsk_test_value = 0;
						GPIO_ResetBits(GPIOA, STBY_PIN);
						Delay(1000);
						break;
					}
					
				}
			}
  }
}

int8_t read_angle = 0;
void SysTick_Handler(void){
	msTicks++;
	msDelay++;
	Time_DataStruct.time++;
	//Time_DataStruct.vel_time = msTicks;
	buzzer_time++;
	vel_time++;
	

	if(MouseState != DrivePath){
		if(buzzer_state == 1){
			if(buzzer_time >  on_time){
				GPIO_ToggleBits(BUZZER_PORT, BUZZER_PIN);
				buzzer_state = 0;
			}
		}
		
//		if(DifferentialDrive_DataStruct.va || DifferentialDrive_DataStruct.vb) read_angle = 1;
//		else read_angle =0;
	if(L3GD20_DataStruct.GyroState){
		if(Time_DataStruct.time >25) Time_DataStruct.time = 0;
		if(Time_DataStruct.time > sampleTime){
		L3GD20_ReadXYZ(&L3GD20_DataStruct);
		if(L3GD20_DataStruct.Z > noise || L3GD20_DataStruct.Z < -noise){
			L3GD20_DataStruct.angle += ((prev_rate + (float32_t)L3GD20_DataStruct.Z) * (float32_t)Time_DataStruct.time) / (float32_t)2000;
			prev_rate = (float32_t)L3GD20_DataStruct.Z;
		}
			Time_DataStruct.time = 0;
		}
	}
		//	Direction_FlagStruct.dir_flagA = 1;
//	Direction_FlagStruct.dir_flagB = 1;
	
	dt = vel_time - time_prev;
	if(dt >= 2){
	distance_actA = DifferentialDrive_DataStruct.Da;
	DifferentialDrive_DataStruct.va = ((distance_actA - distance_prevA)*1000/(dt));
	distance_prevA = distance_actA;
		
	//DifferentialDrive_DataStruct.aa = (DifferentialDrive_DataStruct.va - velocity_prevA)*1000/(dt);
	//velocity_prevA = DifferentialDrive_DataStruct.va;
		
	
		
	distance_actB = DifferentialDrive_DataStruct.Db;
	DifferentialDrive_DataStruct.vb = ((distance_actB - distance_prevB)*1000/(dt));
	distance_prevB = distance_actB;
		
	time_prev = vel_time;
		
//	if(mouse_initialized){
//		sprintf(USART_Buffer.buffer, "\rdira: %d | Da: %f | dirb: %d | Db: %f\n", Direction_DataStruct.directionA, DifferentialDrive_DataStruct.Da, Direction_DataStruct.directionB, DifferentialDrive_DataStruct.Db);USART_SendString(USART_Buffer.buffer);
//	}
//	if(mouse_initialized){
//		sprintf(USART_Buffer.buffer, "\raa: %f | ab: %f\n", DifferentialDrive_DataStruct.aa, DifferentialDrive_DataStruct.ab);USART_SendString(USART_Buffer.buffer);
//	}
//	if(mouse_initialized){
//		sprintf(USART_Buffer.buffer, "\rva: %f | vb: %f | dirA: %d | dirB: %d\n", DifferentialDrive_DataStruct.va, DifferentialDrive_DataStruct.vb, Direction_DataStruct.directionA, Direction_DataStruct.directionB);USART_SendString(USART_Buffer.buffer);
//	}

//	if((MouseState == DriveDist || MouseState == TurnRight) && ((DifferentialDrive_DataStruct.va == 0) || (DifferentialDrive_DataStruct.vb == 0))){
//		DifferentialDrive_DataStruct.CCRpulseCorrA += 0.05*Direction_DataStruct.directionA;
//		DifferentialDrive_DataStruct.CCRpulseCorrB += 0.05*Direction_DataStruct.directionB;
//	}else{
//		DifferentialDrive_DataStruct.CCRpulseCorrB = 0;
//		DifferentialDrive_DataStruct.CCRpulseCorrA = 0;
//	}
}


//	if(mouse_initialized){
//		if (USART_GetFlagStatus(USART1, USART_FLAG_RXNE)) {
//			USART_SendString("\n\r");
//		    //USART_Buffer.character = USART_ReceiveData(USART1);
//				Direction_FlagStruct.dir_flagB = USART_geti();
//			Direction_FlagStruct.dir_flagA = Direction_FlagStruct.dir_flagB;
//			//USART_SendString("/n/r");
//		}
//	}
	
	dir_flag_actA = Direction_FlagStruct.dir_flagA;
	if((dir_flag_actA != Direction_DataStruct.directionA) && (DifferentialDrive_DataStruct.va == 0)){
		Direction_DataStruct.directionA = dir_flag_actA;
	}
	
	dir_flag_actB = Direction_FlagStruct.dir_flagB;
	if((dir_flag_actB != Direction_DataStruct.directionB) && (DifferentialDrive_DataStruct.vb == 0)){
		Direction_DataStruct.directionB = dir_flag_actB;
	}
		
		if(MouseState == NewSquare){
			//Encoders_DataStruct.bumpA = 0;
			//Encoders_DataStruct.bumpB = 0;
			MouseState = Stop;
			
			GPIO_ToggleBits(BUZZER_PORT, BUZZER_PIN);
			buzzer_state = 1;
			buzzer_time = 0;
			
//			if(Maze_DataStruct.mouse_orientation[DirN] == north){
//				Maze_DataStruct.Y--;
//			}else if(Maze_DataStruct.mouse_orientation[DirN] == west){
//				Maze_DataStruct.X--;
//			}else if(Maze_DataStruct.mouse_orientation[DirN] == east){
//				Maze_DataStruct.X++;
//			}else if(Maze_DataStruct.mouse_orientation[DirN] == south){
//				Maze_DataStruct.Y++;
//			}
			CheckNextFieldOrientation(&Maze_DataStruct);

			Maze_DataStruct.X = Maze_DataStruct.X + Maze_DataStruct.nextX;
			Maze_DataStruct.Y = Maze_DataStruct.Y + Maze_DataStruct.nextY;
			

//			if(Maze_DataStruct.mouse_dir == dir_north){
//				Maze_DataStruct.Y--;
//			}else if(Maze_DataStruct.mouse_dir == dir_west){
//				Maze_DataStruct.X--;
//			}else if(Maze_DataStruct.mouse_dir == dir_east){
//				Maze_DataStruct.X++;
//			}else if(Maze_DataStruct.mouse_dir == dir_south){
//				Maze_DataStruct.Y++;
//			}
			//Maze_DataStruct.maze_flood[Maze_DataStruct.X][Maze_DataStruct.Y]++;
			//Maze_DataStruct.actual_position = Maze_DataStruct.actual_position + 1;

			//Maze_DataStruct.maze_flood[Maze_DataStruct.X][Maze_DataStruct.Y] = Maze_DataStruct.actual_position;
			

			AddWall(&IRSensors_DataStruct, &Maze_DataStruct);
			
			FloodFillMaze(&Maze_DataStruct, Maze_DataStruct.X, Maze_DataStruct.Y, Maze_DataStruct.actual_position, Maze_DataStruct.actual_position + 1);
			Maze_DataStruct.actual_position = Maze_DataStruct.actual_position + 1;

			Time_DataStruct.time = 0;
			L3GD20_DataStruct.angle = 0;
			L3GD20_DataStruct.prev_rate = 0;
			
			Encoders_DataStruct.bumpA = 0;
			DifferentialDrive_DataStruct.Da -= 18;
			Encoders_DataStruct.bumpB = 0;
			DifferentialDrive_DataStruct.Db -= 18;
			DifferentialDrive_DataStruct.D -= 18;
			
			MakeDecision(&MouseState, &Encoders_DataStruct, &Direction_FlagStruct, &Maze_DataStruct, &DifferentialDrive_DataStruct);
		
			//MouseState = Stop;
		}
		
		if(MouseState == TurnAround){
			if(getADCx(&IRSensors_DataStruct, 2) > getADCx(&IRSensors_DataStruct, 1)){
				MouseState = TurnAroundRight;
		}else{
				MouseState = TurnAroundLeft;		
			}
			//USART_SendString("\rCYCE\n");
			//sprintf(USART_Buffer.buffer, "\rMaze_DataStruct.SE_middle_value: %d \n", Maze_DataStruct.SE_middle_value);USART_SendString(USART_Buffer.buffer);
	//		if(getADCx(&IRSensors_DataStruct, 2) > getADCx(&IRSensors_DataStruct, 1)){
	//			L3GD20_DataStruct.angle = 0;
	//			L3GD20_DataStruct.prev_rate = 0;
	//			MouseState = TurnRight;
	//			//TurnLeft90Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &PID_Regulator[3], test_value);
	//		}else{
	//			L3GD20_DataStruct.angle = 0;
	//			L3GD20_DataStruct.prev_rate = 0;
	//			MouseState = TurnLeft;
	//			//TurnRight90Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &PID_Regulator[3], test_value);
	//		}
	//		//MouseState = Forward;
//		}else if(MouseState == DriveDist){
//				DriveDistance(&MouseState, &DifferentialDrive_DataStruct, &IRSensors_DataStruct, PID_Regulator, &Direction_FlagStruct);
//		}else if(MouseState == Forward){
			//if(MouseState == TurnRight){
				//TurnRight90Degrees();
			//}
			//SpyWall(&IRSensors_DataStruct, PID_Regulator, &Error_DataStruct, test_value);
			//FloodMaze(MouseState, &Error_DataStruct, PID_Regulator, &IRSensors_DataStruct, test_value);
			//USART_SendString("\rForward\r\n");
			//FollowTheWall(&MouseState, &Maze_DataStruct, &Error_DataStruct, PID_Regulator, &IRSensors_DataStruct, test_value);
			FollowOneWall(&MouseState, &Maze_DataStruct, &Error_DataStruct, PID_Regulator, &IRSensors_DataStruct, &Direction_FlagStruct, test_value);
			
			//DriveSuareOneWall(&MouseState, &Encoders_DataStruct, &Maze_DataStruct, &Error_DataStruct, PID_Regulator, &IRSensors_DataStruct, &Direction_FlagStruct, test_value);
			//DriveForward(&IRSensors_DataStruct, &Error_DataStruct, test_value);
		}else if(MouseState == Decide){
			if(abs(getADCx(&IRSensors_DataStruct, 2) - getADCx(&IRSensors_DataStruct, 1)) > high_error_level){
				if(getADCx(&IRSensors_DataStruct, 2) > getADCx(&IRSensors_DataStruct, 1)){
					MouseState = TurnRight;
					Maze_DataStruct.mouse_dir = dir_east;
				}else{
					MouseState = TurnLeft;
					Maze_DataStruct.mouse_dir = dir_west;
				}
			}
		}else if(MouseState == TurnRight){
			RightTurn(&MouseState, &DifferentialDrive_DataStruct, &IRSensors_DataStruct, PID_Regulator, &Direction_FlagStruct);
			//MakeTurnRight(&MouseState, &Maze_DataStruct, &Error_DataStruct, PID_Regulator, &IRSensors_DataStruct, &Direction_FlagStruct, test_value);
			//TurnRight90Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &Error_DataStruct, &PID_Regulator[6], &Direction_FlagStruct, test_value);		
		}else if(MouseState == TurnLeft){
			LeftTurn(&MouseState, &DifferentialDrive_DataStruct, &IRSensors_DataStruct, PID_Regulator, &Direction_FlagStruct);
			//MakeTurnLeft(&MouseState, &Maze_DataStruct, &Error_DataStruct, PID_Regulator, &IRSensors_DataStruct, &Direction_FlagStruct, test_value);
			//TurnLeft90Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &Error_DataStruct, &PID_Regulator[6], &Direction_FlagStruct, test_value);		
		}else if(MouseState == TurnAroundRight){
			//MakeTurnAroundGyro(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &Maze_DataStruct, &Error_DataStruct, PID_Regulator, &IRSensors_DataStruct, test_value); 
			//MakeTurnAroundRight(&MouseState, &Maze_DataStruct, &Error_DataStruct, PID_Regulator, &IRSensors_DataStruct, &Direction_FlagStruct, test_value);
			//TurnLeft90Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &PID_Regulator[3], &Direction_FlagStruct, test_value);		
			TurnRight180Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &Error_DataStruct, &PID_Regulator[7], &Direction_FlagStruct, test_value);		
		}else if(MouseState == DriveDist){
				DriveDistance(&MouseState, &DifferentialDrive_DataStruct, &IRSensors_DataStruct, PID_Regulator, &Direction_FlagStruct);
		}else if(MouseState == TurnAroundLeft){
			AroundLeftTurn(&MouseState, &DifferentialDrive_DataStruct, &IRSensors_DataStruct, PID_Regulator, &Direction_FlagStruct);
			//MakeTurnAroundGyro(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &Maze_DataStruct, &Error_DataStruct, PID_Regulator, &IRSensors_DataStruct, test_value); 
			//MakeTurnAroundLeft(&MouseState, &Maze_DataStruct, &Error_DataStruct, PID_Regulator, &IRSensors_DataStruct, &Direction_FlagStruct, test_value);
			//TurnLeft180Degrees(&MouseState, &L3GD20_DataStruct, &Time_DataStruct, &Error_DataStruct, &PID_Regulator[7], &Direction_FlagStruct, test_value);		
		}else if(MouseState == Stop){
			LeftMotor(&Direction_FlagStruct, -stop_ccr);
			RightMotor(&Direction_FlagStruct, -stop_ccr);
			
			if((DifferentialDrive_DataStruct.va == 0) && (DifferentialDrive_DataStruct.vb == 0)){
				//GPIO_ResetBits(GPIOA, STBY_PIN);
				Direction_FlagStruct.dir_flagA = 0;
				Direction_DataStruct.directionA = 0;
				Direction_FlagStruct.dir_flagB = 0;
				Direction_DataStruct.directionB = 0;
				LeftHardStop();
				RightHardStop();
			}
			//Direction_FlagStruct.dir_flagA = 1;
		}else if(MouseState == Test){
	//		Time_DataStruct.time = 0;
	//		L3GD20_DataStruct.angle = 0;
	//		L3GD20_DataStruct.prev_rate = 0;
	//		MouseState = TurnLeft;
				
		}
	}else{
		if(buzzer_state == 1){
			if(buzzer_time >  on_time){
				GPIO_ToggleBits(BUZZER_PORT, BUZZER_PIN);
				buzzer_state = 0;
			}
		}
	}
	
//	if((DifferentialDrive_DataStruct->va == 0) || (DifferentialDrive_DataStruct->vb == 0)){
//		DifferentialDrive_DataStruct->CCRpulseCorrA += 0.05*Direction_DataStruct->directionA;
//		DifferentialDrive_DataStruct->CCRpulseCorrB += 0.05*Direction_DataStruct->directionB;
//	}else{
//		DifferentialDrive_DataStruct->CCRpulseCorrB = 0;
//		DifferentialDrive_DataStruct->CCRpulseCorrA = 0;
//	}
	

	


	
	if(mouse_initialized == 2){
		if (USART_GetFlagStatus(USART1, USART_FLAG_RXNE)) {
			USART_SendString("\n\rDriveDistance\n");
			//DifferentialDrive_DataStruct.distance_to_drive = USART_geti();
			arm_pid_reset_f32(&PID_Regulator[4].PID);
			DifferentialDrive_DataStruct.Da = 0;
			Encoders_DataStruct.bumpA = 0;
			DifferentialDrive_DataStruct.Db = 0;
			Encoders_DataStruct.bumpB = 0;
			DifferentialDrive_DataStruct.D = 0;
			DifferentialDrive_DataStruct.distance_to_drive = 18;
			
			DifferentialDrive_DataStruct.maxCCRpulse = 700;
			
			USART_Buffer.character = USART_ReceiveData(USART1);
			if(USART_Buffer.character == 'q'){
				PidInsert(&PID_Regulator[4], &USART_Buffer);
				GPIO_SetBits(GPIOA, STBY_PIN);
				MouseState = DriveDist;
				
				USART_SendString("\n\r");
			}else if(USART_Buffer.character == 'w'){
				PID_Regulator[4].kp = 60;
				PID_Regulator[4].ki = 0.1;
				PID_Regulator[4].kd = 5;
				//PidInit(&PID_Regulator[4].PID, PID_Regulator[4].kp, PID_Regulator[4].ki, PID_Regulator[4].kd); 	
				PidInsert(&PID_Regulator[2], &USART_Buffer);
				GPIO_SetBits(GPIOA, STBY_PIN);
				MouseState = DriveDist;
				USART_SendString("\n\r");
			}else if(USART_Buffer.character == 'e'){
				USART_SendString("\n\rBetween the wall ready\n");
				PID_Regulator[4].kp = 60;
				PID_Regulator[4].ki = 0.1;
				PID_Regulator[4].kd = 5;
				PidInit(&PID_Regulator[4].PID, PID_Regulator[4].kp, PID_Regulator[4].ki, PID_Regulator[4].kd); 
				
				PID_Regulator[2].kp = 0.5;
				PID_Regulator[2].ki = 0;
				PID_Regulator[2].kd = 0;
				PidInit(&PID_Regulator[2].PID, PID_Regulator[2].kp, PID_Regulator[2].ki, PID_Regulator[2].kd);
				
				GPIO_SetBits(GPIOA, STBY_PIN);
				MouseState = DriveDist;
			}else if(USART_Buffer.character == 'f'){
				USART_SendString("\n\rBetween the wall ready\n");
				PidInsert(&PID_Regulator[4], &USART_Buffer);
				
				PID_Regulator[2].kp = 0.5;
				PID_Regulator[2].ki = 0;
				PID_Regulator[2].kd = 0;
				PidInit(&PID_Regulator[2].PID, PID_Regulator[2].kp, PID_Regulator[2].ki, PID_Regulator[2].kd);
				
				GPIO_SetBits(GPIOA, STBY_PIN);
				MouseState = DriveDist;
			}else if(USART_Buffer.character == 'x'){
				//arm_pid_reset_f32(&PID_Regulator->PID);
				//PidInit(&PID_Regulator->PID, 0, 0, 0);
				PID_Regulator[3].kp = 95;
				PID_Regulator[3].ki = 1;
				PID_Regulator[3].kd = 10;
				PidInsert(&PID_Regulator[3], &USART_Buffer);
				PidInit(&PID_Regulator[3].PID, PID_Regulator[3].kp, PID_Regulator[3].ki, PID_Regulator[3].kd);
				PidInit(&PID_Regulator[0].PID, PID_Regulator[3].kp, PID_Regulator[3].ki, PID_Regulator[3].kd);
				arm_pid_reset_f32(&PID_Regulator[0].PID);
				arm_pid_reset_f32(&PID_Regulator[3].PID);
				DifferentialDrive_DataStruct.Da = 0;
				Encoders_DataStruct.bumpA = 0;
				DifferentialDrive_DataStruct.Db = 0;
				Encoders_DataStruct.bumpB = 0;
				DifferentialDrive_DataStruct.D = 0;
				//DifferentialDrive_DataStruct.distance_to_drive = 18;
				DifferentialDrive_DataStruct.distance_to_driveA = -5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
				DifferentialDrive_DataStruct.distance_to_driveB  = 5.340707511;
				GPIO_SetBits(GPIOA, STBY_PIN);
				MouseState = TurnRight;			
			}else if(USART_Buffer.character == 'z'){
				//arm_pid_reset_f32(&PID_Regulator->PID);
				//PidInit(&PID_Regulator->PID, 0, 0, 0);
				PID_Regulator[3].kp = 95;
				PID_Regulator[3].ki = 1;
				PID_Regulator[3].kd = 10;
				PidInsert(&PID_Regulator[3], &USART_Buffer);
				PidInit(&PID_Regulator[3].PID, PID_Regulator[3].kp, PID_Regulator[3].ki, PID_Regulator[3].kd);
				PidInit(&PID_Regulator[0].PID, PID_Regulator[3].kp, PID_Regulator[3].ki, PID_Regulator[3].kd);
				
				arm_pid_reset_f32(&PID_Regulator[0].PID);
				arm_pid_reset_f32(&PID_Regulator[3].PID);
				
				DifferentialDrive_DataStruct.Da = 0;
				Encoders_DataStruct.bumpA = 0;
				DifferentialDrive_DataStruct.Db = 0;
				Encoders_DataStruct.bumpB = 0;
				DifferentialDrive_DataStruct.D = 0;
				//DifferentialDrive_DataStruct.distance_to_drive = 18;
				DifferentialDrive_DataStruct.distance_to_driveA = 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
				DifferentialDrive_DataStruct.distance_to_driveB  = -5.340707511;
				GPIO_SetBits(GPIOA, STBY_PIN);
				MouseState = TurnLeft;				
			}else if(USART_Buffer.character == 'v'){
				//arm_pid_reset_f32(&PID_Regulator->PID);
				//PidInit(&PID_Regulator->PID, 0, 0, 0);
				PID_Regulator[3].kp = 950;
				PID_Regulator[3].ki = 0.2;
				PID_Regulator[3].kd = 1000;
				PidInsert(&PID_Regulator[3], &USART_Buffer);
				PidInit(&PID_Regulator[3].PID, PID_Regulator[3].kp, PID_Regulator[3].ki, PID_Regulator[3].kd);
				PidInit(&PID_Regulator[0].PID, PID_Regulator[3].kp, PID_Regulator[3].ki, PID_Regulator[3].kd);
				
				arm_pid_reset_f32(&PID_Regulator[0].PID);
				arm_pid_reset_f32(&PID_Regulator[3].PID);
				
				DifferentialDrive_DataStruct.Da = 0;
				Encoders_DataStruct.bumpA = 0;
				DifferentialDrive_DataStruct.Db = 0;
				Encoders_DataStruct.bumpB = 0;
				DifferentialDrive_DataStruct.D = 0;
				//DifferentialDrive_DataStruct.distance_to_drive = 18;
				DifferentialDrive_DataStruct.distance_to_driveA = -10.68141502;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
				DifferentialDrive_DataStruct.distance_to_driveB  = 10.68141502;
				GPIO_SetBits(GPIOA, STBY_PIN);
				MouseState = TurnRight;	
			}else if(USART_Buffer.character == 'c'){
				//arm_pid_reset_f32(&PID_Regulator->PID);
				//PidInit(&PID_Regulator->PID, 0, 0, 0);
				PID_Regulator[3].kp = 950;
				PID_Regulator[3].ki = 0.2;
				PID_Regulator[3].kd = 1000;
				PidInsert(&PID_Regulator[3], &USART_Buffer);
				PidInit(&PID_Regulator[3].PID, PID_Regulator[3].kp, PID_Regulator[3].ki, PID_Regulator[3].kd);
				PidInit(&PID_Regulator[0].PID, PID_Regulator[3].kp, PID_Regulator[3].ki, PID_Regulator[3].kd);
				
				arm_pid_reset_f32(&PID_Regulator[0].PID);
				arm_pid_reset_f32(&PID_Regulator[3].PID);
				
				DifferentialDrive_DataStruct.Da = 0;
				Encoders_DataStruct.bumpA = 0;
				DifferentialDrive_DataStruct.Db = 0;
				Encoders_DataStruct.bumpB = 0;
				DifferentialDrive_DataStruct.D = 0;
				//DifferentialDrive_DataStruct.distance_to_drive = 18;
				DifferentialDrive_DataStruct.distance_to_driveA = 10.68141502;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
				DifferentialDrive_DataStruct.distance_to_driveB  = -10.68141502;
				GPIO_SetBits(GPIOA, STBY_PIN);
				MouseState = TurnLeft;		
			}else if(USART_Buffer.character == 'i'){
				MouseInit(&IRSensors_DataStruct,&Maze_DataStruct, &PID_Regulator[2], &Direction_FlagStruct);
				MouseState = Stop;		
			}
	
			if(USART_Buffer.character == 'b'){
					MouseState = Stop;	
			}
			//USART_SendString("\n\r");
		}
		//sprintf(USART_Buffer.buffer, "\rDa: %f | transA: %f | Db: %f | transB: %f | D: %f \n", DifferentialDrive_DataStruct.Da, DifferentialDrive_DataStruct.trans_pd_regulatorA, DifferentialDrive_DataStruct.Db, DifferentialDrive_DataStruct.trans_pd_regulatorB, DifferentialDrive_DataStruct.D);USART_SendString(USART_Buffer.buffer);
		sprintf(USART_Buffer.buffer, "\rDa: %f | Db: %f | D: %f | trans: %f | rot: %f\n", DifferentialDrive_DataStruct.Da, DifferentialDrive_DataStruct.Db, DifferentialDrive_DataStruct.D, DifferentialDrive_DataStruct.trans_pd_regulator, DifferentialDrive_DataStruct.rot_pd_regulator);USART_SendString(USART_Buffer.buffer);
}
	
	if(msDelay >= 100 && mouse_initialized == 2 && MouseState != Stop){
		sprintf(USART_Buffer.buffer, "\rDa: %f | dtdDa: %f | Db: %f | dtdDB: %f | D: %f | dtdD: %f\n", DifferentialDrive_DataStruct.Da, DifferentialDrive_DataStruct.distance_to_driveA, DifferentialDrive_DataStruct.Db, DifferentialDrive_DataStruct.distance_to_driveB, DifferentialDrive_DataStruct.D, DifferentialDrive_DataStruct.distance_to_drive);USART_SendString(USART_Buffer.buffer);
		msDelay = 0;
	}

//		sprintf(USART_Buffer.buffer, "\rDa: %f | Db: %f | D: %f | trans: %f | rot: %f\n", DifferentialDrive_DataStruct.Da, DifferentialDrive_DataStruct.Db, DifferentialDrive_DataStruct.D, DifferentialDrive_DataStruct.trans_pd_regulator, DifferentialDrive_DataStruct.rot_pd_regulator);USART_SendString(USART_Buffer.buffer);
//	}
//	
//	if(MouseState == TurnLeft || MouseState == TurnRight){
//		//sprintf(USART_Buffer.buffer, "\rDa: %f | Db: %f | D: %f | trans: %f | rot: %f\n", DifferentialDrive_DataStruct.Da, DifferentialDrive_DataStruct.Db, DifferentialDrive_DataStruct.D, DifferentialDrive_DataStruct.trans_pd_regulator, DifferentialDrive_DataStruct.rot_pd_regulator);USART_SendString(USART_Buffer.buffer);
//		sprintf(USART_Buffer.buffer, "\rDa: %f | transA: %f | Db: %f | transB: %f | D: %f \n", DifferentialDrive_DataStruct.Da, DifferentialDrive_DataStruct.trans_pd_regulatorA, DifferentialDrive_DataStruct.Db, DifferentialDrive_DataStruct.trans_pd_regulatorB, DifferentialDrive_DataStruct.D);USART_SendString(USART_Buffer.buffer);
//	}
	//Direction_DataStruct
  TimingDelay_Decrement();
}

void EXTI9_5_IRQHandler(void){
  if(EXTI_GetITStatus(EXTI_Line8) != RESET)
  {
		//L3GD20_DataStruct.GyroState = 1;
		//float32_t actual_time;
//float32_t previous_time;
			//msTicks++;
		//Time_DataStruct.time++;
		//Time_DataStruct.vel_time++;
//		if(Direction_FlagStruct.dir_flagA == 1){
//			Encoders_DataStruct.bumpA++;
//			Encoders_DataStruct.distanceA = Encoders_DataStruct.bumpA * distance_per_bump;
//		}else if(Direction_FlagStruct.dir_flagA == -1){
//			Encoders_DataStruct.bumpA--;
//		}
		
//		Encoders_DataStruct.bumpA++;
//		sprintf(USART_Buffer.buffer, "\rREncoders_DataStruct.bumpA: %d \n", Encoders_DataStruct.bumpA);USART_SendString(USART_Buffer.buffer);
//		//USART_Puts("\rLine 8 is working\r\n"); 
		//Direction_DataStruct.directionA =1;
		Encoders_DataStruct.bumpA += Direction_DataStruct.directionA;
		
		setDa(&DifferentialDrive_DataStruct, Direction_DataStruct.directionA);
		setTheta(&DifferentialDrive_DataStruct);
		setD(&DifferentialDrive_DataStruct);

		setX(&DifferentialDrive_DataStruct);

		//DifferentialDrive_DataStruct.va = (distance_per_bump/(RTC_GetTime_SecondsSubSeconds(&RTC_TimeStruct) - previous_timeA));//*Direction_FlagStruct.dir_flagA;
		previous_timeA = RTC_GetTime_SecondsSubSeconds(&RTC_TimeStruct);
		
//		sprintf(USART_Buffer.buffer, "\rbumpA = %d | Da = %f | D = %f | theta = %f | va = %f | x = %f, y = %f \n", 
//																	Encoders_DataStruct.bumpA, 
//																	DifferentialDrive_DataStruct.Da, 
//																	DifferentialDrive_DataStruct.D, 
//																	DifferentialDrive_DataStruct.theta, 
//																	DifferentialDrive_DataStruct.va, 
//																	DifferentialDrive_DataStruct.x, 
//																	DifferentialDrive_DataStruct.y,
//																	Direction_DataStruct.directionA);
//		USART_SendString(USART_Buffer.buffer);
		
		//USART_Puts("\rLine 8 is working\r\n"); 
		
    EXTI_ClearITPendingBit(EXTI_Line8);
  }
}

int8_t counter;
void EXTI15_10_IRQHandler(void){
  if(EXTI_GetITStatus(EXTI_Line11) != RESET)
  {
		//L3GD20_DataStruct.GyroState = 1;
//		if(Direction_FlagStruct.dir_flagA == 1){
//			Encoders_DataStruct.bumpB++;
//			Encoders_DataStruct.distanceB = Encoders_DataStruct.bumpB * distance_per_bump;
//		}else if(Direction_FlagStruct.dir_flagA == -1){
//			Encoders_DataStruct.bumpB--;
//		}
//		else if(Direction_FlagStruct.dir_flagA == 2 || Direction_FlagStruct.dir_flagA == 3){
//			Encoders_DataStruct.bumpB++;
//		}

		//Encoders_DataStruct.velocity = distance_per_bump/Time_DataStruct.vel_time;
		//Time_DataStruct.vel_time = 0;

//		Encoders_DataStruct.bumpB++;
//	sprintf(USART_Buffer.buffer, "\rLEncoders_DataStruct.bumpB: %d \n", Encoders_DataStruct.bumpB);USART_SendString(USART_Buffer.buffer);
		//USART_Puts("\rLine 11 is working\r\n");
		//	sprintf(USART_Buffer.buffer, "\rLEncoders_DataStruct.bumpB: %d \n", Encoders_DataStruct.bumpB);USART_SendString(USART_Buffer.buffer);
		//USART_Puts("\rLine 11 is working\r\n");
		
		Encoders_DataStruct.bumpB += Direction_DataStruct.directionB;
		
		setDb(&DifferentialDrive_DataStruct, Direction_DataStruct.directionB);
		setTheta(&DifferentialDrive_DataStruct);
		setD(&DifferentialDrive_DataStruct);
		setY(&DifferentialDrive_DataStruct);
		
		//DifferentialDrive_DataStruct.vb = (distance_per_bump/(RTC_GetTime_SecondsSubSeconds(&RTC_TimeStruct) - previous_timeB));//*Direction_FlagStruct.dir_flagB;
		//previous_timeB = RTC_GetTime_SecondsSubSeconds(&RTC_TimeStruct);
		
//		sprintf(USART_Buffer.buffer, "\rbumpB = %d | Db = %f | D = %f | theta = %f | vb = %f | x = %f, y = %f \n", 
//																	Encoders_DataStruct.bumpB, 
//																	DifferentialDrive_DataStruct.Db, 
//																	DifferentialDrive_DataStruct.D, 
//																	DifferentialDrive_DataStruct.theta, 
//																	DifferentialDrive_DataStruct.vb, 
//																	DifferentialDrive_DataStruct.x, 
//																	DifferentialDrive_DataStruct.y,
//																	Direction_DataStruct.directionB);
//		USART_SendString(USART_Buffer.buffer);
				
    EXTI_ClearITPendingBit(EXTI_Line11);
  }
}

/* RTC IRQ handler */
void RTC_WKUP_IRQHandler(void) {
	/* Check for RTC interrupt */
	if (RTC_GetITStatus(RTC_IT_WUT) != RESET) {
		/* Clear interrupt flags */
		RTC_ClearITPendingBit(RTC_IT_WUT);
		/* Do things */
		//Time_DataStruct.vel_time++;
		
		//sprintf(USART_Buffer.buffer, "\n\rpid_l: %f | pid_r: %f \n", Error_DataStruct.error_pid_correction_front_l, Error_DataStruct.error_pid_correction_front_r);USART_SendString(USART_Buffer.buffer);
		sprintf(USART_Buffer.buffer, "\r													bumpA: %d | bumpB: %d \n", Encoders_DataStruct.bumpA, Encoders_DataStruct.bumpB);USART_SendString(USART_Buffer.buffer);
		
		//sprintf(USART_Buffer.buffer, "\n\rgyro_error: %f | angle: %f\n", Error_DataStruct.gyro_error, 	L3GD20_DataStruct.angle);USART_SendString(USART_Buffer.buffer);
		//sprintf(USART_Buffer.buffer, "\r													bumpA: %d | bumpB: %d \n", Encoders_DataStruct.bumpA, Encoders_DataStruct.bumpB);USART_SendString(USART_Buffer.buffer);

		//USART_Puts("\rRTC interrupt\n");
	}
	
	/* Clear EXTI line 22 */
	EXTI_ClearITPendingBit(EXTI_Line22);
}

