#include "MMv4_stm32f4_rtc.h"

/**
  * @brief  Configures the RTC peripheral by selecting the clock source.
  * @param  None
  * @retval None
//  */


void RTC_Initialize(void){
  RTC_TimeTypeDef  RTC_TimeStructure;
  RTC_InitTypeDef RTC_InitStructure;
  
  /* Enable the PWR clock */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);

  /* Allow access to RTC */
  PWR_BackupAccessCmd(ENABLE);
  
  /* Reset RTC Domain */
  RCC_BackupResetCmd(ENABLE);
  RCC_BackupResetCmd(DISABLE);
  
  /* Enable the LSE OSC */
  RCC_LSEConfig(RCC_LSE_ON);

  /* Wait till LSE is ready */  
  while(RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET)
  {
  }

  /* Select the RTC Clock Source */
  RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
  
  /* Configure the RTC data register and RTC prescaler */
  /* ck_spre(1Hz) = RTCCLK(LSI) /(AsynchPrediv + 1)*(SynchPrediv + 1)*/
  RTC_InitStructure.RTC_AsynchPrediv = 0x1F;
  RTC_InitStructure.RTC_SynchPrediv  = 0x3FF;
  RTC_InitStructure.RTC_HourFormat   = RTC_HourFormat_24;
  RTC_Init(&RTC_InitStructure);
  
  /* Set the time to 00h 00mn 00s AM */
  RTC_TimeStructure.RTC_H12     = RTC_H12_AM;
  RTC_TimeStructure.RTC_Hours   = 0;
  RTC_TimeStructure.RTC_Minutes = 0;
  RTC_TimeStructure.RTC_Seconds = 0;  
  RTC_SetTime(RTC_Format_BCD, &RTC_TimeStructure);
  
}

void RTC_Enable(void){
		/* Enable the RTC Clock */
	RCC_RTCCLKCmd(ENABLE);
  
  /* Wait for RTC APB registers synchronisation */
  RTC_WaitForSynchro();
}

/* wake_up_counter:		60 - 60s, 
											30 - 30s, 
											15 - 15s, 
											10 - 10s, 
											 5 - 5s, 
											 2 - 2s, 
											 1 - 1s,
									 0.500 - 500ms,
									 0.250 - 250ms,
									 0.125 - 125ms,
									 0.050 - 50ms,
									 0.020 - 20ms,
									 0.010 - 10ms,
or other value in hex*/
void RTC_WakeUp_InteruptInitialize(void){
  EXTI_InitTypeDef EXTI_InitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  
  /* EXTI configuration */
  EXTI_ClearITPendingBit(EXTI_Line22);
  EXTI_InitStructure.EXTI_Line = EXTI_Line22;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);
  
  /* Enable the RTC Alarm Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = RTC_WKUP_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
	
	RTC_WakeUpCmd(DISABLE);

	/* Clock divided by 8, 32768 / 8 = 4096 */
	/* 4096 ticks for 1second interrupt */
  RTC_WakeUpClockConfig(RTC_WakeUpClock_RTCCLK_Div8);
	
	/* Enable wakeup interrupt */
	RTC_ITConfig(RTC_IT_WUT, ENABLE);
}

void RTC_WakeUp_InteruptEnable(double wake_up_counter){
		USARTBuffer_TypeDef USART_Buffer;
		int counter;	
		if (wake_up_counter == 60) 					counter = 0x3BFFF; 		/* 60 seconds = 60 * 4096 / 1 = 245760 */
		else if (wake_up_counter == 30) 		counter = 0x1DFFF;		/* 30 seconds */
		else if (wake_up_counter == 15) 		counter = 0xEFFF;		/* 15 seconds */
		else if (wake_up_counter == 10) 		counter = 0x9FFF;		/* 10 seconds */
		else if (wake_up_counter == 5) 			counter = 0x4FFF;		/* 5 seconds */
		else if (wake_up_counter == 2) 			counter = 0x1FFF;		/* 2 seconds */
		else if (wake_up_counter == 1) 		 	counter = 0x0FFF;		/* 1 second */
		else if (wake_up_counter == 0.500) 	counter = 0x7FF;		/* 500 ms */
		else if (wake_up_counter == 0.250) 	counter = 0x3FF;		/* 250 ms */
		else if (wake_up_counter == 0.125) 	counter = 0x1FF;		/* 125 ms */
		else if (wake_up_counter == 0.050) 	counter = 0x32;		/* 50 ms */
		else if (wake_up_counter == 0.025) 	counter = 0x19;		/* 25 ms */
		else if (wake_up_counter == 0.010) 	counter = 0xA;			/* 10 ms */
		else{
			USART_Puts("\rWARNING!!! - You inserted own counter value (wake_up_counter must be hex): ");
			counter = wake_up_counter;
			sprintf(USART_Buffer.buffer, "%d \n", counter);
			USART_Puts(USART_Buffer.buffer);
		}			
		
	/* Set RTC wakeup counter */
	RTC_SetWakeUpCounter(counter);
		
	/* Wait for RTC APB registers synchronisation */
  RTC_WaitForSynchro();
		
	/* Enable the wakeup */
	RTC_WakeUpCmd(ENABLE);
}

void RTC_Disable(void){
	/* Disable the RTC Clock */
	RCC_RTCCLKCmd(DISABLE);
		/* Wait for RTC APB registers synchronisation */
  RTC_WaitForSynchro();
}

/**
  * @brief  Returns the current time and sub second.
  * @param  Secondfraction: the sub second fraction.
  * @param  RTC_TimeStructure : pointer to a RTC_TimeTypeDef structure that 
  *         contains the current time values. 
  * @retval time array: return current time and sub second in a table form
  */
Time_TypeDef RTC_Get_Time(RTC_TimeTypeDef* RTC_TimeStructure){
  Time_TypeDef actual_time_data;
	uint32_t Secondfraction = 1000 - ((uint32_t)((uint32_t)RTC_GetSubSecond() * 1000) / (uint32_t)0x3FF);
	
	RTC_GetTime(RTC_Format_BCD, RTC_TimeStructure);

  /* Fill the table fields with the current Time*/
  actual_time_data.time_array[0]   = (((uint8_t)(RTC_TimeStructure->RTC_Hours & 0xF0) >> 0x04) + 0x30);
  actual_time_data.time_array[1]   = (((uint8_t)(RTC_TimeStructure->RTC_Hours & 0x0F))+ 0x30);
  actual_time_data.time_array[2]   = 0x3A;
  
  actual_time_data.time_array[3]   = (((uint8_t)(RTC_TimeStructure->RTC_Minutes & 0xF0) >> 0x04) + 0x30);
  actual_time_data.time_array[4]   =(((uint8_t)(RTC_TimeStructure->RTC_Minutes & 0x0F))+ (uint8_t)0x30);
  actual_time_data.time_array[5]   = 0x3A;

  actual_time_data.time_array[6]   = (((uint8_t)(RTC_TimeStructure->RTC_Seconds & 0xF0) >> 0x04)+ 0x30);
  actual_time_data.time_array[7]   = (((uint8_t)(RTC_TimeStructure->RTC_Seconds & 0x0F)) + 0x30);
  actual_time_data.time_array[8]   = 0x2E;
  
  actual_time_data.time_array[9]   = (uint8_t)((Secondfraction / 100) + 0x30);
  actual_time_data.time_array[10]  = (uint8_t)(((Secondfraction % 100 ) / 10) + 0x30);
  actual_time_data.time_array[11]  =  (uint8_t)((Secondfraction % 10) + 0x30);
  
  /* return actual_time_data */
  return actual_time_data;
}

/* @brief  Displays the current Time */ 
double RTC_GetTime_SecondsSubSeconds(RTC_TimeTypeDef* RTC_TimeStructure){   	
  double seconds_passed = 0;
	RTC_GetTime(RTC_Format_BCD, RTC_TimeStructure);
	seconds_passed = (((uint8_t)(RTC_TimeStructure->RTC_Hours & 0xF0) >> 0x04)*10 + ((uint8_t)(RTC_TimeStructure->RTC_Hours & 0x0F)))*3600
									+ (((uint8_t)(RTC_TimeStructure->RTC_Minutes & 0xF0) >> 0x04)*10 + ((uint8_t)(RTC_TimeStructure->RTC_Minutes & 0x0F)))*60
									+ ((uint8_t)(RTC_TimeStructure->RTC_Seconds & 0xF0) >> 0x04)*10 + (uint8_t)(RTC_TimeStructure->RTC_Seconds & 0x0F)
									+ (1000 - (uint8_t)RTC_GetSubSecond()*3.90625)/1000;
	return seconds_passed;
}

void RTC_Time_display(RTC_TimeTypeDef* RTC_TimeStructure, Time_TypeDef TimeData){
	USARTBuffer_TypeDef USART_Buffer;	
  uint8_t index = 0;
	
	RTC_GetTime(RTC_Format_BCD, RTC_TimeStructure);
	USART_Puts("\rTime: ");
  for (index = 0; index < 12; index++)
  {
    /* Display time element under index (char)  */
		sprintf(USART_Buffer.buffer, "%c", TimeData.time_array[index]);
		USART_Puts(USART_Buffer.buffer);
  }
	USART_Puts("\n");
	/* Display the current time in seconds and subseconds*/
	sprintf(USART_Buffer.buffer, "\rSeconds: %4.3f\n", (double)RTC_GetTime_SecondsSubSeconds(RTC_TimeStructure));
	USART_Puts(USART_Buffer.buffer);  
}

/* RTC reset */
void RTC_ResetTime(RTC_TimeTypeDef* RTC_TimeStructure){   
  RTC_TimeStructure->RTC_Hours   = 0;
  RTC_TimeStructure->RTC_Minutes = 0;
  RTC_TimeStructure->RTC_Seconds = 0;  
  RTC_SetTime(RTC_Format_BCD, RTC_TimeStructure); 
}

