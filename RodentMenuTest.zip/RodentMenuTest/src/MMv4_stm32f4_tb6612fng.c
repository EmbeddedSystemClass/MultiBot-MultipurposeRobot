#include "MMv4_stm32f4_tb6612fng.h"

#define min_value 1

TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
TIM_OCInitTypeDef  TIM_OCInitStructure;

void TB6612FNG_GPIO_Initialize(void){
	GPIO_InitTypeDef TB6612FNG_InitStructure;
	/* Output HSE clock on MCO1 pin(PC5) ****************************************/ 
  /* Enable the GPIOC peripheral */ 
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
  
  /* Configure L3GD20 pin PC1 - DRDY and PC7 - DEN in alternate function */
  TB6612FNG_InitStructure.GPIO_Pin = A_IN1 | A_IN2 | B_IN1 | B_IN2;
  TB6612FNG_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  TB6612FNG_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  TB6612FNG_InitStructure.GPIO_OType = GPIO_OType_PP;
  TB6612FNG_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;  
  GPIO_Init(GPIOB, &TB6612FNG_InitStructure);
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
  
  /* Configure L3GD20 pin PC1 - DRDY and PC7 - DEN in alternate function */
  TB6612FNG_InitStructure.GPIO_Pin = STBY_PIN;
  TB6612FNG_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  TB6612FNG_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  TB6612FNG_InitStructure.GPIO_OType = GPIO_OType_PP;
  TB6612FNG_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;  
  GPIO_Init(GPIOA, &TB6612FNG_InitStructure);
}

void TB6612FNG_PWM_Initialize(void){
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/* Compute AAR (Period) value */
	uint32_t TIM2_ARR = SE_MaxCCR;	//(TIM2_counter_clock / TIM2_output_clock) - 1; //(50000000 / 80000) - 1;
	/* Compute the prescaler value */
  uint16_t PrescalerValue = (uint16_t) ((SystemCoreClock / 2) / TIM2_counter_clock) - 1; 
  /* TIM2 clock enable */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	
  /* GPIOC clock enable */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
  
  /* GPIOC Configuration: TIM2 CH1 (PA5), TIM2 CH2 (PA1) */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP ;
  GPIO_Init(GPIOA, &GPIO_InitStructure); 

  /* Connect TIM2 pins to AF2 */  
  GPIO_PinAFConfig(GPIOA, GPIO_PinSource1, GPIO_AF_TIM2);
  GPIO_PinAFConfig(GPIOA, GPIO_PinSource5, GPIO_AF_TIM2);
	
		/* -----------------------------------------------------------------------
    TIM2 Configuration: generate 2 PWM signals
    
    If TIM2 input clock (TIM2CLK) is set to 2 * APB1 clock (PCLK1), 
    since APB1 prescaler is different from 1.   
      TIM2CLK = 2 * PCLK1  
      PCLK1 = HCLK / 4 
      => TIM2CLK = HCLK / 2 = SystemCoreClock /2
          
    To get TIM2 counter clock at 50 MHz, the prescaler is computed as follows:
			 Prescaler = (TIM2CLK / TIM2 counter clock) - 1
       Prescaler = ((SystemCoreClock / 2) / 50MHz) - 1
			 
			 Prescaler = ((100000000 / 2) / 50000000) - 1 = 499
                                              
    To get TIM2 output clock at 100 KHz, the period (ARR)) is computed as follows:
       ARR = (TIM2 counter clock / TIM2 output clock) - 1 //timer period
			 ARR = (100000000 / 100000) - 1 = 999
						
		For example:         
    TIM2 Channel1 duty cycle = (TIM2_CCR1/ TIM2_ARR)* 100 = 50%
    TIM2 Channel2 duty cycle = (TIM2_CCR2/ TIM2_ARR)* 100 = 37.5%

    Note: 
     SystemCoreClock variable holds HCLK frequency and is defined in system_stm32f4xx.c file.
     Each time the core clock (HCLK) changes, user had to call SystemCoreClockUpdate()
     function to update SystemCoreClock variable value. Otherwise, any configuration
     based on this variable will be incorrect.    
  ----------------------------------------------------------------------- */  

//	sprintf(array, "\r\tTIM2_ARR: %d  |  PrescalerValue: %d\r\n", TIM2_ARR, PrescalerValue);
//	USART_Puts(array);

  /* Time base configuration */
  TIM_TimeBaseStructure.TIM_Period = TIM2_ARR;
  TIM_TimeBaseStructure.TIM_Prescaler = PrescalerValue;
  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
	
	/* PWM1 Mode configuration: Channel1 and Channel2 */
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OC1Init(TIM2, &TIM_OCInitStructure);
}

/* Converts percents to CCR values */
int16_t CCR_Perc(int8_t CCR_Percent) {
  if (((CCR_Percent >= 0) && (CCR_Percent <= 100)) ? (1) : (0)){
    return CCR_Percent*CCR_percnt_factor;
  }else if(CCR_Percent > 100){
    return 600; //max 615
  }else return 0;
}

void TB6612FNG_PWMA_SetChannel(int16_t CCR1_Val){
	//int16_t CCR1_Val = CCR_Perc(CCR_Percent);
	/* PWM1 Mode configuration: Channel1 */
  TIM_OCInitStructure.TIM_Pulse = CCR1_Val;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;

  TIM_OC1Init(TIM2, &TIM_OCInitStructure);

  TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);

//  /* PWM1 Mode configuration: Channel2 */
//  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
//  TIM_OCInitStructure.TIM_Pulse = CCR2_Val;

//  TIM_OC2Init(TIM2, &TIM_OCInitStructure);

//  TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);
	
	TIM_ARRPreloadConfig(TIM2, ENABLE);

  /* TIM2 enable counter */
  TIM_Cmd(TIM2, ENABLE);
}

void TB6612FNG_PWMB_SetChannel(int16_t CCR2_Val){
	//int16_t CCR2_Val = CCR_Perc(CCR_Percent);
  /* PWM1 Mode configuration: Channel2 */
	TIM_OCInitStructure.TIM_Pulse = CCR2_Val;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;

  TIM_OC2Init(TIM2, &TIM_OCInitStructure);

  TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);
	
	TIM_ARRPreloadConfig(TIM2, ENABLE);

  /* TIM2 enable counter */
  TIM_Cmd(TIM2, ENABLE);
}

void RightMotor(DirectionFlag_TypeDef* Direction_FlagStruct, int16_t CRR_Val){
	//Direction_FlagStruct->directionA = CRR_Val >= -200 ? 1 : -1;
	//Direction_FlagStruct->directionA = CRR_Val >= 0 ? 1 : -1;
	if(CRR_Val > 0){
		//CRR_Val = CRR_Val >= 500 ? CRR_Val : 500;
		Direction_FlagStruct->dir_flagA = 1;
		//TB6612FNG_PWMB_SetChannel(CRR_Val < 1000 ? CRR_Val : 1000);
		TB6612FNG_PWMB_SetChannel(CRR_Val);
		GPIO_SetBits(AB_IN, A_IN1);	
		GPIO_ResetBits(AB_IN, A_IN2);
	}else{
		Direction_FlagStruct->dir_flagA = -1;
		//Direction_FlagStruct->directionA = -CRR_Val > min_value ? 11 : 0;		
		//TB6612FNG_PWMB_SetChannel(-CRR_Val < 1000 ? -CRR_Val : 1000);
		TB6612FNG_PWMB_SetChannel(-CRR_Val);
		GPIO_ResetBits(AB_IN, A_IN1);
		GPIO_SetBits(AB_IN, A_IN2);
	}
}

void LeftMotor(DirectionFlag_TypeDef* Direction_FlagStruct, int16_t CRR_Val){
	//Direction_FlagStruct->directionB = CRR_Val >= -200 ? 1 : -1;
	//Direction_FlagStruct->directionB = CRR_Val >= 0 ? 1 : -1;
	if(CRR_Val > 0){
		Direction_FlagStruct->dir_flagB = 1;
		//CRR_Val = CRR_Val >= 500 ? CRR_Val : 500;
		//TB6612FNG_PWMA_SetChannel(CRR_Val < 1000 ? CRR_Val : 1000);
		TB6612FNG_PWMA_SetChannel(CRR_Val);
		GPIO_SetBits(AB_IN, B_IN1);
		GPIO_ResetBits(AB_IN, B_IN2);
	}else{
		Direction_FlagStruct->dir_flagB = -1;	
		//TB6612FNG_PWMA_SetChannel(-CRR_Val < 1000 ? -CRR_Val : 1000);
		TB6612FNG_PWMA_SetChannel(-CRR_Val);
		GPIO_ResetBits(AB_IN, B_IN1);
		GPIO_SetBits(AB_IN, B_IN2);;
	}
}

void RightForward(DirectionFlag_TypeDef* Direction_FlagStruct, int8_t PowerPercent){
	Direction_FlagStruct->dir_flagA = 1;
	TB6612FNG_PWMB_SetChannel(PowerPercent);
	GPIO_SetBits(AB_IN, A_IN1);	
	GPIO_ResetBits(AB_IN, A_IN2);
}

void LeftForward(DirectionFlag_TypeDef* Direction_FlagStruct, int8_t PowerPercent){
	Direction_FlagStruct->dir_flagB = 1;
	TB6612FNG_PWMA_SetChannel(PowerPercent);
	GPIO_SetBits(AB_IN, B_IN1);
	GPIO_ResetBits(AB_IN, B_IN2);
}

void RightBackward(DirectionFlag_TypeDef* Direction_FlagStruct, int8_t PowerPercent){
	Direction_FlagStruct->dir_flagA = -1;
	TB6612FNG_PWMB_SetChannel(PowerPercent);
	GPIO_ResetBits(AB_IN, A_IN1);
	GPIO_SetBits(AB_IN, A_IN2);
}
void LeftBackward(DirectionFlag_TypeDef* Direction_FlagStruct, int8_t PowerPercent){
	Direction_FlagStruct->dir_flagB = -1;
	TB6612FNG_PWMA_SetChannel(PowerPercent);
	GPIO_ResetBits(AB_IN, B_IN1);
	GPIO_SetBits(AB_IN, B_IN2);;
}

void RightHardStop(void){
	TB6612FNG_PWMB_SetChannel(0);
	GPIO_ResetBits(AB_IN, A_IN1);
	GPIO_ResetBits(AB_IN, A_IN2);
}

void LeftHardStop(void){
	TB6612FNG_PWMA_SetChannel(0);
	GPIO_ResetBits(AB_IN, B_IN1);
	GPIO_ResetBits(AB_IN, B_IN2);
}

void RightSoftStop(void){
	GPIO_ResetBits(AB_IN, A_IN1);
	GPIO_ResetBits(AB_IN, A_IN2);;
	TB6612FNG_PWMA_SetChannel(0);
}

void LeftSoftStop(void){
	GPIO_ResetBits(AB_IN, B_IN1);
	GPIO_ResetBits(AB_IN, B_IN2);
	TB6612FNG_PWMB_SetChannel(0);
}

//void MouseHardStop(void){
//	RightBackward(40);
//	LeftBackward(40);	
//	Delay(10);
//	LeftHardStop();
//	RightHardStop();
//}
