#include  "MMv4_stm32f4_software.h"

USARTBuffer_TypeDef USART_Buffer1;
float32_t tmp_error;
float32_t tmp_errorA;
float32_t tmp_errorB;
float32_t prev_error;

void setDa(DifferentialDrive_TypeDef* DifferentialDrive_DataStruct, int8_t directionA){
	DifferentialDrive_DataStruct->Da += (float32_t)distance_per_bump*directionA;
}

void setDb(DifferentialDrive_TypeDef* DifferentialDrive_DataStruct, int8_t directionB){
	DifferentialDrive_DataStruct->Db += (float32_t)distance_per_bump*directionB;
}

void setTheta(DifferentialDrive_TypeDef* DifferentialDrive_DataStruct){
	DifferentialDrive_DataStruct->theta = ((DifferentialDrive_DataStruct->Db - DifferentialDrive_DataStruct->Da)/(float32_t)wheelbase);
}

void setD(DifferentialDrive_TypeDef* DifferentialDrive_DataStruct){
	DifferentialDrive_DataStruct->D = ((DifferentialDrive_DataStruct->Db + DifferentialDrive_DataStruct->Da)/2);
}

void setX(DifferentialDrive_TypeDef* DifferentialDrive_DataStruct){
	DifferentialDrive_DataStruct->x = DifferentialDrive_DataStruct->x_prev + DifferentialDrive_DataStruct->D*arm_sin_f32(DifferentialDrive_DataStruct->theta);
}

void setY(DifferentialDrive_TypeDef* DifferentialDrive_DataStruct){
	DifferentialDrive_DataStruct->y = DifferentialDrive_DataStruct->y_prev + DifferentialDrive_DataStruct->D*arm_cos_f32(DifferentialDrive_DataStruct->theta);
}






void getBin(int num, char *str){
	int mask = 0x10 << 1;
  *(str+5) = '\0';

  while(mask >>= 1)
    *str++ = !!(mask & num) + '0';
}

int DecToBin(int n){
    int rem, i=1, binary=0;
    while (n!=0)
    {
        rem=n%2;
        n/=2;
        binary+=rem*i;
        i*=10;
    }
    return binary;
}

void ResetMaze(MazeData_TypeDef *Maze_DataStruct){
	Maze_DataStruct->actual_position = 0;

	if(Maze_DataStruct->initial_corner_position == 1){
			Maze_DataStruct->X = 0;
			Maze_DataStruct->Y = 0;
		}
	if(Maze_DataStruct->initial_corner_position == 2){
			Maze_DataStruct->X = Maze_DataStruct->N - 1;
			Maze_DataStruct->Y = 0;
		}
	if(Maze_DataStruct->initial_corner_position == 3){
			Maze_DataStruct->X = Maze_DataStruct->N - 1;
			Maze_DataStruct->Y = Maze_DataStruct->N - 1;
		}
	if(Maze_DataStruct->initial_corner_position == 4){
		Maze_DataStruct->X = 0;
		Maze_DataStruct->Y = Maze_DataStruct->N - 1;
	}
}

void EraseMaze(MazeData_TypeDef *Maze_DataStruct){
	uint8_t x, y;
	for(y = 0; y < Maze_DataStruct->N; y++){
		for(x = 0; x < Maze_DataStruct->N; x++){
			Maze_DataStruct->maze_flood[x][y] = 0;
			Maze_DataStruct->maze_wall[x][y] = 0;
		}
	}
}

void FillMaze(MazeData_TypeDef *Maze_DataStruct){
	uint8_t x, y, c = Maze_DataStruct->N*Maze_DataStruct->N - 1; //czy zmieści się max
	for(y = 0; y < Maze_DataStruct->N; y++){
		for(x = 0; x < Maze_DataStruct->N; x++){
			Maze_DataStruct->maze_flood[x][y] = c;//c++;
			Maze_DataStruct->maze_wall[x][y] = 0;
			//c++;
		}
	}
	if(Maze_DataStruct->initial_corner_position == 1){
			Maze_DataStruct->X = 0;
			Maze_DataStruct->Y = 0;
		}
	if(Maze_DataStruct->initial_corner_position == 2){
			Maze_DataStruct->X = Maze_DataStruct->N - 1;
			Maze_DataStruct->Y = 0;
		}
	if(Maze_DataStruct->initial_corner_position == 3){
			Maze_DataStruct->X = Maze_DataStruct->N - 1;
			Maze_DataStruct->Y = Maze_DataStruct->N - 1;
		}
	if(Maze_DataStruct->initial_corner_position == 4){
		Maze_DataStruct->X = 0;
		Maze_DataStruct->Y = Maze_DataStruct->N - 1;
	}
//	uint8_t x, y, c = 255;
//	for(y = 0; y < 16; y++){
//		for(x = 0; x < 16; x++){
//			Maze_DataStruct->maze[x][y] = c--;
//			Maze_DataStruct->maze_wall[x][y] = 0;
//		}
//	}
//	
//	uint8_t x, y, c = 0;
//	for(y = 0; y < 16; y++){
//		for(x = 0; x < 16; x++){
//			Maze_DataStruct->maze_flood[x][y] = c++;
//			Maze_DataStruct->maze_wall[x][y] = 0;
//		}
//	}
}

void DrawMaze(MazeData_TypeDef *Maze_DataStruct){
	uint8_t x, y;
	for(y = 0; y < Maze_DataStruct->N; y++){
		USART_SendString("\r");
		for(x = 0; x < Maze_DataStruct->N; x++){
			//gotoxy(x, y);
			USART_SendString("[");
			sprintf(USART_Buffer1.buffer, "%3d", Maze_DataStruct->maze_flood[x][y]);USART_SendString(USART_Buffer1.buffer);
			USART_SendString("]");
		}
			USART_SendString("\n");
	}
}

void DrawMazeWalls(MazeData_TypeDef *Maze_DataStruct){
	uint8_t x, y;
	char str[8];
	for(y = 0; y < Maze_DataStruct->N; y++){
		USART_SendString("\r");
		for(x = 0; x < Maze_DataStruct->N; x++){
				USART_SendString("[");
				sprintf(str, "%4d", DecToBin(Maze_DataStruct->maze_wall[x][y]));
				USART_SendString(str);
				USART_SendString("]");
		}
			USART_SendString("\n");
	}
}

void PresentMazeWalls(MazeData_TypeDef *Maze_DataStruct){
	uint8_t x, y, i;

	for(y = 0; y < Maze_DataStruct->N; y++){
		if(y == 0){
			USART_SendString("\r ");
			for(i = 0; i < Maze_DataStruct->N; i++){
				USART_SendString("__ ");
			}
			USART_SendString("\n");
		}
		USART_SendString("\r|");
		for(x = 0; x < Maze_DataStruct->N; x++){
			if(y < Maze_DataStruct->N - 1){
				if(((Maze_DataStruct->maze_wall[x][y] & wall_south) == wall_south) || ((y + 1 < Maze_DataStruct->N) ? ((Maze_DataStruct->maze_wall[x][y + 1] & wall_north) == wall_north) : 1)){
					USART_SendString("__");
				}else{
					USART_SendString("  ");
				}
			}else{
				USART_SendString("__");
			}
			if(x < Maze_DataStruct->N - 1){
				if(((Maze_DataStruct->maze_wall[x][y] & wall_east) == wall_east) || ((x + 1 < Maze_DataStruct->N) ? ((Maze_DataStruct->maze_wall[x + 1][y] & wall_west) == wall_west) : 1)){
					USART_SendString("|");
				}else{
					USART_SendString(" ");
				}
			}else{
				USART_SendString("|");
			}
		}
		USART_SendString("\n");
	}
}

void DrawMaze_Bin(MazeData_TypeDef *Maze_DataStruct){
	uint8_t x, y;
	for(y = 0; y < Maze_DataStruct->N; y++){
		USART_SendString("\r");
		for(x = 0; x < Maze_DataStruct->N; x++){
			//gotoxy(x, y);
			USART_SendString("[");
			sprintf(USART_Buffer1.buffer, "%8d", DecToBin(Maze_DataStruct->maze_flood[x][y]));USART_SendString(USART_Buffer1.buffer);
			USART_SendString("]");
		}
			USART_SendString("\n");
	}
}

// __
//|__|

void DrawMouseOrientation(MazeData_TypeDef *Maze_DataStruct){
	USART_SendString("\r");USART_SendString("  ");USART_SendChar(Maze_DataStruct->mouse_orientation[DirN]);USART_SendString("\n");
	USART_SendString("\r");USART_SendChar(Maze_DataStruct->mouse_orientation[DirW]);USART_SendString("   ");USART_SendChar(Maze_DataStruct->mouse_orientation[DirE]);USART_SendString("\n");
	USART_SendString("\r");USART_SendString("  ");USART_SendChar(Maze_DataStruct->mouse_orientation[DirS]);USART_SendString("\n");
}

MM_State_TypeDef ResetMouseOrientatioArray(MazeData_TypeDef *Maze_DataStruct){
	if(Maze_DataStruct->initial_corner_position == 1 || Maze_DataStruct->initial_corner_position == 2){
		Maze_DataStruct->mouse_orientation[DirN] = 'S';
		Maze_DataStruct->mouse_orientation[DirE] = 'W';
		Maze_DataStruct->mouse_orientation[DirS] = 'N';
		Maze_DataStruct->mouse_orientation[DirW] = 'E';
	}else{
		Maze_DataStruct->mouse_orientation[DirN] = 'N';
		Maze_DataStruct->mouse_orientation[DirE] = 'E';
		Maze_DataStruct->mouse_orientation[DirS] = 'S';
		Maze_DataStruct->mouse_orientation[DirW] = 'W';
	}

	return MM_Success;
}

MM_State_TypeDef RotateMouseOrientatioArray90degRight(MazeData_TypeDef *Maze_DataStruct){
	char prev_N = Maze_DataStruct->mouse_orientation[DirN];
	char prev_E = Maze_DataStruct->mouse_orientation[DirE];
	char prev_S = Maze_DataStruct->mouse_orientation[DirS];
	char prev_W = Maze_DataStruct->mouse_orientation[DirW];

	Maze_DataStruct->mouse_orientation[DirN] = prev_E;
	Maze_DataStruct->mouse_orientation[DirE] = prev_S;
	Maze_DataStruct->mouse_orientation[DirS] = prev_W;
	Maze_DataStruct->mouse_orientation[DirW] = prev_N;
	return MM_Success;
}

MM_State_TypeDef RotateMouseOrientatioArray90degLeft(MazeData_TypeDef *Maze_DataStruct){
	char prev_N = Maze_DataStruct->mouse_orientation[DirN];
	char prev_E = Maze_DataStruct->mouse_orientation[DirE];
	char prev_S = Maze_DataStruct->mouse_orientation[DirS];
	char prev_W = Maze_DataStruct->mouse_orientation[DirW];

	Maze_DataStruct->mouse_orientation[DirN] = prev_W;
	Maze_DataStruct->mouse_orientation[DirE] = prev_N;
	Maze_DataStruct->mouse_orientation[DirS] = prev_E;
	Maze_DataStruct->mouse_orientation[DirW] = prev_S;
	return MM_Success;
}


MM_State_TypeDef CheckNextFieldOrientation(MazeData_TypeDef *Maze_DataStruct){
	if(Maze_DataStruct->mouse_orientation[DirN] == 'N'){
		Maze_DataStruct->nextX =  0;
		Maze_DataStruct->nextY = -1;

		Maze_DataStruct->mouse_north = north;
		Maze_DataStruct->mouse_east = east;
		Maze_DataStruct->mouse_south = south;
		Maze_DataStruct->mouse_west = west;

		Maze_DataStruct->top_neighbor = -1;
		Maze_DataStruct->left_neighbor = -1;
		Maze_DataStruct->right_neighbor = 1;
		Maze_DataStruct->down_neighbor = 0;

	}else if(Maze_DataStruct->mouse_orientation[DirN] == 'E'){
		Maze_DataStruct->nextX = 1;
		Maze_DataStruct->nextY = 0;

		Maze_DataStruct->mouse_north = east;
		Maze_DataStruct->mouse_east = south;
		Maze_DataStruct->mouse_south = west;
		Maze_DataStruct->mouse_west = north;

		Maze_DataStruct->top_neighbor = -1;
		Maze_DataStruct->left_neighbor = 0;
		Maze_DataStruct->right_neighbor = 1;
		Maze_DataStruct->down_neighbor = 1;
	}else if(Maze_DataStruct->mouse_orientation[DirN] == 'W'){
		Maze_DataStruct->nextX = -1;
		Maze_DataStruct->nextY = 0;

		Maze_DataStruct->mouse_north = west;
		Maze_DataStruct->mouse_east = north;
		Maze_DataStruct->mouse_south = east;
		Maze_DataStruct->mouse_west = south;

		Maze_DataStruct->top_neighbor = -1;
		Maze_DataStruct->left_neighbor = -1;
		Maze_DataStruct->right_neighbor = 0;
		Maze_DataStruct->down_neighbor = 1;
	}else if(Maze_DataStruct->mouse_orientation[DirN] == 'S'){
		Maze_DataStruct->nextX = 0;
		Maze_DataStruct->nextY = 1;

		Maze_DataStruct->mouse_north = south;
		Maze_DataStruct->mouse_east = west;
		Maze_DataStruct->mouse_south = north;
		Maze_DataStruct->mouse_west = east;

		Maze_DataStruct->top_neighbor = 0;
		Maze_DataStruct->left_neighbor = -1;
		Maze_DataStruct->right_neighbor = 1;
		Maze_DataStruct->down_neighbor = 1;
	}
	return MM_Success;
}


void FloodFillMaze(MazeData_TypeDef *Maze_DataStruct, uint8_t position_x, uint8_t position_y, int8_t actual_position, int8_t next_position){
	if(Maze_DataStruct->maze_flood[position_x][position_y] > next_position){
		if(!((position_x >= Maze_DataStruct->N) || (position_y >= Maze_DataStruct->N))){

			Maze_DataStruct->maze_flood[position_x][position_y] = next_position;

			if(!((Maze_DataStruct->maze_wall[position_x][position_y] & wall_north) == wall_north) && ((Maze_DataStruct->maze_wall[position_x][position_y + Maze_DataStruct->top_neighbor] & visited) == visited)){
				FloodFillMaze(Maze_DataStruct, position_x, position_y + Maze_DataStruct->top_neighbor, actual_position, next_position + 1);
			}
			if(!((Maze_DataStruct->maze_wall[position_x][position_y] & wall_east) == wall_east) && ((Maze_DataStruct->maze_wall[position_x + Maze_DataStruct->right_neighbor][position_y] & visited) == visited)){
				FloodFillMaze(Maze_DataStruct, position_x + Maze_DataStruct->right_neighbor, position_y, actual_position, next_position + 1);
			}
			if(!((Maze_DataStruct->maze_wall[position_x][position_y] & wall_south) == wall_south) && ((Maze_DataStruct->maze_wall[position_x][position_y + Maze_DataStruct->down_neighbor] & visited) == visited)){
				FloodFillMaze(Maze_DataStruct, position_x, position_y + Maze_DataStruct->down_neighbor, actual_position, next_position + 1);
			}
			if(!((Maze_DataStruct->maze_wall[position_x][position_y] & wall_west) == wall_west) && ((Maze_DataStruct->maze_wall[position_x + Maze_DataStruct->left_neighbor][position_y] & visited) == visited)){
				FloodFillMaze(Maze_DataStruct, position_x + Maze_DataStruct->left_neighbor, position_y, actual_position, next_position + 1);
			}
		}
	}
}

//int8_t a = 11111111B;
void AddWall(IRSernorsData_InitTypeDef* IRSensors_DataStruct, MazeData_TypeDef *Maze_DataStruct){
	if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & visited) == visited)){
		Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] = 0;
		if(getADCx(IRSensors_DataStruct, 1) >= Rside_wall_present) {
			Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] |=  Maze_DataStruct->mouse_east;
			//indeks = indeks + 16;          // teraz indeks pokazuje na segment powyzej
			//mapa[indeks] = mapa[indeks] | SOUTH;
		}

		if(getADCx(IRSensors_DataStruct, 2) >= Lside_wall_present) {
			Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] |=  Maze_DataStruct->mouse_west;
				//indeks = indeks + 1;
				//mapa[indeks] = mapa[indeks] | WEST;
		}

		if((getADCx(IRSensors_DataStruct, 0) + getADCx(IRSensors_DataStruct, 3))/2 >= front_wall_present) {
				Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] |=  Maze_DataStruct->mouse_north;
				//indeks = indeks + 240;    // r�wnowazne z odjeciem 16
				//mapa[indeks] = mapa[indeks] | NORTH;
		}

		if(Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] == 1 || Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] == 8){
			//Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] |= finish;
		}else if(Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] == 13){
			Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] |= dead_end;
		}

		Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] |= visited;
	}else{
		return;
	}
	//	else{
	//		Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->top_neighbor] = next_position;
	//		Maze_DataStruct->maze_flood[Maze_DataStruct->X + Maze_DataStruct->right_neighbor][Maze_DataStruct->Y] = next_position;
	//		Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->down_neighbor] = next_position;
	//		Maze_DataStruct->maze_flood[Maze_DataStruct->X + Maze_DataStruct->left_neighbor][Maze_DataStruct->Y] = next_position;
	//		//Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y-1] = next_position;
	//	}

//	if(getADCx(IRSensors_DataStruct, 2) >= front_wall_present) { 
//			indeks = indeks + 255;    // r�wnowazne z odjeciem 1 
//			mapa[indeks] = mapa[indeks] | EAST; 
//	} 
//				
//	Maze_DataStruct->maze[Maze_DataStruct->X][Maze_DataStruct->Y] = Maze_DataStruct->actual_position;
//	Maze_DataStruct->actual_position++;
//	Maze_DataStruct->X++;
//	Maze_DataStruct->Y++;
}

uint8_t X, Y;

//void MakeDecision(enum Mouse_Status* MouseState, EncoderData_TypeDef *Encoders_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, MazeData_TypeDef* Maze_DataStruct, DifferentialDrive_TypeDef* DifferentialDrive_DataStruct){
//	if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & Maze_DataStruct->mouse_north) == Maze_DataStruct->mouse_north)){
//		//if((Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->top_neighbor]) < (Maze_DataStruct->actual_position)){
//		*MouseState = DriveDist;
//		return;
//		//}
//	}
//	if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & Maze_DataStruct->mouse_east) == Maze_DataStruct->mouse_east)){
//		DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da - 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
//		DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db + 5.340707511;
//		RotateMouseOrientatioArray90degRight(Maze_DataStruct);
//		*MouseState = TurnRight;
//		return;
//	}
//	if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & Maze_DataStruct->mouse_west) == Maze_DataStruct->mouse_west)){
//		DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da + 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
//		DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db - 5.340707511;
//
//		RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
//		*MouseState = TurnLeft;
//		return;
//	}else {//TURN AROUND
//		//USART_SendString("\rMouseState = Stop\n");
//		//USART_SendString("\rAround\n");
//
//		DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da + 10.68141502;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
//		DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db - 10.681415021;
//
//		RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
//		RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
//		*MouseState = TurnLeft;
//		//*MouseState = TurnAround;
//		//Direction_FlagStruct->dir_flagA = -1;
//		//GPIO_ResetBits(BUZZER_PORT, BUZZER_PIN);
//	}
//}
int16_t sorted_fields[3];

void MakeDecision(enum Mouse_Status* MouseState, EncoderData_TypeDef *Encoders_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, MazeData_TypeDef* Maze_DataStruct, DifferentialDrive_TypeDef* DifferentialDrive_DataStruct){
	//SortFields(MazeData_TypeDef *Maze_DataStruct, uint8_t sort_buffer[3]);
	if(Maze_DataStruct->mouse_north == north){
		if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & wall_north) == wall_north) && ((Maze_DataStruct->Y + Maze_DataStruct->top_neighbor) >= Maze_DataStruct->N ? 0 : 1)){
			if((!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->top_neighbor] & visited) == visited))){
			//if((Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->top_neighbor]) < (Maze_DataStruct->actual_position)){
				*MouseState = DriveDist;
				return;
			}
			sorted_fields[0] = Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->top_neighbor];
		}else{
			sorted_fields[0] = Maze_DataStruct->N*Maze_DataStruct->N;
		}
		if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & wall_east) == wall_east) && ((Maze_DataStruct->X + Maze_DataStruct->right_neighbor) >= Maze_DataStruct->N ? 0 : 1)){
			if((!((Maze_DataStruct->maze_wall[Maze_DataStruct->X + Maze_DataStruct->right_neighbor][Maze_DataStruct->Y] & visited) == visited))){
				DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da - 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
				DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db + 5.340707511;
				RotateMouseOrientatioArray90degRight(Maze_DataStruct);
				*MouseState = TurnRight;
				return;
			}
			sorted_fields[1] = Maze_DataStruct->maze_flood[Maze_DataStruct->X + Maze_DataStruct->right_neighbor][Maze_DataStruct->Y];
		}else{
			sorted_fields[1] = Maze_DataStruct->N*Maze_DataStruct->N;
		}
		if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & wall_west) == wall_west) && ((Maze_DataStruct->X + Maze_DataStruct->left_neighbor) >= Maze_DataStruct->N ? 0 : 1)){
			if((!((Maze_DataStruct->maze_wall[Maze_DataStruct->X + Maze_DataStruct->left_neighbor][Maze_DataStruct->Y] & visited) == visited))){
				DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da + 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
				DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db - 5.340707511;

				RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
				*MouseState = TurnLeft;
				return;
			}
			sorted_fields[2] = Maze_DataStruct->maze_flood[Maze_DataStruct->X + Maze_DataStruct->left_neighbor][Maze_DataStruct->Y];
		}else{
			sorted_fields[2] = Maze_DataStruct->N*Maze_DataStruct->N;
		}

		for(int x=0; x<3; x++){
			for(int y=0; y<3-1; y++){
				if(sorted_fields[y]>sorted_fields[y+1])
				{
					int temp = sorted_fields[y+1];
					sorted_fields[y+1] = sorted_fields[y];
					sorted_fields[y] = temp;
				}
			}
		}

		if(sorted_fields[0] == Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->top_neighbor]){
		//if((Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->top_neighbor]) < (Maze_DataStruct->actual_position)){
			*MouseState = DriveDist;
			return;
		}
		if(sorted_fields[0] == Maze_DataStruct->maze_flood[Maze_DataStruct->X + Maze_DataStruct->right_neighbor][Maze_DataStruct->Y]){
			DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da - 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
			DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db + 5.340707511;
			RotateMouseOrientatioArray90degRight(Maze_DataStruct);
			*MouseState = TurnRight;
			return;
		}
		if(sorted_fields[0] == Maze_DataStruct->maze_flood[Maze_DataStruct->X + Maze_DataStruct->left_neighbor][Maze_DataStruct->Y]){
			DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da + 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
			DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db - 5.340707511;

			RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
			*MouseState = TurnLeft;
			return;
		}else {//TURN AROUND
			//USART_SendString("\rMouseState = Stop\n");
			//USART_SendString("\rAround\n");

			DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da + 10.68141502;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
			DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db - 10.681415021;

			RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
			RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
			*MouseState = TurnLeft;
			//*MouseState = TurnAround;
			//Direction_FlagStruct->dir_flagA = -1;
			//GPIO_ResetBits(BUZZER_PORT, BUZZER_PIN);
		}
	}else if(Maze_DataStruct->mouse_north == east){
		if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & wall_east) == wall_east) && ((Maze_DataStruct->X + Maze_DataStruct->right_neighbor) >= Maze_DataStruct->N ? 0 : 1)){
			if((!((Maze_DataStruct->maze_wall[Maze_DataStruct->X + Maze_DataStruct->right_neighbor][Maze_DataStruct->Y] & visited) == visited))){
				*MouseState = DriveDist;
				return;
			}
			sorted_fields[0] = Maze_DataStruct->maze_flood[Maze_DataStruct->X + Maze_DataStruct->right_neighbor][Maze_DataStruct->Y];
		}else{
			sorted_fields[0] = Maze_DataStruct->N*Maze_DataStruct->N;
		}
		if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & wall_north) == wall_north) && ((Maze_DataStruct->Y + Maze_DataStruct->top_neighbor) >= Maze_DataStruct->N ? 0 : 1)){
			if((!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->top_neighbor] & visited) == visited))){
				DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da + 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
				DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db - 5.340707511;
				RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
				*MouseState = TurnLeft;
				return;
			}
			sorted_fields[1] = Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->top_neighbor];
		}else{
			sorted_fields[1] = Maze_DataStruct->N*Maze_DataStruct->N;
		}
		if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & wall_south) == wall_south) && ((Maze_DataStruct->Y + Maze_DataStruct->down_neighbor) >= Maze_DataStruct->N ? 0 : 1)){
			if((!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->down_neighbor] & visited) == visited))){
				DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da - 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
				DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db + 5.340707511;
				RotateMouseOrientatioArray90degRight(Maze_DataStruct);
				*MouseState = TurnRight;
				return;
			}
			sorted_fields[2] = Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->down_neighbor];
		}else{
			sorted_fields[2] = Maze_DataStruct->N*Maze_DataStruct->N;
		}

		for(int x=0; x<3; x++){
			for(int y=0; y<3-1; y++){
				if(sorted_fields[y]>sorted_fields[y+1])
				{
					int temp = sorted_fields[y+1];
					sorted_fields[y+1] = sorted_fields[y];
					sorted_fields[y] = temp;
				}
			}
		}

		if(sorted_fields[0] == Maze_DataStruct->maze_flood[Maze_DataStruct->X + Maze_DataStruct->right_neighbor][Maze_DataStruct->Y]){
			*MouseState = DriveDist;
			return;
		}
		if(sorted_fields[0] == Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->top_neighbor]){
			DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da + 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
			DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db - 5.340707511;
			RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
			*MouseState = TurnLeft;
			return;
		}
		if(sorted_fields[0] == Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->down_neighbor]){
			DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da - 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
			DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db + 5.340707511;
			RotateMouseOrientatioArray90degRight(Maze_DataStruct);
			*MouseState = TurnRight;
			return;
		}else {//TURN AROUND
			//USART_SendString("\rMouseState = Stop\n");
			//USART_SendString("\rAround\n");

			DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da + 10.68141502;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
			DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db - 10.681415021;

			RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
			RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
			*MouseState = TurnLeft;
			//*MouseState = TurnAround;
			//Direction_FlagStruct->dir_flagA = -1;
			//GPIO_ResetBits(BUZZER_PORT, BUZZER_PIN);
		}
	}else if(Maze_DataStruct->mouse_north == west){
		if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & wall_west) == wall_west) && ((Maze_DataStruct->X + Maze_DataStruct->left_neighbor) >= Maze_DataStruct->N ? 0 : 1)){
			if((!((Maze_DataStruct->maze_wall[Maze_DataStruct->X + Maze_DataStruct->left_neighbor][Maze_DataStruct->Y] & visited) == visited))){
				*MouseState = DriveDist;
				return;
			}
			sorted_fields[0] = Maze_DataStruct->maze_flood[Maze_DataStruct->X + Maze_DataStruct->left_neighbor][Maze_DataStruct->Y];
		}else{
			sorted_fields[0] = Maze_DataStruct->N*Maze_DataStruct->N;
		}
		if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & wall_north) == wall_north) && ((Maze_DataStruct->Y + Maze_DataStruct->top_neighbor) >= Maze_DataStruct->N ? 0 : 1)){
			if((!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->top_neighbor] & visited) == visited))){
				DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da - 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
				DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db + 5.340707511;
				RotateMouseOrientatioArray90degRight(Maze_DataStruct);
				*MouseState = TurnRight;
				return;
			}
			sorted_fields[1] = Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->top_neighbor];
		}else{
			sorted_fields[1] = Maze_DataStruct->N*Maze_DataStruct->N;
		}
		if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & wall_south) == wall_south) && ((Maze_DataStruct->Y + Maze_DataStruct->down_neighbor) >= Maze_DataStruct->N ? 0 : 1)){
			if((!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->down_neighbor] & visited) == visited))){
				DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da + 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
				DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db - 5.340707511;

				RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
				*MouseState = TurnLeft;
				return;
			}
			sorted_fields[2] = Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->down_neighbor];
		}else{
			sorted_fields[2] = Maze_DataStruct->N*Maze_DataStruct->N;
		}

		for(int x=0; x<3; x++){
			for(int y=0; y<3-1; y++){
				if(sorted_fields[y]>sorted_fields[y+1])
				{
					int temp = sorted_fields[y+1];
					sorted_fields[y+1] = sorted_fields[y];
					sorted_fields[y] = temp;
				}
			}
		}

		if(sorted_fields[0] == Maze_DataStruct->maze_flood[Maze_DataStruct->X + Maze_DataStruct->left_neighbor][Maze_DataStruct->Y]){
			*MouseState = DriveDist;
			return;
		}
		if(sorted_fields[0] == Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->top_neighbor]){
			DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da - 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
			DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db + 5.340707511;
			RotateMouseOrientatioArray90degRight(Maze_DataStruct);
			*MouseState = TurnRight;
			return;
		}
		if(sorted_fields[0] == Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->down_neighbor]){
			DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da + 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
			DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db - 5.340707511;

			RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
			*MouseState = TurnLeft;
			return;
		}else{//TURN AROUND
			//USART_SendString("\rMouseState = Stop\n");
			//USART_SendString("\rAround\n");

			DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da + 10.68141502;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
			DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db - 10.681415021;

			RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
			RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
			*MouseState = TurnLeft;
			//*MouseState = TurnAround;
			//Direction_FlagStruct->dir_flagA = -1;
			//GPIO_ResetBits(BUZZER_PORT, BUZZER_PIN);
		}
	}else if(Maze_DataStruct->mouse_north == south){
		if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & wall_south) == wall_south) && ((Maze_DataStruct->Y + Maze_DataStruct->down_neighbor) >= Maze_DataStruct->N ? 0 : 1)){
			if((!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->down_neighbor] & visited) == visited))){
				*MouseState = DriveDist;
				return;
			}
			sorted_fields[0] = Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->down_neighbor];
		}else {
			sorted_fields[0] = Maze_DataStruct->N*Maze_DataStruct->N;
		}

		if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & wall_east) == wall_east) && ((Maze_DataStruct->X + Maze_DataStruct->right_neighbor) >= Maze_DataStruct->N ? 0 : 1)){
			if((!((Maze_DataStruct->maze_wall[Maze_DataStruct->X + Maze_DataStruct->right_neighbor][Maze_DataStruct->Y] & visited) == visited))){
				DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da + 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
				DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db - 5.340707511;
				RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
				*MouseState = TurnLeft;
				return;
			}
			sorted_fields[1] = Maze_DataStruct->maze_flood[Maze_DataStruct->X + Maze_DataStruct->right_neighbor][Maze_DataStruct->Y];
		}else {
			sorted_fields[1] = Maze_DataStruct->N*Maze_DataStruct->N;
		}

		if(!((Maze_DataStruct->maze_wall[Maze_DataStruct->X][Maze_DataStruct->Y] & wall_west) == wall_west) && ((Maze_DataStruct->X + Maze_DataStruct->left_neighbor) >= Maze_DataStruct->N ? 0 : 1)){
			if((!((Maze_DataStruct->maze_wall[Maze_DataStruct->X + Maze_DataStruct->left_neighbor][Maze_DataStruct->Y] & visited) == visited))){
				DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da - 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
				DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db + 5.340707511;
				RotateMouseOrientatioArray90degRight(Maze_DataStruct);
				*MouseState = TurnRight;
				return;
			}
			sorted_fields[2] = Maze_DataStruct->maze_flood[Maze_DataStruct->X + Maze_DataStruct->left_neighbor][Maze_DataStruct->Y];
		}else {
			sorted_fields[2] = Maze_DataStruct->N*Maze_DataStruct->N;
		}

		for(int x=0; x<3; x++){
			for(int y=0; y<3-1; y++){
				if(sorted_fields[y]>sorted_fields[y+1])
				{
					int temp = sorted_fields[y+1];
					sorted_fields[y+1] = sorted_fields[y];
					sorted_fields[y] = temp;
				}
			}
		}

		if(sorted_fields[0] == Maze_DataStruct->maze_flood[Maze_DataStruct->X][Maze_DataStruct->Y + Maze_DataStruct->down_neighbor]){
			*MouseState = DriveDist;
			return;
		}
		if(sorted_fields[0] == Maze_DataStruct->maze_flood[Maze_DataStruct->X + Maze_DataStruct->right_neighbor][Maze_DataStruct->Y]){
			DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da + 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
			DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db - 5.340707511;
			RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
			*MouseState = TurnLeft;
			return;
		}
		if(sorted_fields[0] == Maze_DataStruct->maze_flood[Maze_DataStruct->X + Maze_DataStruct->left_neighbor][Maze_DataStruct->Y]){
			DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da - 5.340707511;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
			DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db + 5.340707511;
			RotateMouseOrientatioArray90degRight(Maze_DataStruct);
			*MouseState = TurnRight;
			return;
		}else {//TURN AROUND

			//USART_SendString("\rMouseState = Stop\n");
			//USART_SendString("\rAround\n");

			DifferentialDrive_DataStruct->distance_to_driveA = DifferentialDrive_DataStruct->Da + 10.68141502;//((pi/2)* whellbase)/2 || (2*pi*(whellbase)/2))/4
			DifferentialDrive_DataStruct->distance_to_driveB = DifferentialDrive_DataStruct->Db - 10.681415021;

			RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
			RotateMouseOrientatioArray90degLeft(Maze_DataStruct);
			*MouseState = TurnLeft;
			//*MouseState = TurnAround;
			//Direction_FlagStruct->dir_flagA = -1;
			//GPIO_ResetBits(BUZZER_PORT, BUZZER_PIN);
		}
	}
}

float32_t CutPidError(float32_t pid_regulation, int16_t max_power){
//	if(((pid_regulation > -500) && (pid_regulation < 500)) ? (1) : (0)){
//		return pid_regulation;
//	}else if(pid_regulation >= 500){
//		return (float32_t)-500;
//	}else {
//		return (float32_t)-500;
//	}
	
	if(abs(pid_regulation) <= max_power){
		return pid_regulation;
	}else{
		return pid_regulation > 0 ? max_power : -max_power;
	}
}

int8_t c = 0;
float32_t CutPidError2(PidData_TypeDef* PID_Regulator, float32_t pid_regulation, int16_t max_power){
//	if(((pid_regulation > -500) && (pid_regulation < 500)) ? (1) : (0)){
//		return pid_regulation;
//	}else if(pid_regulation >= 500){
//		return (float32_t)-500;
//	}else {
//		return (float32_t)-500;
//	}
	
	
	if(abs(pid_regulation) <= max_power){
		if(c){
			PidInit(&PID_Regulator->PID, PID_Regulator->kp, PID_Regulator->ki, PID_Regulator->kd);
			c = 0;
		}
		return pid_regulation;
	}else{
		c = 1;
		PidInit(&PID_Regulator->PID, PID_Regulator->kp, 0, PID_Regulator->kd);
		return pid_regulation > 0 ? max_power : -max_power;
	}
}

	// - (float32_t)IRSensors_DataStruct->SE_middle_value
void MouseInit2(IRSernorsData_InitTypeDef* IRSensors_DataStruct){
	int32_t	side_error = (int32_t)(getADCx(IRSensors_DataStruct, 2) - getADCx(IRSensors_DataStruct, 1));
	int32_t i, i_max = 10000;
	int32_t sample[4] = {0, 0, 0, 0};
	
	//PidInit(&PID_Regulator->PID, forward_kp, forward_ki + 1, forward_kd);
	IRSensors_DataStruct->SE_value_correct[0] = 0;
	IRSensors_DataStruct->SE_value_correct[1] = 0;
	IRSensors_DataStruct->SE_value_correct[2] = 0;
	IRSensors_DataStruct->SE_value_correct[3] = 0;
	
	while(!USART_GetFlagStatus(USART1, USART_FLAG_RXNE));
	USART_ClearFlag(USART1, USART_FLAG_RXNE);
	
	for(i = 0; i <= i_max; i++){
		sample[0] += IRSensors_DataStruct->SE_value[0];
		sample[1] += IRSensors_DataStruct->SE_value[1];
		sample[2] += IRSensors_DataStruct->SE_value[2];
		sample[3] += IRSensors_DataStruct->SE_value[3];
	}
	
	IRSensors_DataStruct->SE_value_correct[0] = sample[0]/i_max;
	IRSensors_DataStruct->SE_value_correct[1] = sample[1]/i_max;
	IRSensors_DataStruct->SE_value_correct[2] = sample[2]/i_max;
	IRSensors_DataStruct->SE_value_correct[3] = sample[3]/i_max;
	
	sprintf(USART_Buffer1.buffer, "\ra0: %d | a1: %d | a2: %d | a3: %d\n", 
															IRSensors_DataStruct->SE_value_correct[0], 
															IRSensors_DataStruct->SE_value_correct[1], 
															IRSensors_DataStruct->SE_value_correct[2], 
															IRSensors_DataStruct->SE_value_correct[3]);
	USART_SendString(USART_Buffer1.buffer);
	//EXTI_ClearITPendingBit(EXTI_Line8);
	while(!USART_GetFlagStatus(USART1, USART_FLAG_RXNE));
	USART_ClearFlag(USART1, USART_FLAG_RXNE);

	while(!USART_GetFlagStatus(USART1, USART_FLAG_RXNE)){
			
		sprintf(USART_Buffer1.buffer, "\ra0c: %d | a1c: %d | a2c: %d | a3c: %d\n", 
																	getADCx(IRSensors_DataStruct, 0), 
																	getADCx(IRSensors_DataStruct, 1), 
																	getADCx(IRSensors_DataStruct, 2), 
																	getADCx(IRSensors_DataStruct, 3));
			USART_SendString(USART_Buffer1.buffer);
		Delay(100);
	}
	USART_ClearFlag(USART1, USART_FLAG_RXNE);
}

void DriveDistance(enum Mouse_Status* MouseState, DifferentialDrive_TypeDef* DifferentialDrive_DataStruct, IRSernorsData_InitTypeDef* IRSensors_DataStruct, PidData_TypeDef PID_Regulator[],DirectionFlag_TypeDef* Direction_FlagStruct){
	if((getADCx(IRSensors_DataStruct, 1) >= Rside_wall_present) || (getADCx(IRSensors_DataStruct, 2) >= Lside_wall_present)){
		if(getADCx(IRSensors_DataStruct, 2) > getADCx(IRSensors_DataStruct, 1)){
			DifferentialDrive_DataStruct->rot_pd_regulator = CutPidError(arm_pid_f32(&PID_Regulator[2].PID, (float32_t)getADCx(IRSensors_DataStruct, 2)), DifferentialDrive_DataStruct->maxCCRpulse);
		}else{
			DifferentialDrive_DataStruct->rot_pd_regulator = CutPidError(arm_pid_f32(&PID_Regulator[2].PID, (float32_t)(-getADCx(IRSensors_DataStruct, 1))), DifferentialDrive_DataStruct->maxCCRpulse);
		}
	}else{
		DifferentialDrive_DataStruct->rot_pd_regulator = 0;
		arm_pid_reset_f32(&PID_Regulator[2].PID);
	}

	tmp_error = DifferentialDrive_DataStruct->distance_to_drive - DifferentialDrive_DataStruct->D;
	DifferentialDrive_DataStruct->trans_pd_regulator = CutPidError2(&PID_Regulator[4], arm_pid_f32(&PID_Regulator[4].PID, tmp_error), DifferentialDrive_DataStruct->maxCCRpulse);
	
	LeftMotor(Direction_FlagStruct, DifferentialDrive_DataStruct->trans_pd_regulator + DifferentialDrive_DataStruct->rot_pd_regulator);// + Error_DataStruct->irsensor_side);
	RightMotor(Direction_FlagStruct, DifferentialDrive_DataStruct->trans_pd_regulator - DifferentialDrive_DataStruct->rot_pd_regulator);
	
//	if(((DifferentialDrive_DataStruct->va == 0) || (DifferentialDrive_DataStruct->vb == 0))){
//		PidInit(&PID_Regulator[4].PID, PID_Regulator[4].kp, 10, PID_Regulator[4].kd); 
//		DifferentialDrive_DataStruct->maxCCRpulse = 1000;
//	}else{
//		PidInit(&PID_Regulator[4].PID, PID_Regulator[4].kp, PID_Regulator[4].ki, PID_Regulator[4].kd); 
//		DifferentialDrive_DataStruct->maxCCRpulse = 500;
//	}
	
	if(abs(tmp_error) <= 0.5){
		LeftHardStop();
		RightHardStop();
		arm_pid_reset_f32(&PID_Regulator[4].PID);
		arm_pid_reset_f32(&PID_Regulator[2].PID);
		*MouseState = NewSquare;
		//*MouseState = Stop;
		
	}
}

void LeftTurn(enum Mouse_Status* MouseState, DifferentialDrive_TypeDef* DifferentialDrive_DataStruct, IRSernorsData_InitTypeDef* IRSensors_DataStruct, PidData_TypeDef PID_Regulator[],DirectionFlag_TypeDef* Direction_FlagStruct){
//	if(getADCx(IRSensors_DataStruct, 2) > getADCx(IRSensors_DataStruct, 1)){
//		DifferentialDrive_DataStruct->rot_pd_regulator = CutPidError(arm_pid_f32(&PID_Regulator[2].PID, (float32_t)getADCx(IRSensors_DataStruct, 2) - (float32_t)IRSensors_DataStruct->SE_middle_value));
//	}else{
//		DifferentialDrive_DataStruct->rot_pd_regulator = CutPidError(arm_pid_f32(&PID_Regulator[2].PID, (float32_t)IRSensors_DataStruct->SE_middle_value - (float32_t)getADCx(IRSensors_DataStruct, 1)));
//	}

	//tmp_error = DifferentialDrive_DataStruct->distance_to_drive - DifferentialDrive_DataStruct->D;
	//DifferentialDrive_DataStruct->trans_pd_regulator = CutPidError(arm_pid_f32(&PID_Regulator[4].PID, tmp_error));
	tmp_errorA  =  DifferentialDrive_DataStruct->distance_to_driveA - DifferentialDrive_DataStruct->Da;
	DifferentialDrive_DataStruct->trans_pd_regulatorA = CutPidError(arm_pid_f32(&PID_Regulator[3].PID, tmp_errorA), DifferentialDrive_DataStruct->maxCCRpulse);
	
	tmp_errorB  =  DifferentialDrive_DataStruct->distance_to_driveB - DifferentialDrive_DataStruct->Db;
	DifferentialDrive_DataStruct->trans_pd_regulatorB = CutPidError(arm_pid_f32(&PID_Regulator[0].PID, tmp_errorB), DifferentialDrive_DataStruct->maxCCRpulse);
	
	//sprintf(USART_Buffer1.buffer, "\rerA: %f | erB: %f\n", tmp_errorA, tmp_errorB);USART_SendString(USART_Buffer1.buffer);
	LeftMotor(Direction_FlagStruct, DifferentialDrive_DataStruct->trans_pd_regulatorB);// + Error_DataStruct->irsensor_side);
	RightMotor(Direction_FlagStruct, DifferentialDrive_DataStruct->trans_pd_regulatorA);
	
	if(abs(tmp_errorA) <= 0.5){
		if(abs(tmp_errorB) <= 0.5){
			LeftHardStop();
			RightHardStop();
			arm_pid_reset_f32(&PID_Regulator[3].PID);
			arm_pid_reset_f32(&PID_Regulator[0].PID);
			//DifferentialDrive_DataStruct->maxCCRpulse = 500;
			*MouseState = DriveDist;
			//*MouseState = Stop;
			//*MouseState = NewSquare;
		}
	}
}

void RightTurn(enum Mouse_Status* MouseState, DifferentialDrive_TypeDef* DifferentialDrive_DataStruct, IRSernorsData_InitTypeDef* IRSensors_DataStruct, PidData_TypeDef PID_Regulator[],DirectionFlag_TypeDef* Direction_FlagStruct){
//	if(getADCx(IRSensors_DataStruct, 2) > getADCx(IRSensors_DataStruct, 1)){
//		DifferentialDrive_DataStruct->rot_pd_regulator = CutPidError(arm_pid_f32(&PID_Regulator[2].PID, (float32_t)getADCx(IRSensors_DataStruct, 2) - (float32_t)IRSensors_DataStruct->SE_middle_value));
//	}else{
//		DifferentialDrive_DataStruct->rot_pd_regulator = CutPidError(arm_pid_f32(&PID_Regulator[2].PID, (float32_t)IRSensors_DataStruct->SE_middle_value - (float32_t)getADCx(IRSensors_DataStruct, 1)));
//	}
	//tmp_error = DifferentialDrive_DataStruct->distance_to_drive - DifferentialDrive_DataStruct->D;
	//DifferentialDrive_DataStruct->trans_pd_regulator = CutPidError(arm_pid_f32(&PID_Regulator[4].PID, tmp_error));
	
	tmp_errorA  =  DifferentialDrive_DataStruct->distance_to_driveA - DifferentialDrive_DataStruct->Da;
	DifferentialDrive_DataStruct->trans_pd_regulatorA = CutPidError(arm_pid_f32(&PID_Regulator[3].PID, tmp_errorA), DifferentialDrive_DataStruct->maxCCRpulse);
	
	tmp_errorB  =  DifferentialDrive_DataStruct->distance_to_driveB - DifferentialDrive_DataStruct->Db;
	DifferentialDrive_DataStruct->trans_pd_regulatorB = CutPidError(arm_pid_f32(&PID_Regulator[0].PID, tmp_errorB), DifferentialDrive_DataStruct->maxCCRpulse);
//	
	
//	tmp_errorA  =  DifferentialDrive_DataStruct->distance_to_driveA - DifferentialDrive_DataStruct->Da;
//	DifferentialDrive_DataStruct->trans_pd_regulatorA = CutPidError2(&PID_Regulator[3], arm_pid_f32(&PID_Regulator[3].PID, tmp_errorA), DifferentialDrive_DataStruct->maxCCRpulse);
//	
//	tmp_errorB  =  DifferentialDrive_DataStruct->distance_to_driveB - DifferentialDrive_DataStruct->Db;
//	DifferentialDrive_DataStruct->trans_pd_regulatorB = CutPidError2(&PID_Regulator[0], arm_pid_f32(&PID_Regulator[0].PID, tmp_errorB), DifferentialDrive_DataStruct->maxCCRpulse);
//	
	
	//sprintf(USART_Buffer1.buffer, "\rerA: %f | erB: %f\n", tmp_errorA, tmp_errorB);USART_SendString(USART_Buffer1.buffer);
	LeftMotor(Direction_FlagStruct, DifferentialDrive_DataStruct->trans_pd_regulatorB);// + Error_DataStruct->irsensor_side);
	RightMotor(Direction_FlagStruct, DifferentialDrive_DataStruct->trans_pd_regulatorA);
	
//	if(((DifferentialDrive_DataStruct->va == 0) || (DifferentialDrive_DataStruct->vb == 0))){
//		//PidInit(&PID_Regulator[4].PID, PID_Regulator[4].kp, 10, PID_Regulator[4].kd); 
//		DifferentialDrive_DataStruct->maxCCRpulse = 1000;
//	}else{
//		//PidInit(&PID_Regulator[4].PID, PID_Regulator[4].kp, PID_Regulator[4].ki, PID_Regulator[4].kd); 
//		DifferentialDrive_DataStruct->maxCCRpulse = 500;
//	}

	if(abs(tmp_errorB) <= 0.5){
		if(abs(tmp_errorA) <= 0.5){
			LeftHardStop();
			RightHardStop();
			arm_pid_reset_f32(&PID_Regulator[3].PID);
			arm_pid_reset_f32(&PID_Regulator[0].PID);
			//DifferentialDrive_DataStruct->maxCCRpulse = 500;
			*MouseState = DriveDist;
			//*MouseState = Stop;
			//*MouseState = NewSquare;
		}
	}
}

void AroundLeftTurn(enum Mouse_Status* MouseState, DifferentialDrive_TypeDef* DifferentialDrive_DataStruct, IRSernorsData_InitTypeDef* IRSensors_DataStruct, PidData_TypeDef PID_Regulator[],DirectionFlag_TypeDef* Direction_FlagStruct){
//	if(getADCx(IRSensors_DataStruct, 2) > getADCx(IRSensors_DataStruct, 1)){
//		DifferentialDrive_DataStruct->rot_pd_regulator = CutPidError(arm_pid_f32(&PID_Regulator[2].PID, (float32_t)getADCx(IRSensors_DataStruct, 2) - (float32_t)IRSensors_DataStruct->SE_middle_value));
//	}else{
//		DifferentialDrive_DataStruct->rot_pd_regulator = CutPidError(arm_pid_f32(&PID_Regulator[2].PID, (float32_t)IRSensors_DataStruct->SE_middle_value - (float32_t)getADCx(IRSensors_DataStruct, 1)));
//	}

	//tmp_error = DifferentialDrive_DataStruct->distance_to_drive - DifferentialDrive_DataStruct->D;
	//DifferentialDrive_DataStruct->trans_pd_regulator = CutPidError(arm_pid_f32(&PID_Regulator[4].PID, tmp_error));
	
	tmp_errorA  =  DifferentialDrive_DataStruct->distance_to_driveA - DifferentialDrive_DataStruct->Da;
	DifferentialDrive_DataStruct->trans_pd_regulatorA = CutPidError(arm_pid_f32(&PID_Regulator[3].PID, tmp_errorA), 700);
	tmp_errorB  =  DifferentialDrive_DataStruct->distance_to_driveB - DifferentialDrive_DataStruct->Db;
	DifferentialDrive_DataStruct->trans_pd_regulatorB = CutPidError(arm_pid_f32(&PID_Regulator[3].PID, tmp_errorB), 700);
	
	LeftMotor(Direction_FlagStruct, DifferentialDrive_DataStruct->trans_pd_regulatorB);// + Error_DataStruct->irsensor_side);
	RightMotor(Direction_FlagStruct, DifferentialDrive_DataStruct->trans_pd_regulatorA);
	
	if(abs(tmp_errorA) <= 0.5){
		//*MouseState = Stop;
		if(abs(tmp_errorB) <= 0.5){
			*MouseState = Stop;
			//*MouseState = NewSquare;
		}
	}
}

void Turn90DegreesRightOneWheel(EncoderData_TypeDef *Encoders_DataStruct, enum Mouse_Status *MouseState, uint8_t *turn_speed){

}

void Turn90DegreesLeftOneWheel(EncoderData_TypeDef *Encoders_DataStruct, enum Mouse_Status *MouseState, uint8_t *turn_speed){

}

//float32_t ReturnPidError(arm_pid_instance_f32 *S, float32_t error, float min, float max, float32_t decrease_factor){
//	tmp_error = arm_pid_f32(S, (float32_t)error*decrease_factor);
//	if(((tmp_error > min) && (tmp_error < max)) ? (1) : (0)){
//		return tmp_error;
//	}else if(tmp_error >= max){
//		arm_pid_reset_f32(S);
//		return  max;
//	}else {
//		arm_pid_reset_f32(S);
//		return min;
//	}
//}

float32_t ReturnPidError(arm_pid_instance_f32 *S, float32_t error, int16_t se_max){
	tmp_error = arm_pid_f32(S, error);
	if(((tmp_error > -se_max) && (tmp_error < se_max)) ? (1) : (0)){
		return tmp_error;
	}else if(tmp_error >= se_max){
		arm_pid_reset_f32(S);
		return se_max;
	}else {
		arm_pid_reset_f32(S);
		return -se_max;
	}
}


	
//	tmp_error = arm_pid_f32(S, error);
//	if(((tmp_error > -se_max) && (tmp_error < se_max)) ? (1) : (0)){
//		return tmp_error;
//	}else if(tmp_error >= se_max){
//		arm_pid_reset_f32(S);
//		return se_max;
//	}else {
//		arm_pid_reset_f32(S);
//		return -se_max;
//	}


uint8_t break_pwm_perc_value;

void SpyWall(IRSernorsData_InitTypeDef* IRSensors_DataStruct, PidData_TypeDef PID_Regulator[], ErrorData_TypeDef * Error_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, int16_t pwm_ccr_value){
	Error_DataStruct->error_diff = 1;//(getADCx(IRSensors_DataStruct, 3) - getADCx(IRSensors_DataStruct, 0))*ready_error_corrctor_front;	
	Error_DataStruct->error =	acceptable_front_wall - (getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2;	
	//Error_DataStruct->error = arm_pid_f32(&IRSensors_DataStruct->PID, (float32_t)Error_DataStruct->error);
	if(Error_DataStruct->error > 0){
		//PidInit(&IRSensors_DataStruct->PID, PID_DataStruct->acc_kp, PID_DataStruct->acc_ki, PID_DataStruct->acc_kd); 
		Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[0].PID, (float32_t)Error_DataStruct->error, pwm_ccr_value);
		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front);
		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front);
	}else{
		//PidInit(&IRSensors_DataStruct->PID, PID_DataStruct->br_kp, PID_DataStruct->br_ki, PID_DataStruct->br_kd); 
		Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[1].PID, (float32_t)Error_DataStruct->error, pwm_ccr_value+500);
		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front);
		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front);
	}
}

void FloodMaze(enum Mouse_Status MouseState, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){
	if(MouseState == Test){
		Error_DataStruct->irsensor_front = acceptable_front_wall - (getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2;
		Error_DataStruct->irsensor_side = (getADCx(IRSensors_DataStruct, 2) - getADCx(IRSensors_DataStruct, 1));
		
		if(Error_DataStruct->irsensor_front > 0){
			//PidInit(&IRSensors_DataStruct->PID, IRSensors_DataStruct->kp, IRSensors_DataStruct->ki, IRSensors_DataStruct->kd); 
			Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[0].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value);
		}else{
			//PidInit(&IRSensors_DataStruct->PID, IRSensors_DataStruct->kp*3, IRSensors_DataStruct->ki*3, IRSensors_DataStruct->kd*3); 
			Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[1].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value+500);
		}

		Error_DataStruct->error_pid_correction_side = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_side, pwm_ccr_value);
		if(Error_DataStruct->irsensor_side > 0){
			LeftMotor(Direction_FlagStruct, Error_DataStruct->irsensor_front + Error_DataStruct->irsensor_side);
			RightMotor(Direction_FlagStruct, Error_DataStruct->irsensor_front);// - Error_DataStruct->irsensor_side);
		}else{
			LeftMotor(Direction_FlagStruct, Error_DataStruct->irsensor_front);// + Error_DataStruct->irsensor_side);
			RightMotor(Direction_FlagStruct, Error_DataStruct->irsensor_front - Error_DataStruct->irsensor_side);
		}
	}
}

void FollowTheWall(enum Mouse_Status* MouseState, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){
	Maze_DataStruct->SE_Right_vir = getADCx(IRSensors_DataStruct, 1);
	Maze_DataStruct->SE_Left_vir = getADCx(IRSensors_DataStruct, 2);
	
	if((Maze_DataStruct->SE_Left_vir < IRSensors_DataStruct->SE_middle_value)&&(Maze_DataStruct->SE_Right_vir < IRSensors_DataStruct->SE_middle_value)){
		if(Maze_DataStruct->SE_Left_vir > Maze_DataStruct->SE_Right_vir){
			Maze_DataStruct->SE_Right_vir = IRSensors_DataStruct->SE_middle_value;
		}else{
			Maze_DataStruct->SE_Left_vir = IRSensors_DataStruct->SE_middle_value;
		}
	}
	
	Error_DataStruct->irsensor_front = acceptable_front_wall - (getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2;
//		Error_DataStruct->irsensor_side =  getADCx(IRSensors_DataStruct, 2) - 1750;
	Error_DataStruct->irsensor_side = (Maze_DataStruct->SE_Left_vir - Maze_DataStruct->SE_Right_vir);
	if(abs(Error_DataStruct->irsensor_side) > 500){
		PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki + 1, forward_kd); 
	}else{
		PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki, forward_kd); 
	}
	if(Error_DataStruct->irsensor_front > 0){
		//PidInit(&IRSensors_DataStruct->PID, IRSensors_DataStruct->kp, IRSensors_DataStruct->ki, IRSensors_DataStruct->kd); 
		Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[0].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value);
		if(Error_DataStruct->error_pid_correction_front < 500) Error_DataStruct->error_pid_correction_front = 500;
	}else{
		//PidInit(&IRSensors_DataStruct->PID, IRSensors_DataStruct->kp*3, IRSensors_DataStruct->ki*3, IRSensors_DataStruct->kd*3); 
		Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[1].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value+500);
		if(Error_DataStruct->error_pid_correction_front < -500) Error_DataStruct->error_pid_correction_front = -500;
	}

	Error_DataStruct->error_pid_correction_side = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_side, pwm_ccr_value);
	if(Error_DataStruct->irsensor_side > 0){
		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front );
		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front - Error_DataStruct->error_pid_correction_side);// - Error_DataStruct->irsensor_side);
	}else{
		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front + Error_DataStruct->error_pid_correction_side);// + Error_DataStruct->irsensor_side);
		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front );
	}
	
	if(abs(Error_DataStruct->irsensor_front) < 350){
		LeftMotor(Direction_FlagStruct, -stop_ccr);
		RightMotor(Direction_FlagStruct, -stop_ccr);
		*MouseState = Stop;
	}
}
int8_t is_error_high = 0;
//void FollowOneWall(enum Mouse_Status* MouseState, 
//	MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], 
//	IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){	

//	if(getADCx(IRSensors_DataStruct, 2) > getADCx(IRSensors_DataStruct, 1)){
//		Error_DataStruct->irsensor_side_l = getADCx(IRSensors_DataStruct, 2) - IRSensors_DataStruct->SE_middle_value;
//		Error_DataStruct->irsensor_side_r = 0;
//		Error_DataStruct->error_pid_correction_side_r =  arm_pid_f32(&PID_Regulator[2].PID, Error_DataStruct->irsensor_side_l);//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);
//		Error_DataStruct->error_pid_correction_side_l =  0;//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);
//		//Error_DataStruct->irsensor_side_differ = getADCx(IRSensors_DataStruct, 2) - IRSensors_DataStruct->SE_middle_value;
//	}else{
//		Error_DataStruct->irsensor_side_r = getADCx(IRSensors_DataStruct, 1) - IRSensors_DataStruct->SE_middle_value;
//		Error_DataStruct->irsensor_side_l = 0;
//		Error_DataStruct->error_pid_correction_side_r =  0;//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);
//		Error_DataStruct->error_pid_correction_side_l =  arm_pid_f32(&PID_Regulator[5].PID, Error_DataStruct->irsensor_side_r);//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);
//		//Error_DataStruct->irsensor_side_differ = IRSensors_DataStruct->SE_middle_value - getADCx(IRSensors_DataStruct, 1);
//	}
//	
//	//Error_DataStruct->encoders_square_l = (bumps_per_suare - Encoders_DataStruct->bumpA);// * 102.5;
//	
//	Error_DataStruct->irsensor_front = acceptable_front_wall - (getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2;
//	//Error_DataStruct->encoders_square_r = bumps_per_suare - Encoders_DataStruct->bumpB;
//	
//	if(Error_DataStruct->error_pid_correction_front < 300){
//		PidInit(&PID_Regulator[4].PID, PID_Regulator[4].kp, PID_Regulator[4].ki, PID_Regulator[4].kd);
//	}else{
//		PidInit(&PID_Regulator[4].PID, PID_Regulator[4].kp, 0, PID_Regulator[4].kd);
//	}
//	

//	
//	Error_DataStruct->error_pid_correction_front = arm_pid_f32(&PID_Regulator[4].PID, Error_DataStruct->irsensor_front);//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_l, pwm_ccr_value);
//	//Error_DataStruct->error_pid_correction_front_r = arm_pid_f32(&PID_Regulator[4].PID, Error_DataStruct->encoders_square_r);//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);

////	if(Error_DataStruct->encoders_square_l != bumps_per_suare){
//		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front - Error_DataStruct->error_pid_correction_side_l);// + Error_DataStruct->irsensor_side);
//		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front - Error_DataStruct->error_pid_correction_side_r);
////	}else{
////		LeftHardStop();
////		RightHardStop();
////	}
//		
//	if(abs(Error_DataStruct->irsensor_front) < 350){
//		LeftMotor(Direction_FlagStruct, -stop_ccr);
//		RightMotor(Direction_FlagStruct, -stop_ccr);
//		//PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki + 1, forward_kd);
//		*MouseState = Decide;
//	}
//}

//void FollowOneWall(enum Mouse_Status* MouseState, 
//	MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], 
//	IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){	
//	if(getADCx(IRSensors_DataStruct, 2) > getADCx(IRSensors_DataStruct, 1)){
//		Error_DataStruct->irsensor_side = getADCx(IRSensors_DataStruct, 2) - IRSensors_DataStruct->SE_middle_value;
//	}else{
//		Error_DataStruct->irsensor_side = IRSensors_DataStruct->SE_middle_value - getADCx(IRSensors_DataStruct, 1);
//	}
//	
//	Error_DataStruct->irsensor_front = acceptable_front_wall - (getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2;
//	
//	if(Error_DataStruct->irsensor_front > 0){
//		//PidInit(&IRSensors_DataStruct->PID, IRSensors_DataStruct->kp, IRSensors_DataStruct->ki, IRSensors_DataStruct->kd); 
//		Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[0].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value);
//		//if(Error_DataStruct->error_pid_correction_front < 500) Error_DataStruct->error_pid_correction_front = 500;
//	}else{
//		//PidInit(&IRSensors_DataStruct->PID, IRSensors_DataStruct->kp*3, IRSensors_DataStruct->ki*3, IRSensors_DataStruct->kd*3); 
//		Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[1].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value+500);
//		//if(Error_DataStruct->error_pid_correction_front > -500) Error_DataStruct->error_pid_correction_front = -500;
//	}
//	//*************88Problem
//	if(abs(Error_DataStruct->irsensor_side) > high_error_level){
//		PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki, forward_kd);
//	}else{
//		PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki + 1, forward_kd); 
//	}
//	//********************Problem	
//	
//	Error_DataStruct->error_pid_correction_side = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_side, pwm_ccr_value);

//	if(Error_DataStruct->irsensor_side > 0){
//		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front );
//		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front - Error_DataStruct->error_pid_correction_side);// - Error_DataStruct->irsensor_side);
//	}else{
//		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front + Error_DataStruct->error_pid_correction_side);// + Error_DataStruct->irsensor_side);
//		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front );
//	}
//		
//	if(abs(Error_DataStruct->irsensor_front) < 350){
//		LeftMotor(Direction_FlagStruct, -stop_ccr);
//		RightMotor(Direction_FlagStruct, -stop_ccr);
//		PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki + 1, forward_kd);
//		*MouseState = Decide;
//	}
//}
	
void FollowOneWall(enum Mouse_Status* MouseState, 
	MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], 
	IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){	
	
	if(getADCx(IRSensors_DataStruct, 2) > getADCx(IRSensors_DataStruct, 1)){
		Error_DataStruct->irsensor_side_l = getADCx(IRSensors_DataStruct, 2) - IRSensors_DataStruct->SE_middle_value;
		Error_DataStruct->irsensor_side_r = 0;
		Error_DataStruct->error_pid_correction_side_r =  arm_pid_f32(&PID_Regulator[2].PID, Error_DataStruct->irsensor_side_l);//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);
		Error_DataStruct->error_pid_correction_side_l =  0;//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);
		//Error_DataStruct->irsensor_side_differ = getADCx(IRSensors_DataStruct, 2) - IRSensors_DataStruct->SE_middle_value;
	}else{
		Error_DataStruct->irsensor_side_r = getADCx(IRSensors_DataStruct, 1) - IRSensors_DataStruct->SE_middle_value;
		Error_DataStruct->irsensor_side_l = 0;
		Error_DataStruct->error_pid_correction_side_r =  0;//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);
		Error_DataStruct->error_pid_correction_side_l =  arm_pid_f32(&PID_Regulator[5].PID, Error_DataStruct->irsensor_side_r);//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);
		//Error_DataStruct->irsensor_side_differ = IRSensors_DataStruct->SE_middle_value - getADCx(IRSensors_DataStruct, 1);
	}

	
	Error_DataStruct->irsensor_front = acceptable_front_wall - (getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2;
	
	if(Error_DataStruct->irsensor_front > 0){
		//PidInit(&IRSensors_DataStruct->PID, IRSensors_DataStruct->kp, IRSensors_DataStruct->ki, IRSensors_DataStruct->kd); 
		Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[0].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value);
		//if(Error_DataStruct->error_pid_correction_front < 500) Error_DataStruct->error_pid_correction_front = 500;
	}else{
		//PidInit(&IRSensors_DataStruct->PID, IRSensors_DataStruct->kp*3, IRSensors_DataStruct->ki*3, IRSensors_DataStruct->kd*3); 
		Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[1].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value+500);
		//if(Error_DataStruct->error_pid_correction_front > -500) Error_DataStruct->error_pid_correction_front = -500;
	}
	//*************88Problem
	if(abs(Error_DataStruct->irsensor_side) > high_error_level){
		PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki, forward_kd);
	}else{
		PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki + 1, forward_kd); 
	}
	//********************Problem	
	
	Error_DataStruct->error_pid_correction_side = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_side, pwm_ccr_value);

	if(Error_DataStruct->irsensor_side > 0){
		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front -Error_DataStruct->error_pid_correction_side_l);
		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front -Error_DataStruct->error_pid_correction_side_r);// - Error_DataStruct->irsensor_side);
	}else{
		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front +Error_DataStruct->error_pid_correction_side_l);// + Error_DataStruct->irsensor_side);
		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front +Error_DataStruct->error_pid_correction_side_r);
	}
		
	if(abs(Error_DataStruct->irsensor_front) < 350){
		LeftMotor(Direction_FlagStruct, -stop_ccr);
		RightMotor(Direction_FlagStruct, -stop_ccr);
		PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki + 1, forward_kd);
		*MouseState = Decide;
	}
}
	

//float32_t CutPidError(float32_t pid_regulation){
////	if(((pid_regulation > -500) && (pid_regulation < 500)) ? (1) : (0)){
////		return pid_regulation;
////	}else if(pid_regulation >= 500){
////		return (float32_t)-500;
////	}else {
////		return (float32_t)-500;
////	}
//	
//	if(abs(pid_regulation) <= 500){
//		return pid_regulation;
//	}else{
//		return pid_regulation > 0 ? 500 : -500;
//	}
//}

void DriveSuareOneWall(enum Mouse_Status* MouseState, EncoderData_TypeDef *Encoders_DataStruct, 
	MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){	
	
	if(getADCx(IRSensors_DataStruct, 2) > getADCx(IRSensors_DataStruct, 1)){
		Error_DataStruct->irsensor_side_l = getADCx(IRSensors_DataStruct, 2) - IRSensors_DataStruct->SE_middle_value;
		Error_DataStruct->irsensor_side_r = 0;
		Error_DataStruct->error_pid_correction_side_r =  arm_pid_f32(&PID_Regulator[2].PID, Error_DataStruct->irsensor_side_l);//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);
		Error_DataStruct->error_pid_correction_side_l =  0;//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);
		//Error_DataStruct->irsensor_side_differ = getADCx(IRSensors_DataStruct, 2) - IRSensors_DataStruct->SE_middle_value;
	}else{
		Error_DataStruct->irsensor_side_r = getADCx(IRSensors_DataStruct, 1) - IRSensors_DataStruct->SE_middle_value;
		Error_DataStruct->irsensor_side_l = 0;
		Error_DataStruct->error_pid_correction_side_r =  0;//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);
		Error_DataStruct->error_pid_correction_side_l =  arm_pid_f32(&PID_Regulator[5].PID, Error_DataStruct->irsensor_side_r);//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);
		//Error_DataStruct->irsensor_side_differ = IRSensors_DataStruct->SE_middle_value - getADCx(IRSensors_DataStruct, 1);
	}
	
	Error_DataStruct->encoders_square_l = (bumps_per_suare - Encoders_DataStruct->bumpA);// * 102.5;
	//Error_DataStruct->encoders_square_r = bumps_per_suare - Encoders_DataStruct->bumpB;
	
	if(Error_DataStruct->error_pid_correction_front_l < 300){
		PidInit(&PID_Regulator[4].PID, PID_Regulator[4].kp, PID_Regulator[4].ki, PID_Regulator[4].kd);
	}else{
		PidInit(&PID_Regulator[4].PID, PID_Regulator[4].kp, 0, PID_Regulator[4].kd);
	}
	

	
	Error_DataStruct->error_pid_correction_front_l = arm_pid_f32(&PID_Regulator[4].PID, Error_DataStruct->encoders_square_l);//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_l, pwm_ccr_value);
	//Error_DataStruct->error_pid_correction_front_r = arm_pid_f32(&PID_Regulator[4].PID, Error_DataStruct->encoders_square_r);//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);

//	if(Error_DataStruct->encoders_square_l != bumps_per_suare){
		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front_l - Error_DataStruct->error_pid_correction_side_l);// + Error_DataStruct->irsensor_side);
		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front_l - Error_DataStruct->error_pid_correction_side_r);
//	}else{
//		LeftHardStop();
//		RightHardStop();
//	}

		if(Encoders_DataStruct->bumpA >= bumps_per_suare){
			Encoders_DataStruct->bumpA -= bumps_per_suare;
			LeftMotor(Direction_FlagStruct, -stop_ccr);
			RightMotor(Direction_FlagStruct, -stop_ccr);
			*MouseState = NewSquare;
		}
}

//void DriveSuareOneWall(enum Mouse_Status* MouseState, EncoderData_TypeDef *Encoders_DataStruct, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){	
//	if(getADCx(IRSensors_DataStruct, 2) > getADCx(IRSensors_DataStruct, 1)){
//		Error_DataStruct->irsensor_side = getADCx(IRSensors_DataStruct, 2) - IRSensors_DataStruct->SE_middle_value;
//	}else{
//		Error_DataStruct->irsensor_side = IRSensors_DataStruct->SE_middle_value - getADCx(IRSensors_DataStruct, 1);
//	}
//	
//	Error_DataStruct->irsensor_front = (bumps_per_suare - (Encoders_DataStruct->bumpA + Encoders_DataStruct->bumpB)/2) * 102.5;
//	
//	if(Error_DataStruct->irsensor_front > 0){
//		//PidInit(&IRSensors_DataStruct->PID, IRSensors_DataStruct->kp, IRSensors_DataStruct->ki, IRSensors_DataStruct->kd); 
//		Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[0].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value);
//		//if(Error_DataStruct->error_pid_correction_front < 500) Error_DataStruct->error_pid_correction_front = 500;
//	}else{
//		//PidInit(&IRSensors_DataStruct->PID, IRSensors_DataStruct->kp*3, IRSensors_DataStruct->ki*3, IRSensors_DataStruct->kd*3); 
//		Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[1].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value+500);
//		//if(Error_DataStruct->error_pid_correction_front > -500) Error_DataStruct->error_pid_correction_front = -500;
//	}
//	//*************88Problem
//	if(abs(Error_DataStruct->irsensor_side) > high_error_level){
//		PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki, forward_kd);
//	}else{
//		PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki + 1, forward_kd); 
//	}
//	//********************Problem	
//	
//	Error_DataStruct->error_pid_correction_side = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_side, pwm_ccr_value);

//	if(Error_DataStruct->irsensor_side > 0){
//		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front );
//		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front - Error_DataStruct->error_pid_correction_side);// - Error_DataStruct->irsensor_side);
//	}else{
//		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front + Error_DataStruct->error_pid_correction_side);// + Error_DataStruct->irsensor_side);
//		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front );
//	}
//		
//	if(abs(Error_DataStruct->irsensor_front) < 350){
//		LeftMotor(Direction_FlagStruct, -stop_ccr);
//		RightMotor(Direction_FlagStruct, -stop_ccr);
//		PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki + 1, forward_kd);
//		*MouseState = Stop;
//	}
//}

void MakeTurnLeftEnc(enum Mouse_Status* MouseState, EncoderData_TypeDef *Encoders_DataStruct, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){	
	Error_DataStruct->encoders_square_l = turn_bumps - Encoders_DataStruct->bumpA;// * 102.5;
	Error_DataStruct->encoders_square_r = turn_bumps - Encoders_DataStruct->bumpB;
	
	if(Error_DataStruct->error_pid_correction_front_l < 300){
		PidInit(&PID_Regulator[4].PID, PID_Regulator[4].kp, PID_Regulator[4].ki, PID_Regulator[4].kd);
	}else{
		PidInit(&PID_Regulator[4].PID, PID_Regulator[4].kp, 0, PID_Regulator[4].kd);
	}
	
	Error_DataStruct->error_pid_correction_front_l = arm_pid_f32(&PID_Regulator[4].PID, Error_DataStruct->encoders_square_l);//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_l, pwm_ccr_value);
	//Error_DataStruct->error_pid_correction_front_r = arm_pid_f32(&PID_Regulator[4].PID, Error_DataStruct->encoders_square_r);//ReturnPidError(&PID_Regulator[4].PID, (float32_t)Error_DataStruct->encoders_square_r, pwm_ccr_value);

//	if(Error_DataStruct->encoders_square_l != bumps_per_suare){
		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front_l + Error_DataStruct->error_pid_correction_side_l);// + Error_DataStruct->irsensor_side);
		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front_l + Error_DataStruct->error_pid_correction_side_r);
//	}else{
//		LeftHardStop();
//		RightHardStop();
//	}

		if((Encoders_DataStruct->bumpA >= turn_bumps) && (Encoders_DataStruct->bumpB >= turn_bumps)){
			Encoders_DataStruct->bumpA -= bumps_per_suare;
			Encoders_DataStruct->bumpB -= bumps_per_suare;
			LeftMotor(Direction_FlagStruct, -stop_ccr);
			RightMotor(Direction_FlagStruct, -stop_ccr);
			//*MouseState = Forward;
			*MouseState = Stop;
		}
}

void MakeTurnRight(enum Mouse_Status* MouseState, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){
	Error_DataStruct->irsensor_front = acceptable_front_wall - (getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2;
	Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value);
	
	Error_DataStruct->irsensor_side = getADCx(IRSensors_DataStruct, 2) - getADCx(IRSensors_DataStruct, 1);
	
	Error_DataStruct->error_pid_correction_side = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_side, pwm_ccr_value);
//USART_SendString("\rMT\n");	
	//if(Error_DataStruct->error_pid_correction_side < 500) Error_DataStruct->error_pid_correction_side = 500;

		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_side);
		RightMotor(Direction_FlagStruct, -stop_ccr);// - Error_DataStruct->irsensor_side);

		
	if(abs(getADCx(IRSensors_DataStruct, 0) + getADCx(IRSensors_DataStruct, 3))/2 < 350){
		LeftMotor(Direction_FlagStruct, -stop_ccr);	
		RightMotor(Direction_FlagStruct, -stop_ccr);
		*MouseState = Forward;
		Maze_DataStruct->mouse_dir = dir_north;
	}
}

void MakeTurnLeft(enum Mouse_Status* MouseState, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){

	Error_DataStruct->irsensor_side = getADCx(IRSensors_DataStruct, 2) - getADCx(IRSensors_DataStruct, 1);
	Error_DataStruct->error_pid_correction_side = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_side, pwm_ccr_value);
//USART_SendString("\rMT\n");	
	//if(Error_DataStruct->error_pid_correction_side > -500) Error_DataStruct->error_pid_correction_side = -500;

		LeftMotor(Direction_FlagStruct, -stop_ccr);// + Error_DataStruct->irsensor_side);
		RightMotor(Direction_FlagStruct, -Error_DataStruct->error_pid_correction_side);
		
	if(abs(getADCx(IRSensors_DataStruct, 0) + getADCx(IRSensors_DataStruct, 3))/2 < 350){
		LeftMotor(Direction_FlagStruct, -stop_ccr);	
		RightMotor(Direction_FlagStruct, -stop_ccr);
		*MouseState = Forward;
		Maze_DataStruct->mouse_dir = dir_north;
	}
}



void MakeTurnAroundRight(enum Mouse_Status* MouseState, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){
	Error_DataStruct->irsensor_front = acceptable_front_wall - (getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2;
	Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value);
	//		Error_DataStruct->irsensor_side =  getADCx(IRSensors_DataStruct, 2) - 1750;
	Error_DataStruct->irsensor_side = getADCx(IRSensors_DataStruct, 2) - getADCx(IRSensors_DataStruct, 1);
	
	
	Error_DataStruct->error_pid_correction_side = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_side, pwm_ccr_value);

	Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value);

//			if(Error_DataStruct->error_pid_correction_front < 500) Error_DataStruct->error_pid_correction_front = 500;
//			else if(Error_DataStruct->error_pid_correction_front > -500) Error_DataStruct->error_pid_correction_front = -500;
	
	//	
//	if(abs(Error_DataStruct->irsensor_front) < 350){
//		LeftMotor(Direction_FlagStruct, -400);	
//		RightMotor(Direction_FlagStruct, -400);
//	}else{
	//sprintf(USART_Buffer1.buffer, "\r%d\n", Error_DataStruct->irsensor_front);USART_SendString(USART_Buffer1.buffer);
//		USART_SendString("\rAR\n");
	//	if(Error_DataStruct->error_pid_correction_front < 500) Error_DataStruct->error_pid_correction_front = 500;	
		LeftMotor(Direction_FlagStruct, turn_ccr + Error_DataStruct->error_pid_correction_front);
		RightMotor(Direction_FlagStruct, -turn_ccr + Error_DataStruct->error_pid_correction_front);// - Error_DataStruct->irsensor_side);


//	}
//	if(Error_DataStruct->irsensor_side > 0){
//		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_side + Error_DataStruct->error_pid_correction_front);
//		RightMotor(Direction_FlagStruct, -Error_DataStruct->error_pid_correction_side - Error_DataStruct->error_pid_correction_front);// - Error_DataStruct->irsensor_side);
//	}else{
//		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_side + Error_DataStruct->error_pid_correction_front);// + Error_DataStruct->irsensor_side);
//		RightMotor(Direction_FlagStruct, -Error_DataStruct->error_pid_correction_side + Error_DataStruct->error_pid_correction_front);
//	}
		
	if(abs(getADCx(IRSensors_DataStruct, 0) + getADCx(IRSensors_DataStruct, 3))/2 < 350){
		LeftMotor(Direction_FlagStruct, -stop_ccr);
		RightMotor(Direction_FlagStruct, -stop_ccr);
		Maze_DataStruct->mouse_dir = dir_north;
		*MouseState = Forward;
	}
}
void MakeTurnAroundLeft(enum Mouse_Status* MouseState, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){
	Error_DataStruct->irsensor_front = acceptable_front_wall - (getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2;
//		Error_DataStruct->irsensor_side =  getADCx(IRSensors_DataStruct, 2) - 1750;
	Error_DataStruct->irsensor_side = getADCx(IRSensors_DataStruct, 2) - getADCx(IRSensors_DataStruct, 1);
	
	
	Error_DataStruct->error_pid_correction_side = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_side, pwm_ccr_value);

	Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value);

//			if(Error_DataStruct->error_pid_correction_front < 500) Error_DataStruct->error_pid_correction_front = 500;
//			else if(Error_DataStruct->error_pid_correction_front > -500) Error_DataStruct->error_pid_correction_front = -500;
//	USART_SendString("\rAL\n");
			//if(Error_DataStruct->error_pid_correction_front > -500) Error_DataStruct->error_pid_correction_front = -500;
			LeftMotor(Direction_FlagStruct, -turn_ccr + Error_DataStruct->error_pid_correction_front);// + Error_DataStruct->irsensor_side);
			RightMotor(Direction_FlagStruct, turn_ccr + Error_DataStruct->error_pid_correction_front);

//	}
//	if(Error_DataStruct->irsensor_side > 0){
//		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_side + Error_DataStruct->error_pid_correction_front);
//		RightMotor(Direction_FlagStruct, -Error_DataStruct->error_pid_correction_side - Error_DataStruct->error_pid_correction_front);// - Error_DataStruct->irsensor_side);
//	}else{
//		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_side + Error_DataStruct->error_pid_correction_front);// + Error_DataStruct->irsensor_side);
//		RightMotor(Direction_FlagStruct, -Error_DataStruct->error_pid_correction_side + Error_DataStruct->error_pid_correction_front);
//	}
		
	if(abs(getADCx(IRSensors_DataStruct, 0) + getADCx(IRSensors_DataStruct, 3))/2 < 350){
		LeftMotor(Direction_FlagStruct, -stop_ccr);
		RightMotor(Direction_FlagStruct, -stop_ccr);
		Maze_DataStruct->mouse_dir = dir_north;
		*MouseState = Forward;
	}
}

//float32_t turn_error;
void TurnRight90Degrees(enum Mouse_Status* MouseState, L3GD20_TypeDef* L3GD20_DataStruct, Time_TypeDef* Time_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef* PID_Regulator, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){
//	L3GD20_DataStruct->angle = 0;
//	L3GD20_DataStruct->prev_rate = 0;
//	sprintf(USART_Buffer1.buffer, "\rLError: %f, angle: %f\n", turn_error, L3GD20_DataStruct->angle);USART_SendString(USART_Buffer1.buffer);
	
		if(L3GD20_DataStruct->angle > -90){

			
			if(Time_DataStruct->time > sampleTime){
				Time_DataStruct->tmp_time = Time_DataStruct->time;
				Time_DataStruct->time = 0;
				L3GD20_ReadXYZ(L3GD20_DataStruct);
				if(L3GD20_DataStruct->Z > noise || L3GD20_DataStruct->Z < -noise){
					L3GD20_DataStruct->angle += ((L3GD20_DataStruct->prev_rate + (float32_t)L3GD20_DataStruct->Z) * (float32_t)Time_DataStruct->tmp_time) / (float32_t)2000;
					
					// remember the current speed for the next loop rate integration.
					L3GD20_DataStruct->prev_rate = L3GD20_DataStruct->Z;
				}
			}
			
			Error_DataStruct->gyro_error = arm_pid_f32(&PID_Regulator->PID,(float32_t)(-90 - L3GD20_DataStruct->angle));
			//sprintf(USART_Buffer1.buffer, "\rRError: %f\n", turn_error);USART_SendString(USART_Buffer1.buffer);
			
			LeftMotor(Direction_FlagStruct, -Error_DataStruct->gyro_error);
			RightMotor(Direction_FlagStruct, Error_DataStruct->gyro_error);
		}else{
				//Encoders_DataStruct->bumpB -= 4;
				L3GD20_DataStruct->angle = 0;
				L3GD20_DataStruct->prev_rate = 0;
				arm_pid_reset_f32(&PID_Regulator->PID);
				LeftMotor(Direction_FlagStruct, -stop_ccr);
				RightMotor(Direction_FlagStruct, stop_ccr);
				//*MouseState = Stop;
				*MouseState = Forward;
		}
}


void TurnLeft90Degrees(enum Mouse_Status* MouseState, L3GD20_TypeDef* L3GD20_DataStruct, Time_TypeDef* Time_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef* PID_Regulator, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){
//	L3GD20_DataStruct->angle = 0;
//	L3GD20_DataStruct->prev_rate = 0;
//		sprintf(USART_Buffer1.buffer, "\rLError: %f, angle: %f\n", turn_error, L3GD20_DataStruct->angle);USART_SendString(USART_Buffer1.buffer);
		if(L3GD20_DataStruct->angle < 90){
		
			if(Time_DataStruct->time > sampleTime){
				Time_DataStruct->tmp_time = Time_DataStruct->time;
				Time_DataStruct->time = 0;
				L3GD20_ReadXYZ(L3GD20_DataStruct);
				//rate = L3GD20_DataStruct->Z/100;
				//sampleNum++;
				//dc_offset = (sampleNum-1)*dc_offset+(1/sampleNum)*(int)gyro.g.z;
				if(L3GD20_DataStruct->Z > noise || L3GD20_DataStruct->Z < -noise){
					L3GD20_DataStruct->angle += ((L3GD20_DataStruct->prev_rate + (float32_t)L3GD20_DataStruct->Z) * (float32_t)Time_DataStruct->tmp_time) / (float32_t)2000;
				
					// remember the current speed for the next loop rate integration.
					L3GD20_DataStruct->prev_rate = L3GD20_DataStruct->Z;
				}

			}
			
			Error_DataStruct->gyro_error = arm_pid_f32(&PID_Regulator->PID, (float32_t)(90 - L3GD20_DataStruct->angle));
			
			RightMotor(Direction_FlagStruct, Error_DataStruct->gyro_error);
			LeftMotor(Direction_FlagStruct, -Error_DataStruct->gyro_error);
			
		}else{
			//Encoders_DataStruct->bumpB -= 4;
			L3GD20_DataStruct->angle = 0;
			L3GD20_DataStruct->prev_rate = 0;
			arm_pid_reset_f32(&PID_Regulator->PID);
			RightMotor(Direction_FlagStruct, -stop_ccr);
			LeftMotor(Direction_FlagStruct, stop_ccr);
			//*MouseState = Stop;
			*MouseState = Forward;
		}
}

void TurnRight180Degrees(enum Mouse_Status* MouseState, L3GD20_TypeDef* L3GD20_DataStruct, Time_TypeDef* Time_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef* PID_Regulator, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){
//	L3GD20_DataStruct->angle = 0;
//	L3GD20_DataStruct->prev_rate = 0;
//	sprintf(USART_Buffer1.buffer, "\rLError: %f, angle: %f\n", turn_error, L3GD20_DataStruct->angle);USART_SendString(USART_Buffer1.buffer);
	
		if(L3GD20_DataStruct->angle > -180){

			
			if(Time_DataStruct->time > sampleTime){
				Time_DataStruct->tmp_time = Time_DataStruct->time;
				Time_DataStruct->time = 0;
				L3GD20_ReadXYZ(L3GD20_DataStruct);
				if(L3GD20_DataStruct->Z > noise || L3GD20_DataStruct->Z < -noise){
					L3GD20_DataStruct->angle += ((L3GD20_DataStruct->prev_rate + (float32_t)L3GD20_DataStruct->Z) * (float32_t)Time_DataStruct->tmp_time) / (float32_t)2000;
					
					// remember the current speed for the next loop rate integration.
					L3GD20_DataStruct->prev_rate = L3GD20_DataStruct->Z;
				}
			}
			
			Error_DataStruct->gyro_error = arm_pid_f32(&PID_Regulator->PID,(float32_t)(-180 - L3GD20_DataStruct->angle));
			//sprintf(USART_Buffer1.buffer, "\rRError: %f\n", turn_error);USART_SendString(USART_Buffer1.buffer);
			
			LeftMotor(Direction_FlagStruct, -Error_DataStruct->gyro_error);
			RightMotor(Direction_FlagStruct, Error_DataStruct->gyro_error);
		}else{
				//Encoders_DataStruct->bumpB -= 4;
				L3GD20_DataStruct->angle = 0;
				L3GD20_DataStruct->prev_rate = 0;
				arm_pid_reset_f32(&PID_Regulator->PID);
				LeftMotor(Direction_FlagStruct, -stop_ccr);
				RightMotor(Direction_FlagStruct, stop_ccr);
				//*MouseState = Stop;
				*MouseState = Forward;
		}
}


void TurnLeft180Degrees(enum Mouse_Status* MouseState, L3GD20_TypeDef* L3GD20_DataStruct, Time_TypeDef* Time_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef* PID_Regulator, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){
//	L3GD20_DataStruct->angle = 0;
//	L3GD20_DataStruct->prev_rate = 0;
//		sprintf(USART_Buffer1.buffer, "\rLError: %f, angle: %f\n", turn_error, L3GD20_DataStruct->angle);USART_SendString(USART_Buffer1.buffer);
		if(L3GD20_DataStruct->angle < 180){
		
			if(Time_DataStruct->time > sampleTime){
				Time_DataStruct->tmp_time = Time_DataStruct->time;
				Time_DataStruct->time = 0;
				L3GD20_ReadXYZ(L3GD20_DataStruct);
				//rate = L3GD20_DataStruct->Z/100;
				//sampleNum++;
				//dc_offset = (sampleNum-1)*dc_offset+(1/sampleNum)*(int)gyro.g.z;
				if(L3GD20_DataStruct->Z > noise || L3GD20_DataStruct->Z < -noise){
					L3GD20_DataStruct->angle += ((L3GD20_DataStruct->prev_rate + (float32_t)L3GD20_DataStruct->Z) * (float32_t)Time_DataStruct->tmp_time) / (float32_t)2000;
				
					// remember the current speed for the next loop rate integration.
					L3GD20_DataStruct->prev_rate = L3GD20_DataStruct->Z;
				}

			}
			
			Error_DataStruct->gyro_error = arm_pid_f32(&PID_Regulator->PID, (float32_t)(180 - L3GD20_DataStruct->angle));
			
			RightMotor(Direction_FlagStruct, Error_DataStruct->gyro_error);
			LeftMotor(Direction_FlagStruct, -Error_DataStruct->gyro_error);
			
		}else{
			//Encoders_DataStruct->bumpB -= 4;
			L3GD20_DataStruct->angle = 0;
			L3GD20_DataStruct->prev_rate = 0;
			arm_pid_reset_f32(&PID_Regulator->PID);
			RightMotor(Direction_FlagStruct, -stop_ccr);
			LeftMotor(Direction_FlagStruct, stop_ccr);
			//*MouseState = Stop;
			*MouseState = Forward;
		}
}


void MakeTurnAroundGyro(enum Mouse_Status* MouseState, L3GD20_TypeDef* L3GD20_DataStruct, Time_TypeDef* Time_DataStruct, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, DirectionFlag_TypeDef* Direction_FlagStruct, uint16_t pwm_ccr_value){
		
//	L3GD20_DataStruct->angle = 0;
//	L3GD20_DataStruct->prev_rate = 0;
	if(*MouseState == TurnAroundLeft){
		if(L3GD20_DataStruct->angle < 180){
			Error_DataStruct->gyro_error = ReturnPidError(&PID_Regulator->PID, (float32_t)(180 - L3GD20_DataStruct->angle), pwm_ccr_value);
			//sprintf(USART_Buffer1.buffer, "\rAError: %f\n", Error_DataStruct->gyro_error);USART_SendString(USART_Buffer1.buffer);
			
			RightMotor(Direction_FlagStruct, Error_DataStruct->gyro_error);
			LeftMotor(Direction_FlagStruct, -Error_DataStruct->gyro_error);
			
			if(Time_DataStruct->time > sampleTime){
				Time_DataStruct->tmp_time = Time_DataStruct->time;
				Time_DataStruct->time = 0;
				L3GD20_ReadXYZ(L3GD20_DataStruct);
				if(L3GD20_DataStruct->Z > noise || L3GD20_DataStruct->Z < -noise){
					L3GD20_DataStruct->angle += ((double)(L3GD20_DataStruct->prev_rate + (double)L3GD20_DataStruct->Z) * (double)Time_DataStruct->tmp_time) / (double)2000;
					// remember the current speed for the next loop rate integration.
					L3GD20_DataStruct->prev_rate = L3GD20_DataStruct->Z;
				}
			}
		}else{
			//Encoders_DataStruct->bumpB -= 4;
			L3GD20_DataStruct->angle = 0;
			L3GD20_DataStruct->prev_rate = 0;
			arm_pid_reset_f32(&PID_Regulator->PID);
			RightMotor(Direction_FlagStruct, -stop_ccr);
			LeftMotor(Direction_FlagStruct, stop_ccr);
			*MouseState = Forward;
		}
	}
}

//void MakeTurnAround(enum Mouse_Status* MouseState, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, uint16_t pwm_ccr_value){
//	if(abs(getADCx(IRSensors_DataStruct, 0) + getADCx(IRSensors_DataStruct, 3))/2 > 350){
//		if(getADCx(IRSensors_DataStruct, 2) > getADCx(IRSensors_DataStruct, 1)){
//			LeftMotor(Direction_FlagStruct, turn_ccr);// + Error_DataStruct->irsensor_side);
//			RightMotor(Direction_FlagStruct, -turn_ccr);
//		}else{
//			LeftMotor(Direction_FlagStruct, -turn_ccr);// + Error_DataStruct->irsensor_side);
//			RightMotor(Direction_FlagStruct, turn_ccr);
//		}
//	}else{
//		LeftMotor(Direction_FlagStruct, -stop_ccr);
//		RightMotor(Direction_FlagStruct, -stop_ccr);
//		*MouseState = Forward;
//	}
//}

//void MakeTurnLeft(){
//	
//}
//void FollowOneWall(enum Mouse_Status* MouseState, MazeData_TypeDef* Maze_DataStruct, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, uint16_t pwm_ccr_value){	
//	if(getADCx(IRSensors_DataStruct, 2) > getADCx(IRSensors_DataStruct, 1)){
//		Error_DataStruct->irsensor_side = getADCx(IRSensors_DataStruct, 2) - IRSensors_DataStruct->SE_middle_value;
//	}else{
//		Error_DataStruct->irsensor_side = IRSensors_DataStruct->SE_middle_value - getADCx(IRSensors_DataStruct, 1);
//	}
//	
//	Error_DataStruct->irsensor_front = acceptable_front_wall - (getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2;
//	
//	if(Error_DataStruct->irsensor_front > 0){
//		//PidInit(&IRSensors_DataStruct->PID, IRSensors_DataStruct->kp, IRSensors_DataStruct->ki, IRSensors_DataStruct->kd); 
//		Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[0].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value);
//		
//	}else{
//		//PidInit(&IRSensors_DataStruct->PID, IRSensors_DataStruct->kp*3, IRSensors_DataStruct->ki*3, IRSensors_DataStruct->kd*3); 
//		Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[1].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value+500);
//	}
//	//*************88Problem
//	if(abs(Error_DataStruct->irsensor_side) > high_error_level){
//		PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki, forward_kd);
//	}else{
//		PidInit(&PID_Regulator[2].PID, forward_kp, forward_ki + 1, forward_kd); 
//	}
//	//********************Problem	
//	
//	Error_DataStruct->error_pid_correction_side = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_side, pwm_ccr_value);

//	if(Error_DataStruct->irsensor_side > 0){
//		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front );
//		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front - Error_DataStruct->error_pid_correction_side);// - Error_DataStruct->irsensor_side);
//	}else{
//		LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front + Error_DataStruct->error_pid_correction_side);// + Error_DataStruct->irsensor_side);
//		RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front );
//	}
//		
//	if(abs(Error_DataStruct->irsensor_front) < 350){
//		LeftMotor(Direction_FlagStruct, -stop_ccr);
//		RightMotor(Direction_FlagStruct, -stop_ccr);
//		*MouseState = Decide;
//	}
//}

void MouseInit(IRSernorsData_InitTypeDef* IRSensors_DataStruct, MazeData_TypeDef* Maze_DataStruct, PidData_TypeDef* PID_Regulator, DirectionFlag_TypeDef* Direction_FlagStruct){
	int32_t	side_error = (int32_t)(getADCx(IRSensors_DataStruct, 2) - getADCx(IRSensors_DataStruct, 1));
	PidInit(&PID_Regulator->PID, forward_kp, forward_ki + 1, forward_kd);
	while(abs(side_error) > 50){
		side_error = ReturnPidError(&PID_Regulator->PID, side_error, 500);
		sprintf(USART_Buffer1.buffer, "\r%d\n", side_error);USART_SendString(USART_Buffer1.buffer);
		if(side_error < 0){
			RightMotor(Direction_FlagStruct, -side_error);
			LeftMotor(Direction_FlagStruct, -stop_ccr);
		}else if(side_error > 0){
			LeftMotor(Direction_FlagStruct, side_error);
			RightMotor(Direction_FlagStruct, -stop_ccr);
		}
		side_error = (int32_t)(getADCx(IRSensors_DataStruct, 2) - getADCx(IRSensors_DataStruct, 1));
	}
	IRSensors_DataStruct->SE_middle_value = getADCx(IRSensors_DataStruct, 2);
	LeftMotor(Direction_FlagStruct, -stop_ccr);
	RightMotor(Direction_FlagStruct, -stop_ccr);
}


//void FollowTheWall(enum Mouse_Status MouseState, ErrorData_TypeDef * Error_DataStruct, PidData_TypeDef PID_Regulator[], IRSernorsData_InitTypeDef* IRSensors_DataStruct, uint16_t pwm_ccr_value){
//	if(MouseState == Flood){
//		Error_DataStruct->irsensor_front = acceptable_front_wall - (getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2;
////		Error_DataStruct->irsensor_side =  getADCx(IRSensors_DataStruct, 2) - 1750;
//		Error_DataStruct->irsensor_side = (getADCx(IRSensors_DataStruct, 2) - getADCx(IRSensors_DataStruct, 1));
//				
//		if(Error_DataStruct->irsensor_front > 0){
//			//PidInit(&IRSensors_DataStruct->PID, IRSensors_DataStruct->kp, IRSensors_DataStruct->ki, IRSensors_DataStruct->kd); 
//			Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[0].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value);
//			
//		}else{
//			//PidInit(&IRSensors_DataStruct->PID, IRSensors_DataStruct->kp*3, IRSensors_DataStruct->ki*3, IRSensors_DataStruct->kd*3); 
//			Error_DataStruct->error_pid_correction_front = ReturnPidError(&PID_Regulator[1].PID, (float32_t)Error_DataStruct->irsensor_front, pwm_ccr_value+500);
//		}

//		Error_DataStruct->error_pid_correction_side = ReturnPidError(&PID_Regulator[2].PID, (float32_t)Error_DataStruct->irsensor_side, pwm_ccr_value);
//		if(Error_DataStruct->irsensor_side > 0){
//			LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front + Error_DataStruct->error_pid_correction_side);
//			RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front);// - Error_DataStruct->irsensor_side);
//		}else{
//			LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front);// + Error_DataStruct->irsensor_side);
//			RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction_front - Error_DataStruct->error_pid_correction_side);
//		}
//		
//		if(abs(Error_DataStruct->irsensor_front) < 350){
//			LeftMotor(Direction_FlagStruct, -5);
//			RightMotor(Direction_FlagStruct, -5);
//			MouseState = Stop;
//		}
//	}
//}

//void SpyWall(IRSernorsData_InitTypeDef* IRSensors_DataStruct, ErrorData_TypeDef * Error_DataStruct, uint8_t pwm_perc_value){
//	Error_DataStruct->error_diff = 1;//(getADCx(IRSensors_DataStruct, 3) - getADCx(IRSensors_DataStruct, 0))*ready_error_corrctor_front;	
//	Error_DataStruct->error = acceptable_front_wall - (getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2;	
//	Error_DataStruct->error_pid_correction = ReturnPidError(&IRSensors_DataStruct->PID, (float32_t)Error_DataStruct->error, -pwm_perc_value, pwm_perc_value, ready_error_corrctor_front);
//	//Delay(5);
//	//sprintf(USART_Buffer1.buffer, "\rError: %f\n", Error_DataStruct->error_pid_correction);USART_SendString(USART_Buffer1.buffer);
//	break_pwm_perc_value = pwm_perc_value;
//	if(((getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2) >= front_is_in_square){
//		if(abs(Error_DataStruct->error) > error_tolerance){
//			if(abs((int)Error_DataStruct->error_pid_correction) < 10){
//				LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction*2);
//				RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction*2);
//			}
//			LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction);
//			RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction);
//	//		if(Error_DataStruct->error > 0){
//	//			LeftForward(&Direction_FlagStruct, pwm_perc_value);
//	//			RightForward(&Direction_FlagStruct, pwm_perc_value);
//	//		}else{
//	//			LeftBackward(&Direction_FlagStruct, break_pwm_perc_value);
//	//			RightBackward(&Direction_FlagStruct, break_pwm_perc_value);
//	//		}
//		}else{
//			LeftMotor(Direction_FlagStruct, -5);
//			RightMotor(Direction_FlagStruct, -5);
//		}
//	}else{
//		LeftMotor(Direction_FlagStruct, 30);
//		RightMotor(Direction_FlagStruct, 30);
//	}
//}

int16_t StopFunction(IRSernorsData_InitTypeDef* IRSensors_DataStruct, uint8_t pwm_perc_value){
	return ((-(pwm_perc_value/front_is_in_square))*((getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2) + pwm_perc_value);
}

//void DriveForward(IRSernorsData_InitTypeDef* IRSensors_DataStruct, ErrorData_TypeDef * Error_DataStruct, uint8_t pwm_perc_value){
//	Error_DataStruct->error = StopFunction(IRSensors_DataStruct, pwm_perc_value);
//	LeftMotor(Direction_FlagStruct, Error_DataStruct->error);
//	RightMotor(Direction_FlagStruct, Error_DataStruct->error);
//	
//	Error_DataStruct->error_diff = 1;//(getADCx(IRSensors_DataStruct, 3) - getADCx(IRSensors_DataStruct, 0))*ready_error_corrctor_front;	
//	Error_DataStruct->error = acceptable_front_wall - (getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2;	
//	Error_DataStruct->error_pid_correction = ReturnPidError(&IRSensors_DataStruct->PID, (float32_t)Error_DataStruct->error, -35, 35, ready_error_corrctor_front);
//	//Delay(5);
//	//sprintf(USART_Buffer1.buffer, "\rError: %f\n", Error_DataStruct->error_pid_correction);USART_SendString(USART_Buffer1.buffer);
//	break_pwm_perc_value = pwm_perc_value;
//	if(abs(Error_DataStruct->error) > error_tolerance){
//			LeftMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction);
//			RightMotor(Direction_FlagStruct, Error_DataStruct->error_pid_correction);
//	}else{
//		LeftMotor(Direction_FlagStruct, -5);
//		RightMotor(Direction_FlagStruct, -5);
//	}
//}
//void SpyWall(IRSernorsData_InitTypeDef* IRSensors_DataStruct, ErrorData_TypeDef * Error_DataStruct, uint8_t pwm_perc_value){
//	Error_DataStruct->error_diff = 1;//(getADCx(IRSensors_DataStruct, 3) - getADCx(IRSensors_DataStruct, 0))*ready_error_corrctor_front;	
//	Error_DataStruct->error = acceptable_front_wall - (getADCx(IRSensors_DataStruct, 3) + getADCx(IRSensors_DataStruct, 0))/2;	
//	//Error_DataStruct->error_pid_correction = ReturnPidError(&IRSensors_DataStruct->PID, (float)Error_DataStruct->error, -25, 25, ready_error_corrctor_front);
//	//sprintf(USART_Buffer1.buffer, "\rError: %f\n", Error_DataStruct->error_pid_correction);USART_SendString(USART_Buffer1.buffer);
//	break_pwm_perc_value = pwm_perc_value;
//	if(abs(Error_DataStruct->error) > error_tolerance){
//		if(Error_DataStruct->error > 0){
//			LeftForward(&Direction_FlagStruct, pwm_perc_value);
//			RightForward(&Direction_FlagStruct, pwm_perc_value);
//		}else{
//			LeftBackward(&Direction_FlagStruct, break_pwm_perc_value);
//			RightBackward(&Direction_FlagStruct, break_pwm_perc_value);
//		}
//	}else{
//			LeftMotor(Direction_FlagStruct, -5);
//			RightMotor(Direction_FlagStruct, -5);
//	}
//}

void PidInitR(arm_pid_instance_f32 * S, float32_t KP, float32_t KI, float32_t KD){
	S->Kp = KP;		/* Proporcional */
	S->Ki = KI;		/* Integral */
	S->Kd = KD;		/* derivative */
	arm_pid_init_f32(S, 1);
}

void PidInit(arm_pid_instance_f32 * S, float32_t KP, float32_t KI, float32_t KD){
	S->Kp = KP;		/* Proporcional */
	S->Ki = KI;		/* Integral */
	S->Kd = KD;		/* derivative */
	arm_pid_init_f32(S, 0);
}

void PidInsert(PidData_TypeDef* PID_Regulator, USARTBuffer_TypeDef* USART_Buffer){
	arm_pid_reset_f32(&PID_Regulator->PID);
	PidInit(&PID_Regulator->PID, 0, 0, 0);

	USART_ClearFlag(USART1, USART_FLAG_RXNE);
	USART_Puts("\rInsert: \n");
	USART_Puts("\rkp = ");PID_Regulator->kp = USART_geti();
	USART_Puts("\n\rki = ");PID_Regulator->ki = USART_geti();
	USART_Puts("\n\rkd = ");PID_Regulator->kd = USART_geti();
		
	//sprintf(USART_Buffer->buffer, "\rYour values: kp = %f, ki = %f, kd = %f \n", PID_Regulator->kp, PID_Regulator->ki, PID_Regulator->kd);USART_Puts(USART_Buffer->buffer);
	//USART_ClearITPendingBit(USART1, USART_FLAG_RXNE);
	//fflush();
	PidInit(&PID_Regulator->PID, PID_Regulator->kp, PID_Regulator->ki, PID_Regulator->kd);
}

void  Button_Initialize(void){
  GPIO_InitTypeDef  GPIO_InitStructure;
	
	/* GPIOG Peripheral clock enable */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);

  /* Configure PG6 and PG8 in output pushpull mode */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
}

//float32_t GetAngle(L3GD20_TypeDef* L3GD20_DataStruct){

//}

//void TurnRight90Degrees(enum Mouse_Status* MouseState, L3GD20_TypeDef* L3GD20_DataStruct, Time_TypeDef* Time_DataStruct, PidData_TypeDef* PID_Regulator, uint16_t pwm_ccr_value){
////	L3GD20_DataStruct->angle = 0;
////	L3GD20_DataStruct->prev_rate = 0;
//	
//	while(*MouseState == TurnRight){
//		if(L3GD20_DataStruct->angle > -90){
//			turn_error = ReturnPidError(&PID_Regulator->PID, (float32_t)(-90 - L3GD20_DataStruct->angle), pwm_ccr_value);
//			sprintf(USART_Buffer1.buffer, "\rError: %f\n", turn_error);USART_SendString(USART_Buffer1.buffer);
//			
//			LeftMotor(Direction_FlagStruct, -turn_error);
//			RightMotor(Direction_FlagStruct, turn_error);
//			
//			if(Time_DataStruct->time > sampleTime){
//				Time_DataStruct->tmp_time = Time_DataStruct->time;
//				Time_DataStruct->time = 0;
//				L3GD20_ReadXYZ(L3GD20_DataStruct);
//				if(L3GD20_DataStruct->Z > noise || L3GD20_DataStruct->Z < -noise){
//					L3GD20_DataStruct->angle += ((double)(L3GD20_DataStruct->prev_rate + (double)L3GD20_DataStruct->Z) * (double)Time_DataStruct->tmp_time) / (double)2000;
//					// remember the current speed for the next loop rate integration.
//					L3GD20_DataStruct->prev_rate = L3GD20_DataStruct->Z;
//				}
//			}
//		}else{
//				//Encoders_DataStruct->bumpB -= 4;
//				L3GD20_DataStruct->angle = 0;
//				L3GD20_DataStruct->prev_rate = 0;
//				arm_pid_reset_f32(&PID_Regulator->PID);
//				LeftMotor(Direction_FlagStruct, -350);
//				RightMotor(Direction_FlagStruct, 350);
//				*MouseState = Forward;
//		}
//	}
//}

//void TurnLeft90Degrees(enum Mouse_Status* MouseState, L3GD20_TypeDef* L3GD20_DataStruct, Time_TypeDef* Time_DataStruct, PidData_TypeDef* PID_Regulator, uint16_t pwm_ccr_value){
////	L3GD20_DataStruct->angle = 0;
////	L3GD20_DataStruct->prev_rate = 0;
//	
//	while(*MouseState == TurnLeft){
//		if(L3GD20_DataStruct->angle < 90){
//			turn_error = ReturnPidError(&PID_Regulator->PID, (float32_t)(90 - L3GD20_DataStruct->angle), pwm_ccr_value);
//			sprintf(USART_Buffer1.buffer, "\rError: %f\n", turn_error);USART_SendString(USART_Buffer1.buffer);
//			
//			RightMotor(Direction_FlagStruct, turn_error);
//			LeftMotor(Direction_FlagStruct, -turn_error);
//			
//			if(Time_DataStruct->time > sampleTime){
//				Time_DataStruct->tmp_time = Time_DataStruct->time;
//				Time_DataStruct->time = 0;
//				L3GD20_ReadXYZ(L3GD20_DataStruct);
//				if(L3GD20_DataStruct->Z > noise || L3GD20_DataStruct->Z < -noise){
//					L3GD20_DataStruct->angle += ((double)(L3GD20_DataStruct->prev_rate + (double)L3GD20_DataStruct->Z) * (double)Time_DataStruct->tmp_time) / (double)2000;
//					// remember the current speed for the next loop rate integration.
//					L3GD20_DataStruct->prev_rate = L3GD20_DataStruct->Z;
//				}
//			}
//		}else{
//			//Encoders_DataStruct->bumpB -= 4;
//			L3GD20_DataStruct->angle = 0;
//			L3GD20_DataStruct->prev_rate = 0;
//			arm_pid_reset_f32(&PID_Regulator->PID);
//			RightMotor(Direction_FlagStruct, -350);
//			LeftMotor(Direction_FlagStruct, 350);
//			*MouseState = Forward;
//		}
//	}
//}
