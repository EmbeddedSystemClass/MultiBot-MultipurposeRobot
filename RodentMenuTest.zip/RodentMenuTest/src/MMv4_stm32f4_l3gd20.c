#include "MMv4_stm32f4_l3gd20.h"	

L3GD20_Scale_TypeDef L3GD20_INT_Scale;

void I2C1_L3GD20_Init(void){
	GPIO_InitTypeDef I2C_GPIO_InitStructure;
	I2C_InitTypeDef	I2C_InitStructure;
	
	/*I2C clock enable */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);
	/*SDA and SCL GPIO clock enable */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	
	
	/* Configure USART SCL and SDA  */
	I2C_GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8| GPIO_Pin_9;
	I2C_GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	I2C_GPIO_InitStructure.GPIO_Speed = GPIO_Speed_25MHz;
	I2C_GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
	I2C_GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOB, &I2C_GPIO_InitStructure);
	
	/* Connect PXx to I2Cx_SCLx*/
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource8, GPIO_AF_I2C1);

	/* Connect PXx to I2Cx_SDAx*/
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource9, GPIO_AF_I2C1);
	
	/* Deinitalize I2C */
	I2C_DeInit(I2C1); 
	
	/* Configure I2C1 */
	I2C_InitStructure.I2C_ClockSpeed = L3G_I2C_CLOCK;
	I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
	I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2; 	// 50% duty cycle
	I2C_InitStructure.I2C_OwnAddress1 = 0x00;	//own address (not important in master mode)
	I2C_InitStructure.I2C_Ack = I2C_Ack_Disable;	//disable acknowledge while reading
	I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;	//set address length to 7 bit
	
	I2C1->CR1 &= ~I2C_CR1_PE; //Disable I2C first
	I2C_Init(I2C1, &I2C_InitStructure);	//initialise I2C1
	
	/* Enable I2C */
	I2C_Cmd(I2C1, ENABLE);
	
}

void I2C1_Start(I2C_TypeDef* I2Cx, uint8_t address, uint8_t direction){
	// wait if busy
	while(I2C_GetFlagStatus(I2Cx, I2C_FLAG_BUSY));
  
	// START I2C
	I2C_GenerateSTART(I2Cx, ENABLE);
	  
	// wait till I2C ready
	while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT));
		
	// Send slave address 
	I2C_Send7bitAddress(I2Cx, address, direction);

	if(direction == I2C_Direction_Transmitter){
		while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));
	}
	else if(direction == I2C_Direction_Receiver){
		while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED));
	}
}

void I2C_Stop(I2C_TypeDef* I2Cx){
	I2C_GenerateSTOP(I2Cx, ENABLE);
}

void I2C_Write(I2C_TypeDef* I2Cx, uint8_t data){
	// wait till ready
	while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTING));
	I2C_SendData(I2Cx, data);
	//Delay(1);
}

uint8_t I2C_Read_Ack(I2C_TypeDef* I2Cx){
	uint8_t recived_data;
	// enable acknowledge
	I2C_AcknowledgeConfig(I2Cx, ENABLE);
	// wait for data
	while( !I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED) );
	// read and save data 
	recived_data = I2C_ReceiveData(I2Cx);
	return recived_data;
}

uint8_t I2C_NoAck_Read(I2C_TypeDef* I2Cx){
	uint8_t recived_data;
	
	I2C_AcknowledgeConfig(I2Cx, DISABLE);
	
	I2C_GenerateSTOP(I2Cx, ENABLE);
	// wait for data
	while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED));
	// read and save data
	recived_data = I2C_ReceiveData(I2Cx);
	return recived_data;
}

L3GD20_State_TypeDef L3GD20_Initialize(L3GD20_TypeDef* L3GD20_InitStruct, L3GD20_Scale_TypeDef scale){
	uint8_t tmp_received_data;	
	
	L3GD20_InitStruct->Address = D20_SA0_HIGH_ADDRESS;
	I2C1_L3GD20_Init();
	
	//USART_Puts("1\r\n");
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Transmitter);
	I2C_Write(I2C1, WHO_AM_I);
	Delay(3);
	I2C_Stop(I2C1);
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Receiver);
	tmp_received_data = I2C_NoAck_Read(I2C1);
	
	if (tmp_received_data != D20H_WHO_ID) {
		return L3GD20_State_Error; //L3GD20 not connected
	}
	
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Transmitter);
	I2C_Write(I2C1, CTRL_REG1); // write one byte to the slave
	Delay(3);
	I2C_Write(I2C1, 0xFF);
	Delay(3);
	I2C_Stop(I2C1);
	
	if(scale == L3GD20_Scale_250){
		I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Transmitter);
		I2C_Write(I2C1, CTRL_REG4); // write one byte to the slave
		Delay(3);
		I2C_Write(I2C1, 0x00);
		Delay(3);
		I2C_Stop(I2C1);
	}else if (scale == L3GD20_Scale_500){
		I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Transmitter);
		I2C_Write(I2C1, CTRL_REG4); // write one byte to the slave
		Delay(3);
		I2C_Write(I2C1, 0x10);
		Delay(3);
		I2C_Stop(I2C1);
	}else if (scale == L3GD20_Scale_2000){
		I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Transmitter);
		I2C_Write(I2C1, CTRL_REG4); // write one byte to the slave
		Delay(3);
		I2C_Write(I2C1, 0x20);
		Delay(3);
		I2C_Stop(I2C1);
	}
	
	/* Save scale */
	L3GD20_INT_Scale = scale;

	/* Set high-pass filter settings */
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Transmitter);
	I2C_Write(I2C1, CTRL_REG2); // write one byte to the slave
	Delay(3);
	I2C_Write(I2C1, 0x00);
	Delay(3);
	I2C_Stop(I2C1);

	/* Enable high-pass filter */
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Transmitter);
	I2C_Write(I2C1, CTRL_REG5); // write one byte to the slave
	Delay(3);
	I2C_Write(I2C1, 0x10);
	Delay(3);
	I2C_Stop(I2C1);
	
	return L3GD20_State_Ready;
}

L3GD20_State_TypeDef L3GD20_ReadXYZ(L3GD20_TypeDef* L3GD20_InitStruct) {
	float tmp_data1, tmp_data2;
	
	/* Read X */
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Transmitter);
	I2C_Write(I2C1, OUT_X_L); 
	I2C_Stop(I2C1);
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Receiver);
	L3GD20_InitStruct->X = I2C_NoAck_Read(I2C1);
	
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Transmitter);
	I2C_Write(I2C1, OUT_X_H); 
	I2C_Stop(I2C1);
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Receiver);
	L3GD20_InitStruct->X |= I2C_NoAck_Read(I2C1) << 8;

	/* Read Y */
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Transmitter);
	I2C_Write(I2C1, OUT_Y_L); 
	I2C_Stop(I2C1);
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Receiver);
	L3GD20_InitStruct->Y = I2C_NoAck_Read(I2C1);
	
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Transmitter);
	I2C_Write(I2C1, OUT_Y_H); 
	I2C_Stop(I2C1);
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Receiver);
	L3GD20_InitStruct->Y |= I2C_NoAck_Read(I2C1) << 8;
	
	
	/* Read Z */
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Transmitter);
	I2C_Write(I2C1, OUT_Z_L); 
	I2C_Stop(I2C1);
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Receiver);
	L3GD20_InitStruct->Z = I2C_NoAck_Read(I2C1);
	
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Transmitter);
	I2C_Write(I2C1, OUT_Z_H); 
	I2C_Stop(I2C1);
	I2C1_Start(I2C1, L3GD20_InitStruct->Address, I2C_Direction_Receiver);
	L3GD20_InitStruct->Z |= I2C_NoAck_Read(I2C1) << 8;
	
	/* Set sensitivity scale correction */
	if (L3GD20_INT_Scale == L3GD20_Scale_250) {
		/* Sensitivity at 250 range = 8.75 mdps/digit */
		tmp_data2 = L3GD20_SENSITIVITY_250 * 0.001;
	} else if (L3GD20_INT_Scale == L3GD20_Scale_500) {
		/* Sensitivity at 500 range = 17.5 mdps/digit */
		tmp_data2 = L3GD20_SENSITIVITY_500 * 0.001;
	} else {
		/* Sensitivity at 2000 range = 70 mdps/digit */
		tmp_data2 = L3GD20_SENSITIVITY_2000 * 0.001;
	}
	
	tmp_data1 = (float)L3GD20_InitStruct->X * tmp_data2;
	L3GD20_InitStruct->X = (int16_t) tmp_data1;
	tmp_data1 = (float)L3GD20_InitStruct->Y * tmp_data2;
	L3GD20_InitStruct->Y = (int16_t) tmp_data1;
	tmp_data1 = (float)L3GD20_InitStruct->Z * tmp_data2;
	L3GD20_InitStruct->Z = (int16_t) tmp_data1;
	return L3GD20_State_Ready;
}
