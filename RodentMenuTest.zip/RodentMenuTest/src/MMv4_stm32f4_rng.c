#include "MMv4_stm32f4_rng.h"

void RNG_Cmd(FunctionalState NewState)
{
  /* Check the parameters */
  assert_param(IS_FUNCTIONAL_STATE(NewState));

  if (NewState != DISABLE)
  {
    /* Enable the RNG */
    RNG->CR |= RNG_CR_RNGEN;
  }
  else
  {
    /* Disable the RNG */
    RNG->CR &= ~RNG_CR_RNGEN;
  }
}

void RNG_Initialize(void){  
 /* Enable RNG clock source */
  RCC_AHB2PeriphClockCmd(RCC_AHB2Periph_RNG, ENABLE);

  /* RNG enable */
  RNG_Cmd(ENABLE);
}

uint32_t RNG_GetRandomNumber(void){
  /* Return random number from DR register */
  return RNG->DR;
}

FlagStatus RNG_GetFlagStatus(uint8_t RNG_FLAG)
{
  FlagStatus bitstatus = RESET;

  assert_param(IS_RNG_GET_FLAG(RNG_FLAG));

  if ((RNG->SR & RNG_FLAG) != (uint8_t)RESET)
  {
    bitstatus = SET;
  }
  else
  {
    bitstatus = RESET;
  }
  
  return  bitstatus;
}
