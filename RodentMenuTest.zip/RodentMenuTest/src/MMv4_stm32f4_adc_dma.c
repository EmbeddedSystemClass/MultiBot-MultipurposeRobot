#include "MMv4_stm32f4_adc_dma.h"

///* Converts percents to error value (max 3300)  */
//int ADC_ErrorToPerc(int error_value){
//	  if (((abs(error_value*Error_percent_factor) > 0) && (abs(error_value*Error_percent_factor) < 40)) ? (1) : (0)){
//    return error_value*Error_percent_factor;
//  }else if(error_value*Error_percent_factor < 0){
//    return -40;
//  }else{
//		return 40;
//	}
//}
int32_t getADCx(IRSernorsData_InitTypeDef* IRSensors_DataStruct, uint8_t x){//SE_value_correct[0]
	return IRSensors_DataStruct->SE_value[x] - IRSensors_DataStruct->SE_value_correct[x];
}

void SE1_ADC_Initialize(IRSernorsData_InitTypeDef* IRSensorsData_DataStruct){
  ADC_InitTypeDef       ADC_InitStructure;
  ADC_CommonInitTypeDef ADC_CommonInitStructure;
  DMA_InitTypeDef       DMA_InitStructure;
  GPIO_InitTypeDef      GPIO_InitStructure;

  /* Enable ADCx, DMA and GPIO clocks ****************************************/ 
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
  RCC_AHB1PeriphClockCmd(SE1_ADC_CHANNEL_GPIO_CLK, ENABLE);  
  RCC_APB2PeriphClockCmd(SE_ADC_CLK, ENABLE);

  /* DMA2 Stream0 channel0 configuration **************************************/
  DMA_InitStructure.DMA_Channel = SE_ADC_DMA_CHANNEL;  
  DMA_InitStructure.DMA_PeripheralBaseAddr =  SE_ADC_DR_ADDRESS;//(uint32_t)ADCx_DR_ADDRESS;
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)&IRSensorsData_DataStruct->SE_value[0];
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
  DMA_InitStructure.DMA_BufferSize = 1;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Disable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;         
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
  DMA_Init(SE_ADC_DMA_STREAM, &DMA_InitStructure);
  DMA_Cmd(SE_ADC_DMA_STREAM, ENABLE);

  /* Configure ADC1 Channel2 pin as analog input ******************************/
  GPIO_InitStructure.GPIO_Pin = SE1_GPIO_PIN ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
  GPIO_Init(SE1_GPIO_PORT, &GPIO_InitStructure);

  /* ADC Common Init **********************************************************/
  ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div2;
  ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
  ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
  ADC_CommonInit(&ADC_CommonInitStructure);

  /* ADC1 Init ****************************************************************/
  ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
  ADC_InitStructure.ADC_ScanConvMode = DISABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
  ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfConversion = 1;
  ADC_Init(SE_ADC , &ADC_InitStructure);

  /* ADC1 regular channel7 configuration **************************************/
  ADC_RegularChannelConfig(SE_ADC, SE1_Channel, 1, ADC_SampleTime_3Cycles);

 /* Enable DMA request after last transfer (Single-ADC mode) */
  ADC_DMARequestAfterLastTransferCmd(SE_ADC, ENABLE);

  /* Enable ADC1 DMA */
  ADC_DMACmd(SE_ADC, ENABLE);

  /* Enable ADC1 */
  ADC_Cmd(SE_ADC, ENABLE);

  /* Start ADC Software Conversion */ 
  ADC_SoftwareStartConv(SE_ADC);
}

void SE2_ADC_Initialize(IRSernorsData_InitTypeDef* IRSensorsData_DataStruct){
  ADC_InitTypeDef       ADC_InitStructure;
  ADC_CommonInitTypeDef ADC_CommonInitStructure;
  DMA_InitTypeDef       DMA_InitStructure;
  GPIO_InitTypeDef      GPIO_InitStructure;

  /* Enable ADCx, DMA and GPIO clocks ****************************************/ 
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
  RCC_AHB1PeriphClockCmd(SE2_ADC_CHANNEL_GPIO_CLK, ENABLE);  
  RCC_APB2PeriphClockCmd(SE_ADC_CLK, ENABLE);

  /* DMA2 Stream0 channel0 configuration **************************************/
  DMA_InitStructure.DMA_Channel = SE_ADC_DMA_CHANNEL;  
  DMA_InitStructure.DMA_PeripheralBaseAddr =  SE_ADC_DR_ADDRESS;//(uint32_t)ADCx_DR_ADDRESS;
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)&IRSensorsData_DataStruct->SE_value[1];
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
  DMA_InitStructure.DMA_BufferSize = 1;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Disable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;         
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
  DMA_Init(SE_ADC_DMA_STREAM, &DMA_InitStructure);
  DMA_Cmd(SE_ADC_DMA_STREAM, ENABLE);

  /* Configure ADC1 Channel2 pin as analog input ******************************/
  GPIO_InitStructure.GPIO_Pin = SE2_GPIO_PIN ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
  GPIO_Init(SE2_GPIO_PORT, &GPIO_InitStructure);

  /* ADC Common Init **********************************************************/
  ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div2;
  ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
  ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
  ADC_CommonInit(&ADC_CommonInitStructure);

  /* ADC1 Init ****************************************************************/
  ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
  ADC_InitStructure.ADC_ScanConvMode = DISABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
  ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfConversion = 1;
  ADC_Init(SE_ADC , &ADC_InitStructure);

  /* ADC1 regular channel7 configuration **************************************/
  ADC_RegularChannelConfig(SE_ADC, SE2_Channel, 1, ADC_SampleTime_3Cycles);

 /* Enable DMA request after last transfer (Single-ADC mode) */
  ADC_DMARequestAfterLastTransferCmd(SE_ADC, ENABLE);

  /* Enable ADC1 DMA */
  ADC_DMACmd(SE_ADC, ENABLE);

  /* Enable ADC1 */
  ADC_Cmd(SE_ADC, ENABLE);

  /* Start ADC Software Conversion */ 
  ADC_SoftwareStartConv(SE_ADC);
}

void SE3_ADC_Initialize(IRSernorsData_InitTypeDef* IRSensorsData_DataStruct){
  ADC_InitTypeDef       ADC_InitStructure;
  ADC_CommonInitTypeDef ADC_CommonInitStructure;
  DMA_InitTypeDef       DMA_InitStructure;
  GPIO_InitTypeDef      GPIO_InitStructure;

  /* Enable ADCx, DMA and GPIO clocks ****************************************/ 
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
  RCC_AHB1PeriphClockCmd(SE3_ADC_CHANNEL_GPIO_CLK, ENABLE);  
  RCC_APB2PeriphClockCmd(SE_ADC_CLK, ENABLE);

  /* DMA2 Stream0 channel0 configuration **************************************/
  DMA_InitStructure.DMA_Channel = SE_ADC_DMA_CHANNEL;  
  DMA_InitStructure.DMA_PeripheralBaseAddr =  SE_ADC_DR_ADDRESS;//(uint32_t)ADCx_DR_ADDRESS;
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)&IRSensorsData_DataStruct->SE_value[3];
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
  DMA_InitStructure.DMA_BufferSize = 1;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Disable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;         
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
  DMA_Init(SE_ADC_DMA_STREAM, &DMA_InitStructure);
  DMA_Cmd(SE_ADC_DMA_STREAM, ENABLE);

  /* Configure ADC1 Channel2 pin as analog input ******************************/
  GPIO_InitStructure.GPIO_Pin = SE3_GPIO_PIN ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
  GPIO_Init(SE3_GPIO_PORT, &GPIO_InitStructure);

  /* ADC Common Init **********************************************************/
  ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div2;
  ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
  ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
  ADC_CommonInit(&ADC_CommonInitStructure);

  /* ADC1 Init ****************************************************************/
  ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
  ADC_InitStructure.ADC_ScanConvMode = DISABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
  ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfConversion = 1;
  ADC_Init(SE_ADC , &ADC_InitStructure);

  /* ADC1 regular channel7 configuration **************************************/
  ADC_RegularChannelConfig(SE_ADC, SE3_Channel, 1, ADC_SampleTime_3Cycles);

 /* Enable DMA request after last transfer (Single-ADC mode) */
  ADC_DMARequestAfterLastTransferCmd(SE_ADC, ENABLE);

  /* Enable ADC1 DMA */
  ADC_DMACmd(SE_ADC, ENABLE);

  /* Enable ADC1 */
  ADC_Cmd(SE_ADC, ENABLE);

  /* Start ADC Software Conversion */ 
  ADC_SoftwareStartConv(SE_ADC);
}

void SE4_ADC_Initialize(IRSernorsData_InitTypeDef* IRSensorsData_DataStruct){
  ADC_InitTypeDef       ADC_InitStructure;
  ADC_CommonInitTypeDef ADC_CommonInitStructure;
  DMA_InitTypeDef       DMA_InitStructure;
  GPIO_InitTypeDef      GPIO_InitStructure;

  /* Enable ADCx, DMA and GPIO clocks ****************************************/ 
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
  RCC_AHB1PeriphClockCmd(SE4_ADC_CHANNEL_GPIO_CLK, ENABLE);  
  RCC_APB2PeriphClockCmd(SE_ADC_CLK, ENABLE);

  /* DMA2 Stream0 channel0 configuration **************************************/
  DMA_InitStructure.DMA_Channel = SE_ADC_DMA_CHANNEL;  
  DMA_InitStructure.DMA_PeripheralBaseAddr =  SE_ADC_DR_ADDRESS;//(uint32_t)ADCx_DR_ADDRESS;
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)&IRSensorsData_DataStruct->SE_value[4];
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
  DMA_InitStructure.DMA_BufferSize = 1;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Disable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;         
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
  DMA_Init(SE_ADC_DMA_STREAM, &DMA_InitStructure);
  DMA_Cmd(SE_ADC_DMA_STREAM, ENABLE);

  /* Configure ADC1 Channel2 pin as analog input ******************************/
  GPIO_InitStructure.GPIO_Pin = SE4_GPIO_PIN ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
  GPIO_Init(SE4_GPIO_PORT, &GPIO_InitStructure);

  /* ADC Common Init **********************************************************/
  ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div2;
  ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
  ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
  ADC_CommonInit(&ADC_CommonInitStructure);

  /* ADC1 Init ****************************************************************/
  ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
  ADC_InitStructure.ADC_ScanConvMode = DISABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
  ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfConversion = 1;
  ADC_Init(SE_ADC , &ADC_InitStructure);

  /* ADC1 regular channel7 configuration **************************************/
  ADC_RegularChannelConfig(SE_ADC, SE4_Channel, 1, ADC_SampleTime_3Cycles);

 /* Enable DMA request after last transfer (Single-ADC mode) */
  ADC_DMARequestAfterLastTransferCmd(SE_ADC, ENABLE);

  /* Enable ADC1 DMA */
  ADC_DMACmd(SE_ADC, ENABLE);

  /* Enable ADC1 */
  ADC_Cmd(SE_ADC, ENABLE);

  /* Start ADC Software Conversion */ 
  ADC_SoftwareStartConv(SE_ADC);
}

void SE_ADC_DMA_Initialize(IRSernorsData_InitTypeDef* IRSensorsData_DataStruct){
  ADC_InitTypeDef       ADC_InitStructure;
  ADC_CommonInitTypeDef ADC_CommonInitStructure;
  DMA_InitTypeDef       DMA_InitStructure;
  GPIO_InitTypeDef      GPIO_InitStructure;

  /* Enable ADCx, DMA and GPIO clocks ****************************************/ 
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
  RCC_AHB1PeriphClockCmd(SE1_ADC_CHANNEL_GPIO_CLK, ENABLE);
	RCC_AHB1PeriphClockCmd(SE2_ADC_CHANNEL_GPIO_CLK, ENABLE);  
	RCC_AHB1PeriphClockCmd(SE3_ADC_CHANNEL_GPIO_CLK, ENABLE); 
	RCC_AHB1PeriphClockCmd(SE4_ADC_CHANNEL_GPIO_CLK, ENABLE);
	RCC_APB2PeriphClockCmd(SE_ADC_CLK, ENABLE);
	
	/* DMA2 Stream0 channel0 configuration **************************************/
	DMA_InitStructure.DMA_Channel = SE_ADC_DMA_CHANNEL; 
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)&IRSensorsData_DataStruct->SE_value[0];
  DMA_InitStructure.DMA_PeripheralBaseAddr = SE_ADC_DR_ADDRESS;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
  DMA_InitStructure.DMA_BufferSize = 4;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;         
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
  DMA_Init(SE_ADC_DMA_STREAM, &DMA_InitStructure);
	
	  /* Enable DMA Stream Transfer Complete interrupt */
  //DMA_ITConfig(SE_ADC_DMA_STREAM, DMA_IT_TC, ENABLE);
	
	/* DMA2_Stream0 enable */
  DMA_Cmd(SE_ADC_DMA_STREAM, ENABLE);

  /* Configure ADC1 Channel2 pin as analog input ******************************/
  GPIO_InitStructure.GPIO_Pin = SE1_GPIO_PIN ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	
//	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_25MHz;
	
  GPIO_Init(SE1_GPIO_PORT, &GPIO_InitStructure);
	
	  /* Configure ADC1 Channel12 pin as analog input ******************************/
  GPIO_InitStructure.GPIO_Pin = SE2_GPIO_PIN ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	
//	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_25MHz;
	
  GPIO_Init(SE2_GPIO_PORT, &GPIO_InitStructure);
	
		/* Configure ADC1 Channel3 pin as analog input ******************************/
  GPIO_InitStructure.GPIO_Pin = SE3_GPIO_PIN ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	
//	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_25MHz;
	
  GPIO_Init(SE3_GPIO_PORT, &GPIO_InitStructure);
	
		/* Configure ADC1 Channel13 pin as analog input ******************************/
  GPIO_InitStructure.GPIO_Pin = SE4_GPIO_PIN ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	
//	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_25MHz;
	
  GPIO_Init(SE4_GPIO_PORT, &GPIO_InitStructure);
	
	/* Put everything back to defaults */
	ADC_DeInit();
	
  /* ADC Common Init **********************************************************/
  ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div2;
  ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_2;
  ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_7Cycles;
  ADC_CommonInit(&ADC_CommonInitStructure);

  /* ADC1 Init ****************************************************************/
  ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
  ADC_InitStructure.ADC_ScanConvMode = ENABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
  ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	//ADC_InitStructure.ADC_ExternalTrigConv = DISABLE;
  ADC_InitStructure.ADC_NbrOfConversion = 4;
  ADC_Init(SE_ADC , &ADC_InitStructure);

  /* ADC1 regular channel2 configuration **************************************/
  ADC_RegularChannelConfig(SE_ADC, SE1_Channel, 1, ADC_SampleTime_28Cycles);
	
	/* ADC1 regular channel12 configuration **************************************/
  ADC_RegularChannelConfig(SE_ADC, SE2_Channel, 2,ADC_SampleTime_28Cycles);
	
	/* ADC1 regular channel3 configuration **************************************/
  ADC_RegularChannelConfig(SE_ADC, SE3_Channel, 3, ADC_SampleTime_28Cycles);

		/* ADC1 regular channel13 configuration **************************************/
  ADC_RegularChannelConfig(SE_ADC, SE4_Channel, 4, ADC_SampleTime_28Cycles);
	
 /* Enable DMA request after last transfer (Single-ADC mode) */
  ADC_DMARequestAfterLastTransferCmd(SE_ADC, ENABLE);

  /* Enable ADC1 DMA */
  ADC_DMACmd(SE_ADC, ENABLE);

  /* Enable ADC1 */
  ADC_Cmd(SE_ADC, ENABLE);

  /* Start ADC Software Conversion */ 
  ADC_SoftwareStartConv(SE_ADC);
}

