#include "MMv4_stm32f4_usart.h"

/**
  * @brief  Configures the USART Peripheral.
  * @param  None
  * @retval None
  */
void USART_Initialize(void)
{
	/*USART CONNECTION INFO
		1. Connect SCL pin
		2. Connect SDA pin
		3. Connect common GND pin (to synchronize)
	
		4. If st-link is connected and USART does not work disconnect RST pin 
	*/
	
  USART_InitTypeDef USART_InitStructure;
	GPIO_InitTypeDef USART_GPIO_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

	/* Configure USART Tx and RX as alternate function  */
	USART_GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6| GPIO_Pin_7;
	USART_GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	USART_GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	USART_GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	USART_GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;

	GPIO_Init(GPIOB, &USART_GPIO_InitStructure);
	/* Connect PXx to USARTx_Tx*/
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_USART1);

	/* Connect PXx to USARTx_Rx*/
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_USART1);

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

	/* USARTx configured as follows:
			- BaudRate = 115200 baud  
			- Word Length = 8 Bits
			- One Stop Bit
			- No parity
			- Hardware flow control disabled (RTS and CTS signals)
			- Receive and transmit enabled
	*/
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

	USART_Init(USART1, &USART_InitStructure);
	USART_Cmd(USART1, ENABLE); 
}

void USART_NVIC_Initialize(void){
	NVIC_InitTypeDef NVIC_InitStructure;
	
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
 
	NVIC_Init(&NVIC_InitStructure);
	//USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
}

void USART_SendChar(char c)
{
	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
	USART_SendData(USART1, c);
}

void USART_SendString(const char* s)
{
	while (*s)
		USART_SendChar(*s++);
}

void USART_Puts(volatile char *s){
	while(*s){
	 // wait until data register is empty
	 while( !(USART1->SR & 0x00000040) );
	 USART_SendData(USART1, *s);
	 *s++;
	 }
}

void USART_SprintfPuts(int16_t value){
	char s[100];
	sprintf(s, "%d", value);
	USART_Puts(s);
}

void USART1_IRQHandler(void)
{
  static int tx_index = 0;
  static int rx_index = 0;
  static volatile char StringLoop[] = "Empty space for long fhfghjgfd  hdhdgfdfgrnfcfhcfhfh gfhchchfhfhhor not that long string\r\n";
  
  if (USART_GetITStatus(USART1, USART_IT_TXE) != RESET) // Transmit the string in a loop
  {
    USART_SendData(USART1, StringLoop[tx_index++]);
 
    if (tx_index >= (sizeof(StringLoop) - 1))
      tx_index = 0;
  }
 
  if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) // Received characters modify string
  {
    StringLoop[rx_index++] = USART_ReceiveData(USART1);
 
    if (rx_index >= (sizeof(StringLoop) - 1))
      rx_index = 0;
  }
}

float USART_geti(void){
	USARTBuffer_TypeDef USART_Buffer;
	char buffer[20];
	int index;
	for(index = 0; index < 20; index++) buffer[index] = '\0';
	index = 0;
	//USART_Puts("\r");
	while(1){
		if (USART_GetFlagStatus(USART1, USART_FLAG_RXNE)){
			if(USART_ReceiveData(USART1) != '/'){
				buffer[index] =  USART_ReceiveData(USART1);
				sprintf(USART_Buffer.buffer, "%c", buffer[index]);
				USART_Puts(USART_Buffer.buffer);
				index++;
			}else{
				memset(USART_Buffer.buffer, 0, sizeof USART_Buffer.buffer);
				//fflush(stdout);  
				USART_ClearFlag(USART1, USART_FLAG_RXNE);
				USART_ClearITPendingBit(USART1, USART_FLAG_RXNE);
				//USART_Puts("\r\n");
				return atof(buffer);
			}
		}
	}
}
